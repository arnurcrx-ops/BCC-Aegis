pragma Singleton

import QtQuick

QtObject {
    readonly property color primaryGreen: "#008C45"
    readonly property color darkGreen: "#006B35"
    readonly property color background: "#F5F7FA"
    readonly property color surface: "#FFFFFF"
    readonly property color primaryText: "#1A1A1A"
    readonly property color secondaryText: "#7B828C"
    readonly property color border: "#E5E8EB"
    readonly property color success: "#198754"
    readonly property color error: "#DC3545"
    readonly property color sidebar: "#FFFFFF"
    readonly property int cornerRadius: 16
}
