import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import KiberQalqan 1.0

Item {
    id: root
    width: parent ? parent.width : 400
    height: 260

    SecureStore {
        id: secureStore
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 12
        spacing: 8

        Label {
            text: "Secure Storage (Encryption at Rest)"
            font.bold: true
            font.pixelSize: 16
        }

        Label {
            text: secureStore.available
                ? "Status: ACTIVE"
                : "Status: DISABLED (" + secureStore.lastError + ")"
            color: secureStore.available ? "#2e7d32" : "#c62828"
            font.bold: true
        }

        Label {
            text: "File: " + (secureStore.storagePath || "(none)")
            font.family: "monospace"
            font.pixelSize: 11
            wrapMode: Text.WrapAnywhere
            Layout.fillWidth: true
        }

        Label {
            text: "Last op: " + (secureStore.lastOperation || "(none)")
            font.family: "monospace"
            font.pixelSize: 11
            wrapMode: Text.WrapAnywhere
            Layout.fillWidth: true
        }

        Label {
            text: "Error: " + (secureStore.lastError || "(none)")
            color: secureStore.lastError ? "#c62828" : "#555"
            font.pixelSize: 11
            wrapMode: Text.WrapAnywhere
            Layout.fillWidth: true
        }

        RowLayout {
            spacing: 8
            Button {
                text: "Save demo"
                enabled: secureStore.available
                onClicked: {
                    var demo = JSON.stringify({ activity: [
                        { id: 1, title: "Coffee", amount: -1200 },
                        { id: 2, title: "Salary", amount: 500000 }
                    ]})
                    secureStore.save(demo)
                }
            }
            Button {
                text: "Load"
                enabled: secureStore.available
                onClicked: {
                    var data = secureStore.load()
                    console.log("Load result:", data.length, "bytes")
                }
            }
            Button {
                text: "Exists?"
                enabled: secureStore.available
                onClicked: console.log("Exists:", secureStore.exists())
            }
        }

        Label {
            text: secureStore.exists() ? "File present on disk" : "No file yet"
            color: "#555"
            font.pixelSize: 11
        }
    }
}