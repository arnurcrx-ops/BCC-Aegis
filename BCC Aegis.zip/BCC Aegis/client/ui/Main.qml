pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import BccDesktop
import KiberQalqan 1.0

ApplicationWindow {
    id: window

    width: 1440
    height: 900
    minimumWidth: 1024
    minimumHeight: 700
    visible: true
    title: "BCC Desktop"
    color: Theme.background

    property int currentTab: 0
    property bool balanceVisible: true
    property bool analysisInProgress: false
    property string analysisResult: ""
    property string analysisError: ""
    property bool transferSent: false
    property bool cardCreationInProgress: false
    property bool transferInProgress: false
    property string cardCreationError: ""
    property string createdCardNumber: ""
    property double createdCardBalance: 0
    property string transferMessage: ""
    property bool transferSucceeded: false
    property int activityFilter: 0

    readonly property var pageTitles: [
        "Добрый день, Айдана",
        "Kiberqalqan",
        "Переводы",
        "История операций",
        "Безопасность"
    ]
    readonly property var pageSubtitles: [
        "Вот что происходит с вашими финансами сегодня",
        "Проверьте сообщение, ссылку или номер на признаки мошенничества",
        "Отправляйте деньги быстро и безопасно",
        "Все движения по вашим демо-счетам",
        "Шифрование данных на диске"
    ]
    readonly property var navigationItems: [
        { label: "Обзор", marker: "▦" },
        { label: "Kiberqalqan", marker: "⬡" },
        { label: "Переводы", marker: "⇄" },
        { label: "История", marker: "◷" },
        { label: "Безопасность", marker: "🔒" }
    ]
    readonly property var transactionItems: [
        {
            title: "Magnum",
            detail: "Сегодня, 14:32 · Покупки · Демо",
            amount: "− 12 450 ₸",
            incoming: false,
            marker: "▤"
        },
        {
            title: "Перевод от Армана К.",
            detail: "Сегодня, 11:08 · Переводы · Демо",
            amount: "+ 35 000 ₸",
            incoming: true,
            marker: "⇄"
        },
        {
            title: "Coffee Boom",
            detail: "Вчера, 18:44 · Кафе и рестораны · Демо",
            amount: "− 3 280 ₸",
            incoming: false,
            marker: "☕"
        },
        {
            title: "Beeline",
            detail: "Вчера, 09:15 · Мобильная связь · Демо",
            amount: "− 4 990 ₸",
            incoming: false,
            marker: "▯"
        },
        {
            title: "Пополнение счета",
            detail: "12 июня, 16:20 · Пополнения · Демо",
            amount: "+ 80 000 ₸",
            incoming: true,
            marker: "▣"
        }
    ]
    readonly property var visibleTransactionItems: transactionItems.filter(function(item) {
        var matchesFilter = activityFilter === 0
                || (activityFilter === 1 && item.incoming)
                || (activityFilter === 2 && !item.incoming)
        var query = activitySearch.text.trim().toLowerCase()
        var matchesSearch = query.length === 0
                || item.title.toLowerCase().indexOf(query) !== -1
                || item.detail.toLowerCase().indexOf(query) !== -1
        return matchesFilter && matchesSearch
    })

    ApiClient {
        id: apiClient

        onScamResult: function(isScam, reason) {
            window.analysisInProgress = false
            window.analysisError = ""
            window.analysisResult = isScam
                    ? "Обнаружены признаки мошенничества"
                    : "Угроз не обнаружено"
            scamResultDetail.text = isScam
                    ? (reason || "Не переходите по ссылкам и не сообщайте коды из SMS.")
                    : "Текст не содержит очевидных подозрительных признаков. Всё равно будьте внимательны."
            scamResultCard.danger = isScam
        }

        onRequestFailed: function(error) {
            window.analysisInProgress = false
            window.analysisResult = ""
            window.analysisError = error
        }

        onCardCreated: function(cardNumber, balance) {
            window.cardCreationInProgress = false
            window.cardCreationError = ""
            window.createdCardNumber = cardNumber
            window.createdCardBalance = balance
            senderCardInput.text = cardNumber.replace(/(.{4})/g, "$1 ").trim()
        }

        onCardCreationFailed: function(message) {
            window.cardCreationInProgress = false
            window.cardCreationError = message
        }

        onTransferResult: function(success, message) {
            window.transferInProgress = false
            window.transferSucceeded = success
            window.transferMessage = message
            if (success)
                window.transferSent = true
        }
    }

    RowLayout {
        anchors.fill: parent
        spacing: 0

        Rectangle {
            Layout.preferredWidth: 248
            Layout.fillHeight: true
            color: Theme.surface
            border.color: Theme.border
            border.width: 1

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 20
                spacing: 0

                Button {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 52
                    onClicked: window.currentTab = 0

                    background: Rectangle {
                        color: "transparent"
                    }

                    contentItem: RowLayout {
                        spacing: 11

                        Rectangle {
                            Layout.preferredWidth: 38
                            Layout.preferredHeight: 38
                            radius: 11
                            color: Theme.primaryGreen

                            Label {
                                anchors.centerIn: parent
                                text: "✦"
                                color: Theme.surface
                                font.pixelSize: 22
                                font.weight: Font.Bold
                            }
                        }

                        ColumnLayout {
                            spacing: 0

                            Label {
                                text: "BCC"
                                color: Theme.primaryText
                                font.pixelSize: 18
                                font.weight: Font.ExtraBold
                            }

                            Label {
                                text: "DESKTOP"
                                color: Theme.secondaryText
                                font.pixelSize: 12
                                font.weight: Font.DemiBold
                                font.letterSpacing: 1.2
                            }
                        }
                    }
                }

                Label {
                    Layout.topMargin: 34
                    Layout.leftMargin: 12
                    Layout.bottomMargin: 10
                    text: "ГЛАВНОЕ МЕНЮ"
                    color: "#A1A7B0"
                    font.pixelSize: 12
                    font.weight: Font.Bold
                    font.letterSpacing: 1.1
                }

                Repeater {
                    model: window.navigationItems

                    delegate: ItemDelegate {
                        id: navItem

                        required property int index
                        required property var modelData

                        Layout.fillWidth: true
                        Layout.preferredHeight: 44
                        Layout.bottomMargin: 3
                        highlighted: window.currentTab === index
                        onClicked: window.currentTab = index

                        background: Rectangle {
                            radius: 9
                            color: navItem.highlighted ? "#E9F6EF" : "transparent"
                        }

                        contentItem: RowLayout {
                            spacing: 12

                            Label {
                                Layout.preferredWidth: 23
                                text: navItem.modelData.marker
                                color: navItem.highlighted ? Theme.primaryGreen : "#69707A"
                                font.pixelSize: 18
                                horizontalAlignment: Text.AlignHCenter
                            }

                            Label {
                                Layout.fillWidth: true
                                text: navItem.modelData.label
                                color: navItem.highlighted ? Theme.primaryGreen : "#69707A"
                                font.pixelSize: 15
                                font.weight: navItem.highlighted ? Font.DemiBold : Font.Medium
                            }

                            Rectangle {
                                visible: navItem.index === 1
                                Layout.preferredWidth: 6
                                Layout.preferredHeight: 6
                                radius: 3
                                color: Theme.primaryGreen
                            }
                        }
                    }
                }

                Item {
                    Layout.fillHeight: true
                }

                Rectangle {
                    Layout.fillWidth: true
                    Layout.bottomMargin: 14
                    radius: 10
                    color: Theme.background
                    implicitHeight: sandboxNotice.implicitHeight + 24

                    Label {
                        id: sandboxNotice

                        anchors.fill: parent
                        anchors.margins: 12
                        text: "Демо-режим\nДанные вымышлены. Реальные банковские услуги не подключены."
                        color: Theme.secondaryText
                        font.pixelSize: 12
                        lineHeight: 1.25
                        wrapMode: Text.WordWrap
                    }
                }

                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 1
                    color: Theme.border
                }

                RowLayout {
                    Layout.fillWidth: true
                    Layout.topMargin: 15
                    spacing: 10

                    Rectangle {
                        Layout.preferredWidth: 36
                        Layout.preferredHeight: 36
                        radius: 18
                        color: "#E7ECE9"

                        Label {
                            anchors.centerIn: parent
                            text: "АК"
                            color: "#315C46"
                            font.pixelSize: 14
                            font.weight: Font.Bold
                        }
                    }

                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 2

                        Label {
                            text: "Айдана К."
                            color: Theme.primaryText
                            font.pixelSize: 14
                            font.weight: Font.Bold
                        }

                        Label {
                            text: "Демо-профиль"
                            color: Theme.secondaryText
                            font.pixelSize: 12
                        }
                    }

                    Label {
                        text: "···"
                        color: Theme.secondaryText
                        font.pixelSize: 18
                    }
                }
            }
        }

        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 0

            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 84
                color: Theme.surface
                border.color: Theme.border
                border.width: 1

                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 32
                    anchors.rightMargin: 32

                    ColumnLayout {
                        spacing: 3

                        Label {
                            text: window.pageTitles[window.currentTab]
                            color: Theme.primaryText
                            font.pixelSize: 20
                            font.weight: Font.Bold
                        }

                        Label {
                            text: window.pageSubtitles[window.currentTab]
                            color: Theme.secondaryText
                            font.pixelSize: 12
                        }
                    }

                    Item {
                        Layout.fillWidth: true
                    }

                    Rectangle {
                        Layout.preferredWidth: 142
                        Layout.preferredHeight: 32
                        radius: 8
                        color: Theme.background

                        RowLayout {
                            anchors.centerIn: parent
                            spacing: 7

                            Rectangle {
                                Layout.preferredWidth: 7
                                Layout.preferredHeight: 7
                                radius: 4
                                color: Theme.primaryGreen
                            }

                            Label {
                                text: "Демо-система"
                                color: Theme.secondaryText
                                font.pixelSize: 12
                            }
                        }
                    }

                    Rectangle {
                        Layout.preferredWidth: 38
                        Layout.preferredHeight: 38
                        radius: 9
                        color: Theme.surface
                        border.color: Theme.border

                        Label {
                            anchors.centerIn: parent
                            text: "♧"
                            color: "#65707A"
                            font.pixelSize: 18
                        }

                        Rectangle {
                            anchors.right: parent.right
                            anchors.top: parent.top
                            anchors.rightMargin: 8
                            anchors.topMargin: 7
                            width: 6
                            height: 6
                            radius: 3
                            color: "#D64545"
                        }
                    }
                }
            }

            StackLayout {
                id: pages

                Layout.fillWidth: true
                Layout.fillHeight: true
                currentIndex: window.currentTab

                ScrollView {
                    id: overviewScroll
                    clip: true
                    ScrollBar.vertical.policy: ScrollBar.AsNeeded

                    ColumnLayout {
                        width: Math.max(0, overviewScroll.availableWidth - 56)
                        anchors.horizontalCenter: parent.horizontalCenter
                        anchors.top: parent.top
                        anchors.topMargin: 24
                        anchors.bottomMargin: 20
                        spacing: 18

                        Rectangle {
                            Layout.fillWidth: true
                            Layout.preferredHeight: 215
                            radius: 14
                            color: Theme.primaryGreen
                            clip: true

                            Rectangle {
                                width: 260
                                height: 260
                                radius: 130
                                x: parent.width - 170
                                y: -150
                                color: "#18FFFFFF"
                            }

                            RowLayout {
                                anchors.fill: parent
                                anchors.margins: 26
                                spacing: 20

                                ColumnLayout {
                                    Layout.fillWidth: true
                                    spacing: 8

                                    Label {
                                        text: "ДЕМО-СЧЕТ · ОСНОВНОЙ"
                                        color: "#D8F0E1"
                                        font.pixelSize: 12
                                        font.weight: Font.Bold
                                        font.letterSpacing: 1
                                    }

                                    Label {
                                        text: window.balanceVisible ? "100 000 ₸" : "••••••••"
                                        color: Theme.surface
                                        font.pixelSize: 34
                                        font.weight: Font.Bold
                                    }

                                    Label {
                                        text: "Демо-баланс · карта •••• 4821"
                                        color: "#D8F0E1"
                                        font.pixelSize: 12
                                    }

                                    Item {
                                        Layout.fillHeight: true
                                    }

                                    RowLayout {
                                        spacing: 18

                                        ColumnLayout {
                                            spacing: 2

                                            Label {
                                                text: "ДОСТУПНО"
                                                color: "#D8F0E1"
                                                font.pixelSize: 12
                                                font.weight: Font.DemiBold
                                            }

                                            Label {
                                                text: window.balanceVisible ? "100 000 ₸" : "••••••"
                                                color: Theme.surface
                                                font.pixelSize: 16
                                                font.weight: Font.Bold
                                            }
                                        }

                                        Button {
                                            id: balanceVisibilityButton
                                            text: window.balanceVisible ? "Скрыть баланс" : "Показать баланс"
                                            onClicked: window.balanceVisible = !window.balanceVisible

                                            contentItem: Label {
                                                text: balanceVisibilityButton.text
                                                color: Theme.surface
                                                font.pixelSize: 14
                                                horizontalAlignment: Text.AlignHCenter
                                                verticalAlignment: Text.AlignVCenter
                                            }

                                            background: Rectangle {
                                                radius: 7
                                                color: "#22FFFFFF"
                                                border.color: "#44FFFFFF"
                                            }
                                        }
                                    }
                                }

                                Rectangle {
                                    Layout.preferredWidth: 90
                                    Layout.preferredHeight: 90
                                    radius: 45
                                    color: "#22FFFFFF"

                                    Label {
                                        anchors.centerIn: parent
                                        text: "₸"
                                        color: Theme.surface
                                        opacity: 0.9
                                        font.pixelSize: 45
                                    }
                                }
                            }
                        }

                        RowLayout {
                            Layout.fillWidth: true
                            spacing: 18

                            Rectangle {
                                Layout.fillWidth: true
                                Layout.horizontalStretchFactor: 2
                                implicitHeight: quickActions.implicitHeight + 38
                                radius: 13
                                color: Theme.surface
                                border.color: Theme.border

                                ColumnLayout {
                                    id: quickActions
                                    anchors.fill: parent
                                    anchors.margins: 19
                                    spacing: 13

                                    RowLayout {
                                        Layout.fillWidth: true

                                        Label {
                                            text: "Быстрые действия"
                                            color: Theme.primaryText
                                            font.pixelSize: 20
                                            font.weight: Font.Bold
                                        }

                                        Item {
                                            Layout.fillWidth: true
                                        }

                                        Label {
                                            text: "Демо-режим"
                                            color: Theme.secondaryText
                                            font.pixelSize: 12
                                        }
                                    }

                                    Button {
                                        Layout.fillWidth: true
                                        Layout.preferredHeight: 58
                                        onClicked: {
                                            window.transferSent = false
                                            window.currentTab = 2
                                        }

                                        background: Rectangle {
                                            radius: 10
                                            color: Theme.primaryGreen
                                        }

                                        contentItem: RowLayout {
                                            anchors.fill: parent
                                            anchors.leftMargin: 12
                                            anchors.rightMargin: 12
                                            spacing: 10

                                            Label {
                                                text: "⇄"
                                                color: Theme.surface
                                                font.pixelSize: 22
                                            }

                                            ColumnLayout {
                                                Layout.fillWidth: true
                                                spacing: 2

                                                Label {
                                                    text: "Перевести"
                                                    color: Theme.surface
                                                    font.pixelSize: 14
                                                    font.weight: Font.Bold
                                                }

                                                Label {
                                                    text: "На карту или счет"
                                                    color: "#D8F0E1"
                                                    font.pixelSize: 12
                                                }
                                            }

                                            Label {
                                                text: "›"
                                                color: Theme.surface
                                                opacity: 0.7
                                                font.pixelSize: 22
                                            }
                                        }
                                    }

                                    Button {
                                        Layout.fillWidth: true
                                        Layout.preferredHeight: 58
                                        onClicked: window.currentTab = 1

                                        background: Rectangle {
                                            radius: 10
                                            color: "#F7FBF9"
                                            border.color: Theme.border
                                        }

                                        contentItem: RowLayout {
                                            anchors.fill: parent
                                            anchors.leftMargin: 12
                                            anchors.rightMargin: 12
                                            spacing: 10

                                            Label {
                                                text: "⬡"
                                                color: Theme.primaryGreen
                                                font.pixelSize: 22
                                            }

                                            ColumnLayout {
                                                Layout.fillWidth: true
                                                spacing: 2

                                                Label {
                                                    text: "Проверить скам"
                                                    color: Theme.primaryText
                                                    font.pixelSize: 14
                                                    font.weight: Font.Bold
                                                }

                                                Label {
                                                    text: "Kiberqalqan"
                                                    color: Theme.secondaryText
                                                    font.pixelSize: 12
                                                }
                                            }

                                            Label {
                                                text: "›"
                                                color: Theme.secondaryText
                                                font.pixelSize: 22
                                            }
                                        }
                                    }
                                }
                            }

                            Rectangle {
                                Layout.fillWidth: true
                                Layout.horizontalStretchFactor: 3
                                implicitHeight: recentActivity.implicitHeight + 38
                                radius: 13
                                color: Theme.surface
                                border.color: Theme.border

                                ColumnLayout {
                                    id: recentActivity
                                    anchors.fill: parent
                                    anchors.margins: 19
                                    spacing: 4

                                    RowLayout {
                                        Layout.fillWidth: true

                                        ColumnLayout {
                                            spacing: 2

                                            Label {
                                                text: "Последние операции"
                                                color: Theme.primaryText
                                                font.pixelSize: 20
                                                font.weight: Font.Bold
                                            }

                                            Label {
                                                text: "Только демонстрационные данные"
                                                color: Theme.secondaryText
                                                font.pixelSize: 12
                                            }
                                        }

                                        Item {
                                            Layout.fillWidth: true
                                        }

                                        Button {
                                            id: allActivityButton
                                            text: "Все операции"
                                            flat: true
                                            onClicked: window.currentTab = 3

                                            contentItem: Label {
                                                text: allActivityButton.text
                                                color: Theme.primaryGreen
                                                font.pixelSize: 14
                                                font.weight: Font.DemiBold
                                            }
                                        }
                                    }

                                    Repeater {
                                        model: window.transactionItems.slice(0, 3)

                                        delegate: transactionRow
                                    }
                                }
                            }
                        }

                        RowLayout {
                            Layout.fillWidth: true
                            spacing: 18

                            Rectangle {
                                Layout.fillWidth: true
                                Layout.preferredWidth: 3
                                implicitHeight: 146
                                radius: 13
                                color: Theme.surface
                                border.color: Theme.border

                                ColumnLayout {
                                    anchors.fill: parent
                                    anchors.margins: 19
                                    spacing: 13

                                    RowLayout {
                                        Layout.fillWidth: true

                                        ColumnLayout {
                                            spacing: 3

                                            Label {
                                                text: "Расходы в июне"
                                                color: Theme.primaryText
                                                font.pixelSize: 14
                                                font.weight: Font.Bold
                                            }

                                            Label {
                                                text: "Вымышленная статистика"
                                                color: Theme.secondaryText
                                                font.pixelSize: 12
                                            }
                                        }

                                        Item {
                                            Layout.fillWidth: true
                                        }

                                        Label {
                                            text: "42 780 ₸"
                                            color: Theme.primaryText
                                            font.pixelSize: 18
                                            font.weight: Font.Bold
                                        }
                                    }

                                    Rectangle {
                                        Layout.fillWidth: true
                                        Layout.preferredHeight: 7
                                        radius: 4
                                        color: "#EDF0F2"

                                        Rectangle {
                                            width: parent.width * 0.29
                                            height: parent.height
                                            radius: 4
                                            color: Theme.primaryGreen
                                        }
                                    }

                                    RowLayout {
                                        Layout.fillWidth: true
                                        spacing: 14

                                        Repeater {
                                            model: [
                                                { label: "Покупки", value: "22 450 ₸", color: "#008C45" },
                                                { label: "Кафе", value: "11 340 ₸", color: "#69A98A" },
                                                { label: "Связь", value: "8 990 ₸", color: "#B4D4C2" }
                                            ]

                                            delegate: RowLayout {
                                                id: expenseRow
                                                required property var modelData
                                                Layout.fillWidth: true
                                                spacing: 5

                                                Rectangle {
                                                    Layout.preferredWidth: 7
                                                    Layout.preferredHeight: 7
                                                    radius: 4
                                                    color: expenseRow.modelData.color
                                                }

                                                ColumnLayout {
                                                    Layout.fillWidth: true
                                                    spacing: 2

                                                    Label {
                                                        text: expenseRow.modelData.label
                                                        color: Theme.secondaryText
                                                        font.pixelSize: 9
                                                    }

                                                    Label {
                                                        text: expenseRow.modelData.value
                                                        color: Theme.primaryText
                                                        font.pixelSize: 14
                                                        font.weight: Font.DemiBold
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                ScrollView {
                    id: shieldScroll
                    clip: true
                    ScrollBar.vertical.policy: ScrollBar.AsNeeded

                    RowLayout {
                        width: Math.max(0, shieldScroll.availableWidth - 56)
                        anchors.horizontalCenter: parent.horizontalCenter
                        anchors.top: parent.top
                        anchors.topMargin: 24
                        anchors.bottomMargin: 20
                        spacing: 18

                        Rectangle {
                            Layout.fillWidth: true
                            Layout.horizontalStretchFactor: 2
                            Layout.alignment: Qt.AlignTop
                            implicitHeight: scamAnalyzer.implicitHeight + 40
                            radius: 13
                            color: Theme.surface
                            border.color: Theme.border

                            ColumnLayout {
                                id: scamAnalyzer
                                anchors.fill: parent
                                anchors.margins: 22
                                spacing: 13

                                RowLayout {
                                    spacing: 12

                                    Rectangle {
                                        Layout.preferredWidth: 42
                                        Layout.preferredHeight: 42
                                        radius: 11
                                        color: "#E9F6EF"

                                        Label {
                                            anchors.centerIn: parent
                                            text: "⬡"
                                            color: Theme.primaryGreen
                                            font.pixelSize: 25
                                        }
                                    }

                                    ColumnLayout {
                                        spacing: 3

                                        Label {
                                            text: "Проверка на мошенничество"
                                            color: Theme.primaryText
                                            font.pixelSize: 20
                                            font.weight: Font.Bold
                                        }

                                        Label {
                                            text: "Анализ обычно занимает несколько секунд"
                                            color: Theme.secondaryText
                                            font.pixelSize: 12
                                        }
                                    }
                                }

                                Label {
                                    Layout.topMargin: 8
                                    text: "Текст, ссылка или номер телефона"
                                    color: Theme.primaryText
                                    font.pixelSize: 14
                                    font.weight: Font.DemiBold
                                }

                                TextArea {
                                    id: scamTextInput
                                    Layout.fillWidth: true
                                    Layout.preferredHeight: 150
                                    placeholderText: "Вставьте подозрительное сообщение или ссылку..."
                                    wrapMode: TextEdit.Wrap
                                    selectByMouse: true
                                    enabled: !window.analysisInProgress
                                    color: Theme.primaryText
                                    font.pixelSize: 14
                                    leftPadding: 13
                                    rightPadding: 13
                                    topPadding: 12
                                    bottomPadding: 12

                                    background: Rectangle {
                                        radius: 9
                                        color: Theme.background
                                        border.color: scamTextInput.activeFocus
                                                       ? Theme.primaryGreen
                                                       : Theme.border
                                    }

                                    onTextChanged: {
                                        window.analysisResult = ""
                                        window.analysisError = ""
                                    }
                                }

                                RowLayout {
                                    Layout.fillWidth: true
                                    spacing: 10

                                    Label {
                                        Layout.fillWidth: true
                                        text: "Мы не сохраняем данные вашей проверки"
                                        color: Theme.secondaryText
                                        font.pixelSize: 12
                                        wrapMode: Text.WordWrap
                                    }

                                    Button {
                                        id: checkScamButton
                                        text: window.analysisInProgress ? "Проверяем..." : "Проверить"
                                        enabled: !window.analysisInProgress
                                                 && scamTextInput.text.trim().length > 0
                                        onClicked: {
                                            window.analysisResult = ""
                                            window.analysisError = ""
                                            window.analysisInProgress = true
                                            apiClient.checkScam(scamTextInput.text)
                                        }

                                        contentItem: Label {
                                            text: checkScamButton.text
                                            color: Theme.surface
                                            font.pixelSize: 14
                                            font.weight: Font.Bold
                                            horizontalAlignment: Text.AlignHCenter
                                            verticalAlignment: Text.AlignVCenter
                                        }

                                        background: Rectangle {
                                            implicitWidth: 130
                                            implicitHeight: 40
                                            radius: 8
                                            color: checkScamButton.enabled
                                                   ? Theme.primaryGreen
                                                   : "#B8C7BF"
                                        }
                                    }
                                }

                                Rectangle {
                                    id: scamResultCard
                                    property bool danger: false
                                    Layout.fillWidth: true
                                    visible: window.analysisResult.length > 0
                                    implicitHeight: resultContent.implicitHeight + 26
                                    radius: 10
                                    color: danger ? "#FFF6F6" : "#F1FAF5"
                                    border.color: danger ? "#F0C5C5" : "#B7E2C9"

                                    RowLayout {
                                        id: resultContent
                                        anchors.fill: parent
                                        anchors.margins: 13
                                        spacing: 10

                                        Label {
                                            text: scamResultCard.danger ? "!" : "✓"
                                            color: scamResultCard.danger ? "#C43D3D" : Theme.primaryGreen
                                            font.pixelSize: 22
                                            font.weight: Font.Bold
                                        }

                                        ColumnLayout {
                                            Layout.fillWidth: true
                                            spacing: 4

                                            Label {
                                                text: window.analysisResult
                                                color: scamResultCard.danger ? "#A82F2F" : "#08743C"
                                                font.pixelSize: 14
                                                font.weight: Font.Bold
                                                wrapMode: Text.WordWrap
                                            }

                                            Label {
                                                id: scamResultDetail
                                                Layout.fillWidth: true
                                                color: "#5F6671"
                                                font.pixelSize: 12
                                                wrapMode: Text.WordWrap
                                            }
                                        }
                                    }
                                }

                                Label {
                                    Layout.fillWidth: true
                                    visible: window.analysisError.length > 0
                                    text: window.analysisError
                                    color: Theme.error
                                    font.pixelSize: 12
                                    wrapMode: Text.WordWrap
                                }
                            }
                        }

                        ColumnLayout {
                            Layout.fillWidth: true
                            Layout.horizontalStretchFactor: 1
                            Layout.alignment: Qt.AlignTop
                            spacing: 14

                            Rectangle {
                                Layout.fillWidth: true
                                implicitHeight: protectionTips.implicitHeight + 36
                                radius: 13
                                color: Theme.surface
                                border.color: Theme.border

                                ColumnLayout {
                                    id: protectionTips
                                    anchors.fill: parent
                                    anchors.margins: 18
                                    spacing: 10

                                    Label {
                                        text: "КАК ЗАЩИТИТЬСЯ"
                                        color: Theme.primaryGreen
                                        font.pixelSize: 12
                                        font.weight: Font.Bold
                                        font.letterSpacing: 1
                                    }

                                    Label {
                                        Layout.fillWidth: true
                                        text: "Банк никогда не просит назвать код из SMS"
                                        color: Theme.primaryText
                                        font.pixelSize: 20
                                        font.weight: Font.Bold
                                        wrapMode: Text.WordWrap
                                    }

                                    Label {
                                        Layout.fillWidth: true
                                        text: "Не передавайте реквизиты карты, пароли и коды подтверждения третьим лицам."
                                        color: Theme.secondaryText
                                        font.pixelSize: 12
                                        lineHeight: 1.35
                                        wrapMode: Text.WordWrap
                                    }
                                }
                            }

                            Rectangle {
                                Layout.fillWidth: true
                                implicitHeight: helpCard.implicitHeight + 36
                                radius: 13
                                color: Theme.surface
                                border.color: Theme.border

                                ColumnLayout {
                                    id: helpCard
                                    anchors.fill: parent
                                    anchors.margins: 18
                                    spacing: 9

                                    Label {
                                        text: "Нужна помощь?"
                                        color: Theme.primaryText
                                        font.pixelSize: 20
                                        font.weight: Font.Bold
                                    }

                                    Label {
                                        Layout.fillWidth: true
                                        text: "Если вы уже сообщили данные, обратитесь в банк по официальному номеру."
                                        color: Theme.secondaryText
                                        font.pixelSize: 12
                                        wrapMode: Text.WordWrap
                                    }
                                }
                            }
                        }
                    }
                }

                ScrollView {
                    id: transfersScroll
                    clip: true
                    ScrollBar.vertical.policy: ScrollBar.AsNeeded

                    RowLayout {
                        width: Math.max(0, transfersScroll.availableWidth - 56)
                        anchors.horizontalCenter: parent.horizontalCenter
                        anchors.top: parent.top
                        anchors.topMargin: 24
                        anchors.bottomMargin: 20
                        spacing: 18

                        Rectangle {
                            Layout.fillWidth: true
                            Layout.horizontalStretchFactor: 2
                            Layout.alignment: Qt.AlignTop
                            implicitHeight: transferForm.implicitHeight + 40
                            radius: 13
                            color: Theme.surface
                            border.color: Theme.border

                            ColumnLayout {
                                id: transferForm
                                anchors.fill: parent
                                anchors.margins: 22
                                spacing: 14

                                RowLayout {
                                    Layout.fillWidth: true
                                    spacing: 8

                                    Label {
                                        text: "На карту"
                                        color: Theme.primaryGreen
                                        font.pixelSize: 14
                                        font.weight: Font.Bold
                                    }

                                    Rectangle {
                                        Layout.preferredWidth: 1
                                        Layout.preferredHeight: 20
                                        color: Theme.border
                                    }

                                    Label {
                                        text: "По номеру телефона"
                                        color: Theme.secondaryText
                                        font.pixelSize: 14
                                    }

                                    Label {
                                        text: "Между счетами"
                                        color: Theme.secondaryText
                                        font.pixelSize: 14
                                    }
                                }

                                Rectangle {
                                    Layout.fillWidth: true
                                    Layout.preferredHeight: 1
                                    color: Theme.border
                                }

                                ColumnLayout {
                                    Layout.fillWidth: true
                                    Layout.topMargin: 7
                                    spacing: 9
                                    visible: !window.transferSent

                                    Label {
                                        text: "Создать тестовую карту"
                                        color: Theme.primaryText
                                        font.pixelSize: 14
                                        font.weight: Font.DemiBold
                                    }

                                    RowLayout {
                                        Layout.fillWidth: true
                                        spacing: 8

                                        TextField {
                                            id: cardOwnerInput
                                            Layout.fillWidth: true
                                            placeholderText: "Имя владельца"
                                            text: "Айдана"
                                            selectByMouse: true
                                            color: Theme.primaryText
                                            font.pixelSize: 14

                                            background: Rectangle {
                                                implicitHeight: 44
                                                radius: 9
                                                color: Theme.background
                                                border.color: cardOwnerInput.activeFocus
                                                               ? Theme.primaryGreen
                                                               : Theme.border
                                            }
                                        }

                                        Button {
                                            id: createCardButton
                                            text: window.cardCreationInProgress
                                                  ? "Создаём..."
                                                  : "Создать тестовую карту"
                                            enabled: !window.cardCreationInProgress
                                                     && cardOwnerInput.text.trim().length > 0
                                            onClicked: {
                                                window.cardCreationInProgress = true
                                                window.cardCreationError = ""
                                                apiClient.createCard(cardOwnerInput.text)
                                            }

                                            contentItem: Label {
                                                text: createCardButton.text
                                                color: Theme.primaryGreen
                                                font.pixelSize: 12
                                                font.weight: Font.Bold
                                                horizontalAlignment: Text.AlignHCenter
                                                verticalAlignment: Text.AlignVCenter
                                            }

                                            background: Rectangle {
                                                implicitWidth: 180
                                                implicitHeight: 44
                                                radius: 8
                                                color: "#E9F6EF"
                                            }
                                        }
                                    }

                                    Label {
                                        Layout.fillWidth: true
                                        visible: window.createdCardNumber.length > 0
                                        text: "Создана тестовая карта: "
                                              + window.createdCardNumber.replace(/(.{4})/g, "$1 ").trim()
                                              + " · баланс "
                                              + Number(window.createdCardBalance).toLocaleString(Qt.locale("ru_RU"))
                                              + " ₸"
                                        color: Theme.primaryGreen
                                        font.pixelSize: 12
                                        wrapMode: Text.WordWrap
                                    }

                                    Label {
                                        Layout.fillWidth: true
                                        visible: window.cardCreationError.length > 0
                                        text: window.cardCreationError
                                        color: Theme.error
                                        font.pixelSize: 12
                                        wrapMode: Text.WordWrap
                                    }

                                    Label {
                                        Layout.topMargin: 5
                                        text: "Номер карты отправителя"
                                        color: Theme.primaryText
                                        font.pixelSize: 14
                                        font.weight: Font.DemiBold
                                    }

                                    TextField {
                                        id: senderCardInput
                                        Layout.fillWidth: true
                                        placeholderText: "0000 0000 0000 0000"
                                        maximumLength: 19
                                        inputMethodHints: Qt.ImhDigitsOnly
                                        selectByMouse: true
                                        color: Theme.primaryText
                                        font.pixelSize: 14
                                        leftPadding: 13

                                        onTextEdited: {
                                            var digits = text.replace(/\D/g, "").slice(0, 16)
                                            text = digits.replace(/(.{4})/g, "$1 ").trim()
                                        }

                                        background: Rectangle {
                                            implicitHeight: 44
                                            radius: 9
                                            color: Theme.background
                                            border.color: senderCardInput.activeFocus
                                                           ? Theme.primaryGreen
                                                           : Theme.border
                                        }
                                    }

                                    Label {
                                        Layout.topMargin: 5
                                        text: "Номер карты получателя"
                                        color: Theme.primaryText
                                        font.pixelSize: 14
                                        font.weight: Font.DemiBold
                                    }

                                    TextField {
                                        id: recipientCardInput
                                        Layout.fillWidth: true
                                        placeholderText: "0000 0000 0000 0000"
                                        maximumLength: 19
                                        inputMethodHints: Qt.ImhDigitsOnly
                                        selectByMouse: true
                                        color: Theme.primaryText
                                        font.pixelSize: 14
                                        leftPadding: 13

                                        onTextEdited: {
                                            var digits = text.replace(/\D/g, "").slice(0, 16)
                                            text = digits.replace(/(.{4})/g, "$1 ").trim()
                                        }

                                        background: Rectangle {
                                            implicitHeight: 44
                                            radius: 9
                                            color: Theme.background
                                            border.color: recipientCardInput.activeFocus
                                                           ? Theme.primaryGreen
                                                           : Theme.border
                                        }
                                    }

                                    Label {
                                        Layout.topMargin: 5
                                        text: "Сумма"
                                        color: Theme.primaryText
                                        font.pixelSize: 14
                                        font.weight: Font.DemiBold
                                    }

                                    TextField {
                                        id: transferAmountInput
                                        Layout.fillWidth: true
                                        placeholderText: "0"
                                        maximumLength: 9
                                        inputMethodHints: Qt.ImhDigitsOnly
                                        selectByMouse: true
                                        color: Theme.primaryText
                                        font.pixelSize: 18
                                        font.weight: Font.Bold
                                        leftPadding: 13
                                        rightPadding: 38

                                        onTextEdited: text = text.replace(/\D/g, "").slice(0, 9)

                                        background: Rectangle {
                                            implicitHeight: 52
                                            radius: 9
                                            color: Theme.background
                                            border.color: transferAmountInput.activeFocus
                                                           ? Theme.primaryGreen
                                                           : Theme.border
                                        }

                                        Label {
                                            anchors.right: parent.right
                                            anchors.rightMargin: 14
                                            anchors.verticalCenter: parent.verticalCenter
                                            text: "₸"
                                            color: Theme.secondaryText
                                            font.pixelSize: 16
                                            font.weight: Font.Bold
                                        }
                                    }

                                    Rectangle {
                                        Layout.fillWidth: true
                                        Layout.topMargin: 3
                                        Layout.preferredHeight: 38
                                        radius: 8
                                        color: Theme.background

                                        RowLayout {
                                            anchors.fill: parent
                                            anchors.leftMargin: 12
                                            anchors.rightMargin: 12

                                            Label {
                                                text: "Комиссия"
                                                color: Theme.secondaryText
                                                font.pixelSize: 12
                                            }

                                            Item {
                                                Layout.fillWidth: true
                                            }

                                            Label {
                                                text: "0 ₸ · демо"
                                                color: Theme.primaryGreen
                                                font.pixelSize: 12
                                                font.weight: Font.Bold
                                            }
                                        }
                                    }

                                    Label {
                                        Layout.fillWidth: true
                                        Layout.topMargin: 2
                                        text: "Демо-режим: перевод выполняется только между тестовыми картами. Реальные деньги не переводятся."
                                        color: Theme.secondaryText
                                        font.pixelSize: 12
                                        wrapMode: Text.WordWrap
                                    }

                                    Label {
                                        Layout.fillWidth: true
                                        visible: window.transferMessage.length > 0
                                        text: window.transferMessage
                                        color: window.transferSucceeded
                                               ? Theme.primaryGreen
                                               : Theme.error
                                        font.pixelSize: 12
                                        wrapMode: Text.WordWrap
                                    }

                                    Button {
                                        id: transferButton
                                        Layout.fillWidth: true
                                        Layout.topMargin: 3
                                        text: window.transferInProgress
                                              ? "Выполняется..."
                                              : "Перевести"
                                        enabled: !window.transferInProgress
                                                 && senderCardInput.text.replace(/\D/g, "").length === 16
                                                 && recipientCardInput.text.replace(/\D/g, "").length === 16
                                                 && Number(transferAmountInput.text) > 0
                                        onClicked: {
                                            window.transferMessage = ""
                                            window.transferInProgress = true
                                            apiClient.transfer(
                                                senderCardInput.text,
                                                recipientCardInput.text,
                                                Number(transferAmountInput.text))
                                        }

                                        contentItem: Label {
                                            text: transferButton.text
                                            color: Theme.surface
                                            font.pixelSize: 14
                                            font.weight: Font.Bold
                                            horizontalAlignment: Text.AlignHCenter
                                            verticalAlignment: Text.AlignVCenter
                                        }

                                        background: Rectangle {
                                            implicitHeight: 44
                                            radius: 8
                                            color: transferButton.enabled
                                                   ? Theme.primaryGreen
                                                   : "#B8C7BF"
                                        }
                                    }
                                }

                                ColumnLayout {
                                    Layout.fillWidth: true
                                    Layout.fillHeight: true
                                    Layout.minimumHeight: 300
                                    visible: window.transferSent
                                    spacing: 10

                                    Item {
                                        Layout.fillHeight: true
                                    }

                                    Label {
                                        Layout.alignment: Qt.AlignHCenter
                                        text: "✓"
                                        color: Theme.primaryGreen
                                        font.pixelSize: 46
                                        font.weight: Font.Bold
                                    }

                                    Label {
                                        Layout.alignment: Qt.AlignHCenter
                                        text: "Демо-перевод выполнен"
                                        color: Theme.primaryText
                                        font.pixelSize: 20
                                        font.weight: Font.Bold
                                    }

                                    Label {
                                        Layout.fillWidth: true
                                        Layout.alignment: Qt.AlignHCenter
                                        text: window.transferMessage
                                        color: Theme.secondaryText
                                        font.pixelSize: 12
                                        horizontalAlignment: Text.AlignHCenter
                                        wrapMode: Text.WordWrap
                                    }

                                    Button {
                                        Layout.alignment: Qt.AlignHCenter
                                        text: "Новый демо-перевод"
                                        onClicked: {
                                            window.transferSent = false
                                            window.transferMessage = ""
                                            transferAmountInput.clear()
                                        }
                                    }

                                    Item {
                                        Layout.fillHeight: true
                                    }
                                }
                            }
                        }

                        ColumnLayout {
                            Layout.fillWidth: true
                            Layout.horizontalStretchFactor: 1
                            Layout.alignment: Qt.AlignTop
                            spacing: 14

                            Rectangle {
                                Layout.fillWidth: true
                                implicitHeight: accountSummary.implicitHeight + 36
                                radius: 13
                                color: Theme.surface
                                border.color: Theme.border

                                ColumnLayout {
                                    id: accountSummary
                                    anchors.fill: parent
                                    anchors.margins: 18
                                    spacing: 10

                                    Label {
                                        text: "Списать со счета"
                                        color: Theme.secondaryText
                                        font.pixelSize: 12
                                    }

                                    RowLayout {
                                        Layout.fillWidth: true
                                        spacing: 9

                                        Rectangle {
                                            Layout.preferredWidth: 44
                                            Layout.preferredHeight: 36
                                            radius: 7
                                            color: Theme.primaryGreen

                                            Label {
                                                anchors.centerIn: parent
                                                text: "BCC"
                                                color: Theme.surface
                                                font.pixelSize: 12
                                                font.weight: Font.Bold
                                            }
                                        }

                                        ColumnLayout {
                                            Layout.fillWidth: true
                                            spacing: 2

                                            Label {
                                                text: "Основной демо-счет"
                                                color: Theme.primaryText
                                                font.pixelSize: 14
                                                font.weight: Font.Bold
                                            }

                                            Label {
                                                text: "•••• 4821"
                                                color: Theme.secondaryText
                                                font.pixelSize: 12
                                            }
                                        }
                                    }

                                    Rectangle {
                                        Layout.fillWidth: true
                                        Layout.preferredHeight: 1
                                        color: Theme.border
                                    }

                                    Label {
                                        text: "Доступно в демо"
                                        color: Theme.secondaryText
                                        font.pixelSize: 12
                                    }

                                    Label {
                                        text: "100 000 ₸"
                                        color: Theme.primaryText
                                        font.pixelSize: 18
                                        font.weight: Font.Bold
                                    }
                                }
                            }

                            Rectangle {
                                Layout.fillWidth: true
                                implicitHeight: safeTransferText.implicitHeight + 30
                                radius: 11
                                color: "#EDF7F2"

                                Label {
                                    id: safeTransferText
                                    anchors.fill: parent
                                    anchors.margins: 15
                                    text: "<b>Безопасный перевод</b><br>Проверяйте имя получателя перед подтверждением операции. Это учебный пример."
                                    color: "#426151"
                                    font.pixelSize: 12
                                    lineHeight: 1.4
                                    textFormat: Text.RichText
                                    wrapMode: Text.WordWrap
                                }
                            }
                        }
                    }
                }

                ScrollView {
                    id: activityScroll
                    clip: true
                    ScrollBar.vertical.policy: ScrollBar.AsNeeded

                    ColumnLayout {
                        width: Math.max(0, activityScroll.availableWidth - 56)
                        anchors.horizontalCenter: parent.horizontalCenter
                        anchors.top: parent.top
                        anchors.topMargin: 24
                        anchors.bottomMargin: 20
                        spacing: 14

                        Rectangle {
                            Layout.fillWidth: true
                            implicitHeight: activityToolbar.implicitHeight + 32
                            radius: 12
                            color: Theme.surface
                            border.color: Theme.border

                            RowLayout {
                                id: activityToolbar
                                anchors.fill: parent
                                anchors.margins: 16
                                spacing: 8

                                Repeater {
                                    model: ["Все операции", "Доходы", "Расходы"]

                                    delegate: Button {
                                        id: filterButton
                                        required property int index
                                        required property string modelData
                                        text: modelData
                                        checked: window.activityFilter === index
                                        onClicked: window.activityFilter = index

                                        contentItem: Label {
                                            text: filterButton.text
                                            color: filterButton.checked ? Theme.primaryGreen : Theme.secondaryText
                                            font.pixelSize: 14
                                            font.weight: filterButton.checked ? Font.Bold : Font.Medium
                                            horizontalAlignment: Text.AlignHCenter
                                            verticalAlignment: Text.AlignVCenter
                                        }

                                        background: Rectangle {
                                            implicitHeight: 34
                                            radius: 7
                                            color: filterButton.checked ? "#E9F6EF" : "transparent"
                                        }
                                    }
                                }

                                Item {
                                    Layout.fillWidth: true
                                }

                                TextField {
                                    id: activitySearch
                                    Layout.preferredWidth: 190
                                    placeholderText: "⌕  Поиск операции"
                                    selectByMouse: true
                                    color: Theme.primaryText
                                    font.pixelSize: 14
                                    leftPadding: 10

                                    background: Rectangle {
                                        implicitHeight: 36
                                        radius: 7
                                        color: Theme.surface
                                        border.color: Theme.border
                                    }
                                }
                            }
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            implicitHeight: activityList.implicitHeight + 30
                            radius: 12
                            color: Theme.surface
                            border.color: Theme.border

                            ColumnLayout {
                                id: activityList
                                anchors.fill: parent
                                anchors.margins: 16
                                spacing: 0

                                Label {
                                    text: "ДЕМОНСТРАЦИОННЫЕ ОПЕРАЦИИ"
                                    color: Theme.secondaryText
                                    font.pixelSize: 12
                                    font.weight: Font.Bold
                                    font.letterSpacing: 0.8
                                }

                                Repeater {
                                    model: window.visibleTransactionItems

                                    delegate: transactionRow
                                }

                                Label {
                                    Layout.fillWidth: true
                                    Layout.topMargin: 14
                                    visible: window.visibleTransactionItems.length === 0
                                    text: "Операции не найдены"
                                    color: Theme.secondaryText
                                    font.pixelSize: 14
                                    horizontalAlignment: Text.AlignHCenter
                                }
                            }
                        }
                    }
                }
                ScrollView {
                    id: securityScroll
                    clip: true
                    ScrollBar.vertical.policy: ScrollBar.AsNeeded

                    ColumnLayout {
                        width: Math.max(0, securityScroll.availableWidth - 56)
                        anchors.horizontalCenter: parent.horizontalCenter
                        spacing: 16

                        SecureStorePanel {
                            Layout.fillWidth: true
                            Layout.preferredHeight: 320
                        }
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true
                Layout.preferredHeight: 34
                Layout.leftMargin: 28
                Layout.rightMargin: 28
                spacing: 8

                Label {
                    text: "© 2025 Банк ЦентрКредит · Демо-прототип"
                    color: "#9AA0A9"
                    font.pixelSize: 12
                }

                Item {
                    Layout.fillWidth: true
                }

                Label {
                    text: "Безопасное соединение · RU"
                    color: "#9AA0A9"
                    font.pixelSize: 12
                }
            }
        }
    }

    Component {
        id: transactionRow

        RowLayout {
            id: transactionRowDelegate
            required property var modelData
            Layout.fillWidth: true
            Layout.preferredHeight: 62
            spacing: 10

            Rectangle {
                Layout.preferredWidth: 36
                Layout.preferredHeight: 36
                radius: 9
                color: transactionRowDelegate.modelData.incoming ? "#E9F6EF" : "#F3F5F7"

                Label {
                    anchors.centerIn: parent
                    text: transactionRowDelegate.modelData.marker
                    color: transactionRowDelegate.modelData.incoming ? Theme.primaryGreen : Theme.secondaryText
                    font.pixelSize: 15
                }
            }

            ColumnLayout {
                Layout.fillWidth: true
                spacing: 3

                Label {
                    Layout.fillWidth: true
                    text: transactionRowDelegate.modelData.title
                    color: Theme.primaryText
                    font.pixelSize: 14
                    font.weight: Font.DemiBold
                    elide: Text.ElideRight
                }

                Label {
                    Layout.fillWidth: true
                    text: transactionRowDelegate.modelData.detail
                    color: Theme.secondaryText
                    font.pixelSize: 12
                    elide: Text.ElideRight
                }
            }

            Label {
                text: transactionRowDelegate.modelData.amount
                color: transactionRowDelegate.modelData.incoming ? Theme.primaryGreen : Theme.primaryText
                font.pixelSize: 14
                font.weight: Font.Bold
                horizontalAlignment: Text.AlignRight
            }
        }
    }
}

