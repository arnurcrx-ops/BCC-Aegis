#include <QCoreApplication>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQuickStyle>
#include <qqml.h>
#include <QTimer>

#include "ApiClient.h"
#include "security/SecureStore.h"

int main(int argc, char *argv[])
{
    QQuickStyle::setStyle(QStringLiteral("Basic"));
    QGuiApplication app(argc, argv);
    QQmlApplicationEngine engine;
    const bool smokeTest = app.arguments().contains(QStringLiteral("--smoke-test"));

    qmlRegisterType<ApiClient>("KiberQalqan", 1, 0, "ApiClient");
    qmlRegisterType<SecureStore>("KiberQalqan", 1, 0, "SecureStore");

    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreated,
        &app,
        [&app, smokeTest](QObject *object, const QUrl &) {
            if (object == nullptr) {
                QCoreApplication::exit(EXIT_FAILURE);
            } else if (smokeTest) {
                QTimer::singleShot(0, &app, &QCoreApplication::quit);
            }
        },
        Qt::QueuedConnection);

    engine.loadFromModule("BccDesktop", "Main");
    return app.exec();
}