#include "ApiClient.h"

#include <cmath>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QRegularExpression>
#include <QUrl>

namespace {

QNetworkRequest jsonRequest(const QString &path)
{
    QNetworkRequest request(QUrl(QStringLiteral("http://127.0.0.1:8000") + path));
    request.setHeader(QNetworkRequest::ContentTypeHeader,
                      QStringLiteral("application/json; charset=utf-8"));
    return request;
}

bool parseResponse(const QByteArray &body, QJsonObject &response)
{
    QJsonParseError parseError;
    const QJsonDocument document = QJsonDocument::fromJson(body, &parseError);
    if (parseError.error != QJsonParseError::NoError || !document.isObject())
    {
        return false;
    }

    response = document.object();
    return true;
}

QString replyFailure(int statusCode,
                     QNetworkReply::NetworkError networkError,
                     const QString &networkErrorText,
                     const QByteArray &body,
                     const QString &operation)
{
    if (statusCode >= 400)
    {
        QJsonObject response;
        QString detail;
        if (parseResponse(body, response))
        {
            const QJsonValue error = response.value(QStringLiteral("error"));
            const QJsonValue apiDetail = response.value(QStringLiteral("detail"));
            if (error.isString())
                detail = error.toString();
            else if (apiDetail.isString())
                detail = apiDetail.toString();
        }

        return detail.isEmpty()
                   ? QStringLiteral("%1. Ошибка сервера HTTP %2.")
                         .arg(operation)
                         .arg(statusCode)
                   : QStringLiteral("%1. Ошибка сервера HTTP %2: %3")
                         .arg(operation)
                         .arg(statusCode)
                         .arg(detail);
    }

    if (networkError != QNetworkReply::NoError)
    {
        return QStringLiteral("%1: %2").arg(operation, networkErrorText);
    }

    if (statusCode < 200 || statusCode >= 300)
        return QStringLiteral("%1. Сервер вернул ошибку HTTP %2.")
            .arg(operation)
            .arg(statusCode);

    return {};
}

} // namespace

ApiClient::ApiClient(QObject *parent)
    : QObject(parent)
{
    networkManager_.setTransferTimeout(15000);
}

void ApiClient::checkScam(const QString &text)
{
    if (text.trimmed().isEmpty())
    {
        emit requestFailed(QStringLiteral("Введите текст для проверки."));
        return;
    }

    const QUrl url(QStringLiteral("http://127.0.0.1:8000/analyze"));
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader,
                      QStringLiteral("application/json; charset=utf-8"));

    QJsonObject payload;
    payload.insert(QStringLiteral("text"), text);
    const QByteArray body = QJsonDocument(payload).toJson(QJsonDocument::Compact);

    QNetworkReply *reply = networkManager_.post(request, body);
    connect(reply, &QNetworkReply::finished, this, [this, reply] {
        const QByteArray responseBody = reply->readAll();
        const auto networkError = reply->error();
        const QString networkErrorText = reply->errorString();
        const int statusCode =
            reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        reply->deleteLater();

        const QString failure = replyFailure(
            statusCode, networkError, networkErrorText, responseBody,
            QStringLiteral("Не удалось выполнить проверку"));
        if (!failure.isEmpty())
        {
            emit requestFailed(failure);
            return;
        }

        QJsonParseError parseError;
        const QJsonDocument document =
            QJsonDocument::fromJson(responseBody, &parseError);
        if (parseError.error != QJsonParseError::NoError ||
            !document.isObject())
        {
            emit requestFailed(
                QStringLiteral("Сервер вернул некорректный ответ."));
            return;
        }

        const QJsonObject response = document.object();
        const QJsonValue isScamValue = response.value(QStringLiteral("is_scam"));
        if (!isScamValue.isBool())
        {
            emit requestFailed(
                QStringLiteral("В ответе сервера отсутствует результат проверки."));
            return;
        }

        const QJsonValue reasonValue = response.value(QStringLiteral("reason"));
        if (!reasonValue.isUndefined() && !reasonValue.isString())
        {
            emit requestFailed(
                QStringLiteral("Сервер вернул некорректный результат проверки."));
            return;
        }

        const bool isScam = isScamValue.toBool();
        emit scamResult(isScam, reasonValue.toString());
    });
}

void ApiClient::createCard(QString ownerName)
{
    if (ownerName.trimmed().isEmpty())
    {
        emit cardCreationFailed(QStringLiteral("Укажите имя владельца карты."));
        return;
    }

    QJsonObject payload;
    payload.insert(QStringLiteral("owner_name"), ownerName.trimmed());
    const QByteArray body = QJsonDocument(payload).toJson(QJsonDocument::Compact);
    QNetworkReply *reply = networkManager_.post(
        jsonRequest(QStringLiteral("/create_card")), body);

    connect(reply, &QNetworkReply::finished, this, [this, reply] {
        const QByteArray responseBody = reply->readAll();
        const auto networkError = reply->error();
        const QString networkErrorText = reply->errorString();
        const int statusCode =
            reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        reply->deleteLater();

        const QString failure = replyFailure(
            statusCode, networkError, networkErrorText, responseBody,
            QStringLiteral("Не удалось создать демо-карту"));
        if (!failure.isEmpty())
        {
            emit cardCreationFailed(failure);
            return;
        }

        QJsonObject response;
        if (!parseResponse(responseBody, response))
        {
            emit cardCreationFailed(
                QStringLiteral("Сервер вернул некорректный ответ при создании карты."));
            return;
        }

        const QJsonValue cardNumber = response.value(QStringLiteral("card_number"));
        const QJsonValue balance = response.value(QStringLiteral("balance"));
        if (response.value(QStringLiteral("status")).toString() !=
                QStringLiteral("ok") ||
            !cardNumber.isString() || !balance.isDouble())
        {
            emit cardCreationFailed(
                QStringLiteral("В ответе сервера отсутствуют данные созданной карты."));
            return;
        }

        emit cardCreated(cardNumber.toString(), balance.toDouble());
    });
}

void ApiClient::transfer(QString senderCard, QString receiverCard, double amount)
{
    senderCard.remove(QRegularExpression(QStringLiteral("\\s")));
    receiverCard.remove(QRegularExpression(QStringLiteral("\\s")));

    if (senderCard.size() != 16 || receiverCard.size() != 16)
    {
        emit transferResult(false,
                            QStringLiteral("Введите номера обеих карт (16 цифр)."));
        return;
    }
    if (senderCard == receiverCard)
    {
        emit transferResult(
            false,
            QStringLiteral("Карты отправителя и получателя должны различаться."));
        return;
    }
    if (!std::isfinite(amount) || amount <= 0.0)
    {
        emit transferResult(false,
                            QStringLiteral("Сумма должна быть больше нуля."));
        return;
    }

    QJsonObject payload;
    payload.insert(QStringLiteral("sender_card"), senderCard);
    payload.insert(QStringLiteral("receiver_card"), receiverCard);
    payload.insert(QStringLiteral("amount"), amount);
    const QByteArray body = QJsonDocument(payload).toJson(QJsonDocument::Compact);
    QNetworkReply *reply =
        networkManager_.post(jsonRequest(QStringLiteral("/transfer")), body);

    connect(reply, &QNetworkReply::finished, this, [this, reply] {
        const QByteArray responseBody = reply->readAll();
        const auto networkError = reply->error();
        const QString networkErrorText = reply->errorString();
        const int statusCode =
            reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        reply->deleteLater();

        const QString failure = replyFailure(
            statusCode, networkError, networkErrorText, responseBody,
            QStringLiteral("Не удалось выполнить перевод"));
        if (!failure.isEmpty())
        {
            emit transferResult(false, failure);
            return;
        }

        QJsonObject response;
        if (!parseResponse(responseBody, response))
        {
            emit transferResult(
                false, QStringLiteral("Сервер вернул некорректный ответ при переводе."));
            return;
        }

        const QJsonValue newBalance =
            response.value(QStringLiteral("new_balance"));
        if (response.value(QStringLiteral("status")).toString() !=
                QStringLiteral("ok") ||
            !newBalance.isDouble())
        {
            emit transferResult(
                false, QStringLiteral("В ответе сервера отсутствует новый баланс."));
            return;
        }

        emit transferResult(
            true,
            QStringLiteral("Перевод выполнен. Остаток: %1 ₸")
                .arg(newBalance.toDouble(), 0, 'f', 2));
    });
}
