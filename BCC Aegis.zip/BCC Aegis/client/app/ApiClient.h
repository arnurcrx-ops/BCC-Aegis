#pragma once

#include <QObject>
#include <QNetworkAccessManager>
#include <QString>

class ApiClient : public QObject
{
    Q_OBJECT

public:
    explicit ApiClient(QObject *parent = nullptr);

    Q_INVOKABLE void checkScam(const QString &text);
    Q_INVOKABLE void createCard(QString ownerName);
    Q_INVOKABLE void transfer(QString senderCard, QString receiverCard, double amount);

signals:
    void scamResult(bool isScam, const QString &reason);
    void requestFailed(const QString &error);
    void cardCreated(QString cardNumber, double balance);
    void cardCreationFailed(QString message);
    void transferResult(bool success, QString message);

private:
    QNetworkAccessManager networkManager_;
};
