"""Записи звонков: аудио + расшифровка + поиск фраз мошенников.

Поток данных:
  1. ARI-мост записывает разговор (ARI bridge record), забирает WAV и отправляет сюда:
     POST /api/v1/recordings  (тело = WAV, метаданные в query).
  2. Сервис transcriber берёт запись из очереди (GET /api/v1/recordings/pending),
     расшифровывает офлайн (faster-whisper) и возвращает текст
     (POST /api/v1/recordings/{id}/transcript).
  3. Здесь текст проверяется на типичные фразы телефонных мошенников; результат
     попадает в базу (SQLite) и в журнал событий консоли.

Всё хранится локально в DATA_DIR (по умолчанию /data): aegis.db и recordings/*.wav.
Доступ ко всем эндпоинтам только по X-API-Key. Записи старше RECORDINGS_RETENTION_DAYS
дней удаляются автоматически (0 = не удалять).
"""
import json
import logging
import os
import re
import secrets
import sqlite3
import threading
import time
from contextlib import contextmanager
from pathlib import Path

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request, status
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

log = logging.getLogger("aegis.recordings")

DATA_DIR = Path(os.getenv("DATA_DIR", "/data"))
REC_DIR = DATA_DIR / "recordings"
DB_PATH = DATA_DIR / "aegis.db"
API_KEY = os.environ.get("AEGIS_API_KEY", "")
RETENTION_DAYS = float(os.getenv("RECORDINGS_RETENTION_DAYS", "7"))
MAX_AUDIO_BYTES = 60 * 1024 * 1024
MIN_AUDIO_BYTES = 4000        # меньше: тишина/обрыв, расшифровывать нечего
MIN_DURATION_S = 2
LEASE_S = 600                 # сколько запись «занята» транскрайбером, потом вернётся в очередь
TRANSCRIPT_MAX = 100_000

router = APIRouter()

_events = None   # deque журнала событий из main.py
_lock = None     # threading.Lock из main.py
_purger_started = False


def require_key(x_api_key: str = Header(default="")):
    if not API_KEY or not secrets.compare_digest(x_api_key.encode(), API_KEY.encode()):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "invalid api key")


# ---------- база ----------

SCHEMA = """
CREATE TABLE IF NOT EXISTS recordings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  call_id TEXT NOT NULL,
  endpoint TEXT NOT NULL,
  dest TEXT NOT NULL DEFAULT '',
  external INTEGER NOT NULL DEFAULT 0,
  answered INTEGER NOT NULL DEFAULT 0,
  duration_s INTEGER NOT NULL DEFAULT 0,
  created REAL NOT NULL,
  audio_file TEXT NOT NULL,
  size_bytes INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL,
  lease_until REAL NOT NULL DEFAULT 0,
  transcript TEXT NOT NULL DEFAULT '',
  language TEXT NOT NULL DEFAULT '',
  flags TEXT NOT NULL DEFAULT '[]',
  score INTEGER NOT NULL DEFAULT 0,
  verdict TEXT NOT NULL DEFAULT '',
  error TEXT NOT NULL DEFAULT '',
  transcribed REAL NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_rec_status ON recordings(status, id);
CREATE INDEX IF NOT EXISTS idx_rec_created ON recordings(created);
"""

_init_lock = threading.Lock()
_inited = False


def init_db() -> None:
    global _inited
    with _init_lock:
        if _inited:
            return
        REC_DIR.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(DB_PATH, timeout=10)
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.executescript(SCHEMA)
            conn.commit()
        finally:
            conn.close()
        _inited = True


@contextmanager
def db():
    init_db()
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _public(r: sqlite3.Row) -> dict:
    return {
        "id": r["id"], "call_id": r["call_id"], "endpoint": r["endpoint"], "dest": r["dest"],
        "external": bool(r["external"]), "answered": bool(r["answered"]),
        "duration_s": r["duration_s"], "created": r["created"], "status": r["status"],
        "transcript": r["transcript"], "language": r["language"],
        "flags": json.loads(r["flags"] or "[]"), "score": r["score"], "verdict": r["verdict"],
        "error": r["error"], "size_bytes": r["size_bytes"],
    }


def _audio_path(name: str) -> Path | None:
    """Путь к файлу строго внутри REC_DIR (имя генерирует сервер, но проверяем всё равно)."""
    p = (REC_DIR / name).resolve()
    if REC_DIR.resolve() not in p.parents:
        return None
    return p


# ---------- анализ текста ----------

# (флаг, вес, шаблоны). Текст нормализуется: нижний регистр, ё->е, лишние пробелы убраны.
RULES: list[tuple[str, int, list[str]]] = [
    ("sms_code", 40, [
        r"код\w* (из|от) ?(смс|sms|сообщени)", r"(смс|sms) ?-? ?код", r"код\w* подтвержден",
        r"пришедш\w+ (вам )?код", r"(назовите|продиктуйте|скажите|сообщите) (мне )?(этот |тот )?код",
        r"растау код", r"смс ?-?код",
    ]),
    ("safe_account", 50, [
        r"безопасн\w+ счет", r"защищенн\w+ счет", r"резервн\w+ счет", r"единый безопасный",
        r"қауіпсіз шот",
    ]),
    ("bank_impersonation", 25, [
        r"служб\w+ безопасност", r"сотрудник\w* (банка|безопасности|службы)",
        r"безопасност\w+ банка", r"центральн\w+ банк", r"следственн\w+ комитет", r"правоохранительн",
        r"банк қызметкері", r"қауіпсіздік қызмет",
    ]),
    ("remote_access", 40, [
        r"any ?desk", r"team ?viewer", r"rust ?desk", r"удаленн\w+ доступ",
        r"(установите|скачайте|загрузите) (себе )?(это )?приложение", r"қашықтан қолжетімділік",
    ]),
    ("card_data", 40, [
        r"номер\w* (вашей )?(банковской )?карт", r"\bcv[vc]\b", r"срок действия карт",
        r"пин ?-?код", r"три цифры на обороте", r"3 цифры на обороте", r"картаның нөмірі",
    ]),
    ("urgent_transfer", 25, [
        r"переведите", r"перевести (все )?(деньги|средства)", r"снимите (все )?(деньги|налич)",
        r"срочн\w+ перевод", r"перевод\w* на (другой |безопасный |резервный )?счет",
    ]),
    ("pressure", 15, [
        r"никому не говорите", r"не говорите никому", r"прямо сейчас", r"немедленно", r"срочно",
        r"иначе (счет|карту) (будет )?(заблокирован|списан)",
    ]),
    ("loan_pressure", 25, [
        r"(оформите|возьмите|взять|оформить) кредит", r"кредит на ваше имя", r"заявк\w+ на кредит",
    ]),
]
_COMPILED = [(flag, w, [re.compile(p) for p in pats]) for flag, w, pats in RULES]


def normalize(text: str) -> str:
    t = text.lower().replace("ё", "е")
    return re.sub(r"\s+", " ", t).strip()


def verdict_for(score: int) -> str:
    if score >= 70:
        return "SHADOW_HOLD"
    if score >= 40:
        return "REVIEW"
    return "ALLOW"


def analyze(text: str) -> tuple[list[str], int]:
    """Возвращает (список сработавших признаков, риск 0..100)."""
    t = normalize(text)
    flags, total = [], 0
    for flag, weight, pats in _COMPILED:
        if any(p.search(t) for p in pats):
            flags.append(flag)
            total += weight
    return flags, min(total, 100)


# ---------- связка с main.py ----------

def configure(events, lock) -> None:
    """Вызывается из main.py: журнал событий консоли и его замок + фоновая очистка."""
    global _events, _lock, _purger_started
    _events, _lock = events, lock
    init_db()
    if RETENTION_DAYS > 0 and not _purger_started:
        _purger_started = True
        threading.Thread(target=_purge_loop, daemon=True, name="rec-purge").start()


def _push_event(r: dict) -> None:
    if _events is None or _lock is None:
        return
    ev = {"ts": time.time(), "kind": "transcript", "call_id": r["call_id"], "endpoint": r["endpoint"],
          "dest": r["dest"], "external": r["external"], "score": r["score"], "verdict": r["verdict"],
          "signals": r["flags"]}
    with _lock:
        _events.append(ev)


def purge(now: float | None = None) -> int:
    """Удаляет записи старше срока хранения. Возвращает число удалённых."""
    if RETENTION_DAYS <= 0:
        return 0
    cutoff = (now or time.time()) - RETENTION_DAYS * 86400
    n = 0
    with db() as c:
        rows = c.execute("SELECT id, audio_file FROM recordings WHERE created < ?", (cutoff,)).fetchall()
        for r in rows:
            p = _audio_path(r["audio_file"])
            if p:
                try:
                    p.unlink(missing_ok=True)
                except OSError as e:
                    log.warning("не удалось удалить %s: %s", p, e)
            c.execute("DELETE FROM recordings WHERE id = ?", (r["id"],))
            n += 1
    if n:
        log.info("удалено записей по сроку хранения: %d", n)
    return n


def _purge_loop() -> None:
    while True:
        try:
            purge()
        except Exception as e:  # noqa: BLE001
            log.warning("purge: %s", e)
        time.sleep(3600)


# ---------- API ----------

@router.post("/api/v1/recordings", dependencies=[Depends(require_key)])
async def ingest(
    request: Request,
    call_id: str = Query(min_length=1, max_length=64),
    endpoint: str = Query(min_length=1, max_length=64),
    dest: str = Query("", max_length=32),
    duration_s: int = Query(0, ge=0, le=86_400),
    answered: bool = Query(False),
    external: bool = Query(False),
):
    """Принимает WAV-запись разговора (тело запроса) от ARI-моста."""
    declared = request.headers.get("content-length")
    if declared and declared.isdigit() and int(declared) > MAX_AUDIO_BYTES:
        raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "audio too large")
    body = await request.body()
    if len(body) > MAX_AUDIO_BYTES:
        raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "audio too large")
    if len(body) < 44 or body[:4] != b"RIFF":
        raise HTTPException(status.HTTP_415_UNSUPPORTED_MEDIA_TYPE, "WAV expected")

    name = f"rec_{int(time.time())}_{secrets.token_hex(4)}.wav"
    init_db()
    (REC_DIR / name).write_bytes(body)
    skip = (not answered) or len(body) < MIN_AUDIO_BYTES or duration_s < MIN_DURATION_S
    with db() as c:
        cur = c.execute(
            "INSERT INTO recordings (call_id, endpoint, dest, external, answered, duration_s, created,"
            " audio_file, size_bytes, status) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (call_id, endpoint, dest, int(external), int(answered), duration_s, time.time(),
             name, len(body), "skipped" if skip else "pending"))
        rid = cur.lastrowid
    log.info("запись #%s принята: %s -> %s, %d байт, %s", rid, endpoint, dest, len(body),
             "пропущена" if skip else "в очередь на расшифровку")
    return {"id": rid, "status": "skipped" if skip else "pending"}


@router.get("/api/v1/recordings/pending", dependencies=[Depends(require_key)])
def pending(limit: int = Query(1, ge=1, le=10)):
    """Очередь для transcriber: выдаёт записи и помечает их «в работе» на LEASE_S секунд."""
    now = time.time()
    with db() as c:
        c.execute("UPDATE recordings SET status='pending' WHERE status='processing' AND lease_until < ?", (now,))
        rows = c.execute("SELECT * FROM recordings WHERE status='pending' ORDER BY id LIMIT ?", (limit,)).fetchall()
        for r in rows:
            c.execute("UPDATE recordings SET status='processing', lease_until=? WHERE id=?", (now + LEASE_S, r["id"]))
    return {"items": [_public(r) for r in rows]}


@router.get("/api/v1/recordings", dependencies=[Depends(require_key)])
def list_recordings(limit: int = Query(50, ge=1, le=200)):
    with db() as c:
        rows = c.execute("SELECT * FROM recordings ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return {"items": [_public(r) for r in rows], "retention_days": RETENTION_DAYS}


@router.get("/api/v1/recordings/{rec_id}/audio", dependencies=[Depends(require_key)])
def audio(rec_id: int):
    with db() as c:
        r = c.execute("SELECT audio_file FROM recordings WHERE id=?", (rec_id,)).fetchone()
    p = _audio_path(r["audio_file"]) if r else None
    if not p or not p.is_file():
        raise HTTPException(status.HTTP_404_NOT_FOUND, "no audio")
    return FileResponse(p, media_type="audio/wav", headers={"Cache-Control": "no-store"})


class TranscriptIn(BaseModel):
    text: str = Field(default="", max_length=TRANSCRIPT_MAX)
    language: str = Field(default="", max_length=16)
    error: str = Field(default="", max_length=300)


@router.post("/api/v1/recordings/{rec_id}/transcript", dependencies=[Depends(require_key)])
def set_transcript(rec_id: int, t: TranscriptIn):
    if t.error:
        with db() as c:
            cur = c.execute("UPDATE recordings SET status='error', error=?, lease_until=0 WHERE id=?",
                            (t.error, rec_id))
        if not cur.rowcount:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "no such recording")
        return {"ok": True, "status": "error"}

    flags, score = analyze(t.text)
    verdict = verdict_for(score)
    with db() as c:
        cur = c.execute(
            "UPDATE recordings SET status='done', transcript=?, language=?, flags=?, score=?, verdict=?,"
            " error='', lease_until=0, transcribed=? WHERE id=?",
            (t.text, t.language, json.dumps(flags), score, verdict, time.time(), rec_id))
        if not cur.rowcount:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "no such recording")
        row = c.execute("SELECT * FROM recordings WHERE id=?", (rec_id,)).fetchone()
    pub = _public(row)
    _push_event(pub)
    logging.getLogger("aegis.audit").info(json.dumps({
        "ts": int(time.time()), "kind": "transcript", "subject": f"{pub['endpoint']}/{pub['call_id']}",
        "score": score, "verdict": verdict, "signals": flags}))
    return {"ok": True, "status": "done", "score": score, "verdict": verdict, "flags": flags}


@router.delete("/api/v1/recordings/{rec_id}", dependencies=[Depends(require_key)])
def delete_recording(rec_id: int):
    with db() as c:
        r = c.execute("SELECT audio_file FROM recordings WHERE id=?", (rec_id,)).fetchone()
        if not r:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "no such recording")
        p = _audio_path(r["audio_file"])
        if p:
            try:
                p.unlink(missing_ok=True)
            except OSError as e:
                log.warning("не удалось удалить %s: %s", p, e)
        c.execute("DELETE FROM recordings WHERE id=?", (rec_id,))
    return {"ok": True}
