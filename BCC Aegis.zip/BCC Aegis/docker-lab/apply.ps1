﻿# Установка записи звонков и расшифровки в BCC Aegis.
# Запускать из папки проекта docker-lab:
#   cd "C:\Users\arnur\Desktop\BCC Aegis\docker-lab"
#   & "$env:TEMP\aegis-rec\apply.ps1"
# Старые файлы сохраняются в папку backup-before-recording-<дата>.

$src = $PSScriptRoot
$dst = (Get-Location).Path

foreach ($f in "docker-compose.yml", "Dockerfile", "main.py", "ari_bridge.py", "dashboard.html") {
    if (-not (Test-Path (Join-Path $dst $f))) {
        throw "Запустите скрипт из папки docker-lab: здесь нет файла $f."
    }
}
foreach ($f in "docker-compose.yml", "Dockerfile", "Dockerfile.transcriber", "requirements-transcriber.txt", "ari_bridge.py", "recordings.py", "transcriber.py", "dashboard.html") {
    if (-not (Test-Path (Join-Path $src $f))) {
        throw "В папке со скриптом ($src) нет файла $f. Распакуйте архив целиком."
    }
}

docker info 2>&1 | Out-Null
if ($LASTEXITCODE -ne 0) { throw "Docker Desktop не запущен. Запустите его и повторите." }

# 1. Резервная копия
$bk = Join-Path $dst ("backup-before-recording-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
New-Item -ItemType Directory -Path $bk | Out-Null
foreach ($f in "docker-compose.yml", "Dockerfile", "main.py", "ari_bridge.py", "dashboard.html") {
    Copy-Item (Join-Path $dst $f) $bk -Force
}
Write-Host "Резервная копия: $bk" -ForegroundColor Green

# 2. Новые файлы
foreach ($f in "docker-compose.yml", "Dockerfile", "Dockerfile.transcriber", "requirements-transcriber.txt", "ari_bridge.py", "recordings.py", "transcriber.py", "dashboard.html") {
    Copy-Item (Join-Path $src $f) (Join-Path $dst $f) -Force
}
Write-Host "Файлы обновлены." -ForegroundColor Green

# 3. Подключить модуль записей к main.py (один раз, в конец файла)
$mp = Join-Path $dst "main.py"
$utf8 = New-Object System.Text.UTF8Encoding($false)
$t = [IO.File]::ReadAllText($mp, $utf8)
if ($t -notmatch "(?m)^import recordings") {
    $nl = "`r`n"
    if ($t.IndexOf("`r`n") -lt 0) { $nl = "`n" }
    $add = $nl + $nl + "# ---------- 5. Записи звонков и расшифровки (recordings.py) ----------" + $nl +
           "import recordings" + $nl +
           "recordings.configure(events, LOCK)" + $nl +
           "app.include_router(recordings.router)" + $nl
    [IO.File]::WriteAllText($mp, $t.TrimEnd() + $add, $utf8)
    Write-Host "main.py: записи подключены." -ForegroundColor Green
} else {
    Write-Host "main.py: записи уже были подключены." -ForegroundColor Yellow
}

# 4. Сборка и запуск (первая сборка транскрайбера занимает несколько минут)
docker compose up -d --build
if ($LASTEXITCODE -ne 0) { throw "docker compose up завершился с ошибкой, см. вывод выше." }
Start-Sleep -Seconds 10
docker compose ps

Write-Host ""
Write-Host "Готово. Дальше:" -ForegroundColor Cyan
Write-Host "  1) Перерегистрируйте Linphone (1001 и 1003): выключить и включить аккаунт."
Write-Host "  2) Позвоните с 1003 на 1001, поговорите 10-20 секунд, завершите звонок."
Write-Host "  3) Модель расшифровки скачивается при первом запуске: docker compose logs -f transcriber"
Write-Host "  4) Консоль: http://127.0.0.1:8000/ui  (блок 05 CALL RECORDINGS)"
