"""Создаёт/дополняет .env (секреты не перезаписываются) и рендерит asterisk/*.template -> *.conf.
Запуск: python setup.py"""
import pathlib
import re
import secrets

root = pathlib.Path(__file__).parent
env_path = root / ".env"

DEFAULTS = {
    "SIP_BIND_IP": "127.0.0.1",
    "CORS_ORIGINS": "http://localhost:8080",
    "ENV": "prod",                   # dev -> включает /docs
    "ENFORCE": "false",              # true -> бридж сбрасывает звонки SHADOW_HOLD
    # --- внешние звонки (SIP-транк) ---
    "TRUNK_ENABLED": "false",        # true после заполнения TRUNK_*
    "TRUNK_HOST": "",
    "TRUNK_PORT": "5060",
    "TRUNK_USER": "",
    "TRUNK_PASS": "",
    "TRUNK_DIAL_FORMAT": "digits",   # digits = 7701..., e164 = +7701...
    "PUBLIC_IP": "",                 # ваш публичный IP (для SDP транка)
    "ALLOWED_PREFIXES": "+7",        # куда разрешено звонить, через запятую
    "OUTBOUND_MAX_PER_HOUR": "10",
    "OUTBOUND_MAX_CONCURRENT": "1",
    # --- телефон в локальной сети (абонент 1003) ---
    "LAN_IP": "",                    # IPv4 этого ПК в Wi-Fi/LAN, например 192.168.1.50
    "LAN_BIND_IP": "127.0.0.1",      # setup.py ставит 0.0.0.0, когда задан LAN_IP
    # --- антифрод: «ночное» правило, часы по местному времени ---
    "NIGHT_START": "0",
    "NIGHT_END": "6",
    "LOCAL_UTC_OFFSET": "5",         # ваш часовой пояс относительно UTC
}


def load_env(path):
    out = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if "=" in line and not line.lstrip().startswith("#"):
            k, v = line.split("=", 1)
            out[k.strip()] = v.strip()
    return out


if env_path.exists():
    vals = load_env(env_path)
    changed = False
    print(".env уже есть, секреты сохранены")
else:
    vals = {
        "AEGIS_API_KEY": secrets.token_urlsafe(32),
        "ARI_PASSWORD": secrets.token_hex(16),
        "SIP_PASS_1001": secrets.token_hex(12),
        "SIP_PASS_1002": secrets.token_hex(12),
        "SIP_PASS_1003": secrets.token_hex(12),
    }
    changed = True
    print("создан .env")

if "SIP_PASS_1003" not in vals:
    vals["SIP_PASS_1003"] = secrets.token_hex(12)
    changed = True
    print("добавлен параметр SIP_PASS_1003")

for k, v in DEFAULTS.items():
    if k not in vals:
        vals[k] = v
        changed = True
        print("добавлен параметр", k)

if changed:
    env_path.write_text("".join(f"{k}={v}\n" for k, v in vals.items()), encoding="utf-8", newline="\n")

if vals["LAN_IP"] and vals["LAN_BIND_IP"] == "127.0.0.1":
    vals["LAN_BIND_IP"] = "0.0.0.0"
    changed = True
    print("LAN_BIND_IP=0.0.0.0 (порты для телефона открыты в локальной сети)")
if changed:
    env_path.write_text("".join(f"{k}={v}\n" for k, v in vals.items()), encoding="utf-8", newline="\n")

trunk_ready = (
    vals["TRUNK_ENABLED"].lower() == "true"
    and all(vals[k] for k in ("TRUNK_HOST", "TRUNK_USER", "TRUNK_PASS"))
)
if vals["TRUNK_ENABLED"].lower() == "true" and not trunk_ready:
    print("ВНИМАНИЕ: TRUNK_ENABLED=true, но TRUNK_HOST/USER/PASS не заполнены, транк отключён")
    vals["TRUNK_ENABLED"] = "false"


def render(text):
    return re.sub(r"@(\w+)@", lambda m: vals.get(m.group(1), m.group(0)), text)


for tpl in (root / "asterisk").glob("*.template"):
    out = tpl.with_suffix("")
    if tpl.name == "pjsip_lan.conf.template" and not vals["LAN_IP"]:
        out.write_text("; телефон в LAN отключён (LAN_IP пуст)\n", encoding="utf-8", newline="\n")
        print("сгенерирован", out.relative_to(root), "(LAN выключен)")
        continue
    if tpl.name == "pjsip_trunk.conf.template":
        if not trunk_ready:
            out.write_text("; транк отключён (TRUNK_ENABLED=false)\n", encoding="utf-8", newline="\n")
            print("сгенерирован", out.relative_to(root), "(транк выключен)")
            continue
        if not vals["PUBLIC_IP"]:
            print("ВНИМАНИЕ: PUBLIC_IP пуст, оператор получит внутренний адрес в SDP и звука не будет")
        # убираем строки с пустым значением (например media_address= при пустом PUBLIC_IP)
        lines = [l for l in render(tpl.read_text(encoding="utf-8")).splitlines() if not re.match(r"^\w+=$", l)]
        if not vals["PUBLIC_IP"]:
            lines = [l for l in lines if not l.startswith("external_signaling_port=")]
        out.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    else:
        out.write_text(render(tpl.read_text(encoding="utf-8")), encoding="utf-8", newline="\n")
    print("сгенерирован", out.relative_to(root))

print("\nАPI-ключ и пароли смотри в .env (в чаты и git не отправлять)")
