import json
import logging
import os
import re
import secrets
import threading
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
from enum import Enum
from pathlib import Path

from fastapi import Depends, FastAPI, Header, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

API_KEY = os.environ["AEGIS_API_KEY"]  # нет ключа - сервис не стартует
ORIGINS = [o.strip() for o in os.getenv("CORS_ORIGINS", "").split(",") if o.strip()]
IS_DEV = os.getenv("ENV", "prod") == "dev"

NIGHT_START = int(os.getenv("NIGHT_START", "0"))        # ночные часы по местному времени [start, end)
NIGHT_END = int(os.getenv("NIGHT_END", "6"))
UTC_OFFSET = int(os.getenv("LOCAL_UTC_OFFSET", "5"))    # часовой пояс для ночного правила
SHORT_CALL_S = 10                                       # звонок короче этого считается «коротким»
BLACKLIST_FILE = Path(os.getenv("BLACKLIST_FILE", "/data/blacklist.json"))
DASHBOARD_HTML = Path(__file__).with_name("dashboard.html")

logging.basicConfig(level=logging.INFO, format="%(message)s")
audit = logging.getLogger("aegis.audit")

app = FastAPI(
    title="BCC Aegis Security Core",
    version="2.3",
    docs_url="/docs" if IS_DEV else None,
    redoc_url=None,
    openapi_url="/openapi.json" if IS_DEV else None,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "X-API-Key"],
)


def require_key(x_api_key: str = Header(default="")):
    if not secrets.compare_digest(x_api_key.encode(), API_KEY.encode()):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "invalid api key")


# ---------- состояние (в памяти; чёрный список хранится в файле) ----------

LOCK = threading.Lock()
events: deque = deque(maxlen=500)                 # журнал для дашборда
active_calls: dict[str, dict] = {}                # call_id -> состояние звонка
short_calls: dict[str, deque] = defaultdict(deque)        # endpoint -> времена коротких звонков
dest_calls: dict[tuple, deque] = defaultdict(deque)       # (endpoint, dest_hash) -> времена звонков
blacklist: list[str] = []


def load_blacklist() -> list[str]:
    try:
        data = json.loads(BLACKLIST_FILE.read_text(encoding="utf-8"))
        return [x for x in data if isinstance(x, str)]
    except FileNotFoundError:
        return []
    except (OSError, ValueError) as ex:
        logging.warning("blacklist: не удалось прочитать %s: %s", BLACKLIST_FILE, ex)
        return []


def save_blacklist() -> None:
    try:
        BLACKLIST_FILE.parent.mkdir(parents=True, exist_ok=True)
        BLACKLIST_FILE.write_text(json.dumps(blacklist), encoding="utf-8")
    except OSError as ex:
        logging.warning("blacklist: не удалось сохранить (останется только в памяти): %s", ex)


blacklist = load_blacklist()


def norm_number(raw: str) -> str:
    """Номер или префикс чёрного списка: +<код><цифры> либо полный номер 8701.../7701..."""
    s = raw.strip()
    digits = re.sub(r"\D", "", s)
    if s.startswith("+"):
        out = "+" + digits
    elif len(digits) == 11 and digits[0] in "78":
        out = "+7" + digits[1:]
    else:
        raise ValueError("use +prefix or full number")
    if not re.fullmatch(r"\+\d{2,15}", out):
        raise ValueError("bad format")
    return out


def prune(dq: deque, now: float, window: float) -> None:
    while dq and now - dq[0] > window:
        dq.popleft()


def prune_active(now: float) -> None:
    for cid in [c for c, v in active_calls.items() if now - v["last_seen"] > 180]:
        active_calls.pop(cid, None)


def is_night(now: float) -> bool:
    h = (datetime.fromtimestamp(now, timezone.utc) + timedelta(hours=UTC_OFFSET)).hour
    if NIGHT_START <= NIGHT_END:
        return NIGHT_START <= h < NIGHT_END
    return h >= NIGHT_START or h < NIGHT_END


def verdict_for(s: int) -> str:
    if s >= 70:
        return "SHADOW_HOLD"
    if s >= 40:
        return "REVIEW"
    return "ALLOW"


def log_decision(kind: str, subject: str, s: int, v: str, signals: list[str], extra: dict | None = None):
    audit.info(json.dumps({
        "ts": int(time.time()), "kind": kind, "subject": subject,
        "score": s, "verdict": v, "signals": signals, **(extra or {}),
    }))


# ---------- 1. Телеметрия с клиента (HTML / мобильное приложение) ----------

class Transport(str, Enum):
    cellular = "cellular"
    wifi = "wifi"
    voip = "voip"
    unknown = "unknown"


class TelemetryPayload(BaseModel):
    device_id: str = Field(min_length=1, max_length=64, pattern=r"^[\w.\-]+$")
    transport: Transport
    speakerphone: bool
    jitter_ms: int = Field(ge=0, le=10_000)


def score_telemetry(d: TelemetryPayload) -> tuple[int, list[str]]:
    total, signals = 0, []
    if d.transport == Transport.voip:
        total += 40; signals.append("voip_transport")
    if d.speakerphone:
        total += 20; signals.append("speakerphone")
    if d.jitter_ms > 150:
        total += 25; signals.append("jitter_high")
    elif d.jitter_ms > 50:
        total += 10; signals.append("jitter_elevated")
    return min(total, 100), signals


@app.post("/api/v1/telemetry", dependencies=[Depends(require_key)])
def analyze(data: TelemetryPayload):
    s, signals = score_telemetry(data)
    v = verdict_for(s)
    log_decision("telemetry", data.device_id, s, v, signals)
    with LOCK:
        events.append({"ts": time.time(), "kind": "telemetry", "endpoint": data.device_id,
                       "score": s, "verdict": v, "signals": signals})
    return {"risk_score": s, "verdict": v, "signals": signals}


# ---------- 2. События звонков из Asterisk (через ari_bridge) ----------

SCANNER_UA = ("friendly-scanner", "sipvicious", "sipcli", "sip-scan", "pplsip", "vaxsipuseragent")


class CallEvent(BaseModel):
    call_id: str = Field(min_length=1, max_length=64)
    endpoint: str = Field(min_length=1, max_length=64)
    user_agent: str = Field(default="", max_length=200)
    jitter_ms: int = Field(default=0, ge=0, le=10_000)
    calls_last_10min: int = Field(default=0, ge=0, le=10_000)
    concurrent_calls: int = Field(default=0, ge=0, le=1_000)
    elapsed_s: int = Field(default=0, ge=0, le=86_400)
    external: bool = False
    destination: str = Field(default="", max_length=32)   # маскированный номер
    dest_hash: str = Field(default="", max_length=64)     # хэш номера для поиска повторов


class CallEnd(BaseModel):
    call_id: str = Field(min_length=1, max_length=64)
    endpoint: str = Field(min_length=1, max_length=64)
    duration_s: int = Field(ge=0, le=86_400)
    answered: bool = False
    external: bool = False
    destination: str = Field(default="", max_length=32)


class BlockEvent(BaseModel):
    endpoint: str = Field(min_length=1, max_length=64)
    reason: str = Field(min_length=1, max_length=64)
    destination: str = Field(default="", max_length=32)


def score_call(e: CallEvent, now: float, first_event: bool) -> tuple[int, list[str]]:
    """Вызывать под LOCK: читает накопленные счётчики."""
    total, signals = 0, []
    ua = e.user_agent.lower()
    if any(x in ua for x in SCANNER_UA):
        total += 70; signals.append("scanner_user_agent")
    elif not ua:
        total += 15; signals.append("no_user_agent")
    if e.calls_last_10min > 10:
        total += 50; signals.append("call_velocity_very_high")
    elif e.calls_last_10min > 5:
        total += 30; signals.append("call_velocity_high")
    if e.external:
        total += 10; signals.append("external_call")
    if e.concurrent_calls > 1:
        total += 25; signals.append("concurrent_calls")
    if e.jitter_ms > 150:
        total += 25; signals.append("jitter_high")
    elif e.jitter_ms > 50:
        total += 10; signals.append("jitter_elevated")
    if is_night(now):
        total += 15; signals.append("night_call")
    if e.external and e.dest_hash and first_event:
        dq = dest_calls[(e.endpoint, e.dest_hash)]
        prune(dq, now, 3600)
        if len(dq) >= 6:
            total += 40; signals.append("repeated_destination_many")
        elif len(dq) >= 3:
            total += 25; signals.append("repeated_destination")
    sq = short_calls[e.endpoint]
    prune(sq, now, 3600)
    if len(sq) >= 5:
        total += 30; signals.append("short_call_burst")
    return min(total, 100), signals


@app.post("/api/v1/call-event", dependencies=[Depends(require_key)])
def call_event(e: CallEvent):
    now = time.time()
    with LOCK:
        prune_active(now)
        prev = active_calls.get(e.call_id)
        s, signals = score_call(e, now, first_event=prev is None)
        v = verdict_for(s)
        if prev is None and e.external and e.dest_hash:
            dest_calls[(e.endpoint, e.dest_hash)].append(now)
        active_calls[e.call_id] = {
            "endpoint": e.endpoint, "dest": e.destination, "external": e.external,
            "start": prev["start"] if prev else now - e.elapsed_s, "last_seen": now,
            "score": s, "verdict": v, "signals": signals,
        }
        if prev is None or prev["verdict"] != v or prev["score"] != s:
            events.append({"ts": now, "kind": "call", "call_id": e.call_id, "endpoint": e.endpoint,
                           "dest": e.destination, "external": e.external,
                           "score": s, "verdict": v, "signals": signals})
    log_decision("call", f"{e.endpoint}/{e.call_id}", s, v, signals,
                 {"dest": e.destination} if e.destination else None)
    return {"risk_score": s, "verdict": v, "signals": signals}


@app.post("/api/v1/call-end", dependencies=[Depends(require_key)])
def call_end(e: CallEnd):
    now = time.time()
    with LOCK:
        prev = active_calls.pop(e.call_id, None)
        if e.duration_s < SHORT_CALL_S:
            short_calls[e.endpoint].append(now)
        events.append({"ts": now, "kind": "end", "call_id": e.call_id, "endpoint": e.endpoint,
                       "dest": e.destination, "external": e.external, "duration_s": e.duration_s,
                       "answered": e.answered, "verdict": prev["verdict"] if prev else "",
                       "score": prev["score"] if prev else 0, "signals": []})
    audit.info(json.dumps({"ts": int(now), "kind": "call_end", "subject": f"{e.endpoint}/{e.call_id}",
                           "duration_s": e.duration_s, "answered": e.answered}))
    return {"ok": True}


@app.post("/api/v1/block-event", dependencies=[Depends(require_key)])
def block_event(e: BlockEvent):
    now = time.time()
    with LOCK:
        events.append({"ts": now, "kind": "blocked", "endpoint": e.endpoint, "dest": e.destination,
                       "external": True, "verdict": "BLOCKED", "score": 100, "signals": [e.reason]})
    audit.info(json.dumps({"ts": int(now), "kind": "blocked", "subject": e.endpoint,
                           "reason": e.reason, "dest": e.destination}))
    return {"ok": True}


# ---------- 3. Чёрный список ----------

class BlacklistEntry(BaseModel):
    entry: str = Field(min_length=1, max_length=32)


@app.get("/api/v1/blacklist", dependencies=[Depends(require_key)])
def get_blacklist():
    with LOCK:
        return {"entries": list(blacklist)}


@app.post("/api/v1/blacklist", dependencies=[Depends(require_key)])
def add_blacklist(b: BlacklistEntry):
    try:
        entry = norm_number(b.entry)
    except ValueError:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "префикс в формате +7809 или полный номер +7701.../8701...")
    with LOCK:
        if entry not in blacklist:
            if len(blacklist) >= 1000:
                raise HTTPException(status.HTTP_409_CONFLICT, "blacklist full")
            blacklist.append(entry)
            save_blacklist()
        return {"entries": list(blacklist)}


@app.post("/api/v1/blacklist/remove", dependencies=[Depends(require_key)])
def remove_blacklist(b: BlacklistEntry):
    try:
        entry = norm_number(b.entry)
    except ValueError:
        entry = b.entry.strip()
    with LOCK:
        if entry in blacklist:
            blacklist.remove(entry)
            save_blacklist()
        return {"entries": list(blacklist)}


# ---------- 4. Дашборд ----------

@app.get("/ui", response_class=HTMLResponse, include_in_schema=False)
def ui():
    return HTMLResponse(DASHBOARD_HTML.read_text(encoding="utf-8"),
                        headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"})


@app.get("/api/v1/dashboard", dependencies=[Depends(require_key)])
def dashboard():
    now = time.time()
    with LOCK:
        prune_active(now)
        latest: dict[str, str] = {}
        for ev in reversed(events):
            if ev["kind"] == "call" and now - ev["ts"] <= 3600 and ev["call_id"] not in latest:
                latest[ev["call_id"]] = ev["verdict"]
        stats = {"ALLOW": 0, "REVIEW": 0, "SHADOW_HOLD": 0, "BLOCKED": 0}
        for v in latest.values():
            stats[v] = stats.get(v, 0) + 1
        stats["BLOCKED"] = sum(1 for ev in events if ev["kind"] == "blocked" and now - ev["ts"] <= 3600)
        return {
            "now": now,
            "config": {"night": f"{NIGHT_START:02d}-{NIGHT_END:02d} (UTC{UTC_OFFSET:+d})",
                       "hold": 70, "review": 40, "short_call_s": SHORT_CALL_S},
            "stats": stats,
            "active": sorted(
                ({"call_id": cid, "endpoint": v["endpoint"], "dest": v["dest"], "external": v["external"],
                  "score": v["score"], "verdict": v["verdict"], "signals": v["signals"],
                  "duration_s": int(now - v["start"])} for cid, v in active_calls.items()),
                key=lambda x: -x["duration_s"]),
            "events": list(reversed(list(events)[-80:])),
            "blacklist": list(blacklist),
        }


@app.get("/health")
def health():
    return {"status": "ok"}

# ---------- 5. Записи звонков и расшифровки (recordings.py) ----------
import recordings
recordings.configure(events, LOCK)
app.include_router(recordings.router)
