"""Транскрайбер: берёт записи звонков из очереди backend и расшифровывает их офлайн.

Работает через HTTP с backend (общие тома не нужны):
  GET  /api/v1/recordings/pending            -> следующая запись
  GET  /api/v1/recordings/{id}/audio         -> WAV
  POST /api/v1/recordings/{id}/transcript    <- {text, language} или {error}

Модель: faster-whisper (CTranslate2) на CPU. Первый запуск скачивает модель с Hugging Face
в том /cache (нужен интернет один раз). Настройки (env):
  WHISPER_MODEL    tiny | base | small (по умолчанию) | medium
  WHISPER_LANGUAGE auto (по умолчанию) | ru | kk | en ...
  WHISPER_COMPUTE  int8 (по умолчанию) | int8_float32 | float32
"""
import logging
import os
import tempfile
import time

import httpx

BACKEND_URL = os.environ.get("BACKEND_URL", "http://backend:8000")
API_KEY = os.environ["AEGIS_API_KEY"]
MODEL_NAME = os.getenv("WHISPER_MODEL", "small")
LANGUAGE = os.getenv("WHISPER_LANGUAGE", "auto")
COMPUTE = os.getenv("WHISPER_COMPUTE", "int8")
CACHE_DIR = os.path.join(os.getenv("HF_HOME", "/cache"), "whisper")
POLL_S = 3

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("aegis.transcriber")


def load_model():
    from faster_whisper import WhisperModel   # импорт здесь: тяжёлая библиотека, нужна только в рабочем режиме
    log.info("загружаю модель %s (%s); при первом запуске она скачивается", MODEL_NAME, COMPUTE)
    model = WhisperModel(MODEL_NAME, device="cpu", compute_type=COMPUTE, download_root=CACHE_DIR)
    log.info("модель готова")
    return model


def transcribe(model, path: str) -> tuple[str, str]:
    lang = None if LANGUAGE.lower() in ("", "auto") else LANGUAGE
    segments, info = model.transcribe(path, language=lang, vad_filter=True, beam_size=5,
                                      condition_on_previous_text=False)
    text = " ".join(s.text.strip() for s in segments).strip()
    return text, (info.language or "")


def run_once(client: httpx.Client, model) -> bool:
    """Обрабатывает одну запись. Возвращает True, если запись была, False — очередь пуста."""
    r = client.get("/api/v1/recordings/pending", params={"limit": 1})
    r.raise_for_status()
    items = r.json().get("items", [])
    if not items:
        return False
    rec = items[0]
    rid = rec["id"]
    path = None
    try:
        a = client.get(f"/api/v1/recordings/{rid}/audio", timeout=60)
        a.raise_for_status()
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            f.write(a.content)
            path = f.name
        t0 = time.time()
        text, lang = transcribe(model, path)
        log.info("запись #%s расшифрована за %.1f с (%s, %d символов)", rid, time.time() - t0, lang, len(text))
        payload = {"text": text, "language": lang}
    except Exception as e:  # noqa: BLE001
        log.exception("запись #%s: ошибка расшифровки", rid)
        payload = {"error": f"{type(e).__name__}: {e}"[:300]}
    finally:
        if path:
            try:
                os.unlink(path)
            except OSError:
                pass
    client.post(f"/api/v1/recordings/{rid}/transcript", json=payload).raise_for_status()
    return True


def main():
    client = httpx.Client(base_url=BACKEND_URL, headers={"X-API-Key": API_KEY}, timeout=15)
    model = load_model()
    log.info("транскрайбер запущен, жду записи")
    while True:
        try:
            busy = run_once(client, model)
        except httpx.HTTPError as e:
            log.warning("backend недоступен: %s", e)
            busy = False
        if not busy:
            time.sleep(POLL_S)


if __name__ == "__main__":
    main()
