# BCC Aegis

Asterisk (SIP) + FastAPI (скоринг) + ARI-мост, всё в Docker Compose.

## Быстрый старт
```bash
python setup.py                 # создаёт .env с секретами и рендерит asterisk/*.conf
docker compose up -d --build    # прод-режим
# dev (hot reload + /docs):
docker compose -f docker-compose.yml -f docker-compose.dev.yml up --build
docker compose ps               # все три сервиса healthy
```

## Проверка
```bash
KEY=$(grep AEGIS_API_KEY .env | cut -d= -f2)
curl -i -X POST localhost:8000/api/v1/telemetry -H "Content-Type: application/json" \
  -d '{"device_id":"d1","transport":"voip","speakerphone":true,"jitter_ms":80}'        # 401
curl -X POST localhost:8000/api/v1/telemetry -H "Content-Type: application/json" -H "X-API-Key: $KEY" \
  -d '{"device_id":"d1","transport":"voip","speakerphone":true,"jitter_ms":80}'        # вердикт
docker compose exec asterisk asterisk -rx "pjsip show endpoints"
docker compose logs -f ari-bridge backend      # аудит решений
```

## Софтфоны
Zoiper/Linphone: сервер `127.0.0.1:5060`, логины `1001` и `1002`, пароли в `.env`
(`SIP_PASS_1001`, `SIP_PASS_1002`). Звони 1001 -> 1002 (через ARI-мост) или на `600` (эхо).
На Windows сервер указывай с портом 15060: Registrar/Outbound Proxy `sip:127.0.0.1:15060;transport=udp`, Domain `127.0.0.1` (без порта).

## Режимы контроля
- `ENFORCE=false` (по умолчанию): мост только считает и логирует вердикты.
- `ENFORCE=true`: звонки с вердиктом `SHADOW_HOLD` сбрасываются. Включай после подбора порогов в `main.py`.
- Если backend недоступен, звонки не блокируются (fail-open).

## Безопасность
- Наружу открыты только SIP/RTP на `SIP_BIND_IP` (по умолчанию 127.0.0.1) и API на 127.0.0.1:8000.
- ARI (8088) и AMI (5038) не публикуются.
- Для интернета: HTTPS через Caddy/nginx, rate limit, fail2ban для SIP, не открывай 5060 без ACL.
- `.env` и сгенерированные `asterisk/*.conf` не коммитить.

## Известные ограничения
- Поле `jitter_ms` в звонках берётся из `CHANNEL(rtcp,rxjitter)`; если RTCP не включён, будет 0.
  Проверь: `docker compose exec asterisk asterisk -rx "core show channels"` во время звонка.
- Пороги скоринга условные, подбирай на реальных данных.

## Звонки на обычные номера (SIP-транк)
1. Заведи аккаунт у VoIP-оператора (SIP-транк / SIP-аккаунт), пополни счёт небольшой суммой и поставь лимит расходов.
2. В `.env` заполни: `TRUNK_HOST`, `TRUNK_PORT`, `TRUNK_USER`, `TRUNK_PASS`, `PUBLIC_IP` (твой внешний IP),
   `TRUNK_DIAL_FORMAT` (`digits` = `7701...`, `e164` = `+7701...`, смотри документацию оператора),
   затем `TRUNK_ENABLED=true`.
3. `python setup.py` и `docker compose up -d`.
4. Проверка регистрации: `docker compose exec asterisk asterisk -rx "pjsip show registrations"` (статус `Registered`).
5. В софтфоне набери свой мобильный: `87011234567`, `77011234567` или `+77011234567`.

### Защита от кражи минут (всегда включена для внешних звонков)
- `ALLOWED_PREFIXES` - куда можно звонить (по умолчанию только `+7`).
- `OUTBOUND_MAX_PER_HOUR` - лимит внешних звонков в час на абонента (10).
- `OUTBOUND_MAX_CONCURRENT` - одновременных внешних звонков на абонента (1).
- Номера в логах и в backend только в маскированном виде.
- Входящие звонки с транка отклоняются.

### Ограничения
- Транк за домашним NAT: если слышимость односторонняя, пробрось UDP 30000-30050 на роутере и открой их в брандмауэре Windows.
- Если оператор не завершает звонок после того, как собеседник положил трубку, понадобится проброс UDP 5061.
- Конфиг транка проверен только на синтаксис шаблона, с реальным оператором не прогонялся.

## Телефон в локальной сети (абонент 1003)
Бесплатный способ «позвонить на телефон»: на смартфоне установлен софтфон (Linphone/Zoiper), телефон и ПК в одной Wi-Fi сети.
1. В `.env` впиши `LAN_IP` (IPv4 этого ПК в Wi-Fi), затем `python setup.py` и `docker compose up -d`.
2. Брандмауэр Windows (PowerShell от администратора):
   `New-NetFirewallRule -DisplayName "Aegis SIP" -Direction Inbound -Protocol UDP -LocalPort 5062 -Action Allow`
   `New-NetFirewallRule -DisplayName "Aegis RTP" -Direction Inbound -Protocol UDP -LocalPort 30000-30050 -Action Allow`
3. В приложении на телефоне: логин `1003`, пароль `SIP_PASS_1003` из `.env`, Domain `LAN_IP`,
   Registrar и Outbound Proxy `sip:LAN_IP:5062;transport=udp`, UDP.
4. С ПК (1001) набери `1003`, или с телефона набери `1001`.
Если LAN_IP не задан, порты 5062 и 30000-30050 слушают только 127.0.0.1.

## Дашборд мониторинга
Открой `http://localhost:8000/ui` и введи `AEGIS_API_KEY` из `.env` (ключ хранится только в текущей вкладке).
Показывает активные звонки, журнал вердиктов, счётчики за час и чёрный список. Обновляется раз в 2 секунды.
Журнал и счётчики хранятся в памяти backend и сбрасываются при перезапуске; чёрный список сохраняется в томе `aegis_data`.

## Антифрод-сигналы (баллы суммируются, потолок 100)
| Сигнал | Баллы | Что значит |
|---|---|---|
| scanner_user_agent | 70 | User-Agent известного SIP-сканера |
| no_user_agent | 15 | клиент не представился |
| call_velocity_high / very_high | 30 / 50 | более 5 / 10 звонков за 10 минут |
| concurrent_calls | 25 | у абонента больше одного звонка одновременно |
| external_call | 10 | звонок во внешнюю сеть |
| night_call | 15 | звонок в ночные часы (`NIGHT_START`-`NIGHT_END`, `LOCAL_UTC_OFFSET`) |
| repeated_destination / _many | 25 / 40 | 3+ / 6+ звонков абонента на один внешний номер за час |
| short_call_burst | 30 | 5+ звонков короче 10 секунд за час |
| jitter_elevated / high | 10 / 25 | плохое качество канала |

Пороги: 40+ = REVIEW, 70+ = SHADOW_HOLD. Правила в `main.py` (`score_call`).
Чёрный список и лимиты внешних звонков (`ALLOWED_PREFIXES`, `OUTBOUND_MAX_*`) блокируют звонок всегда,
а вердикт SHADOW_HOLD сбрасывает звонок только при `ENFORCE=true`.
В backend номера не передаются: только маска (`+7701*****67`) и хэш для поиска повторов.
