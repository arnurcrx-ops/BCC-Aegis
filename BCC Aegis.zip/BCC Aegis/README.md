# BCC Desktop

An independent desktop banking prototype. It is not affiliated with BCC, does
not connect to real banking systems, and must only use fictional data and
authorized sandbox services.

## Windows development build

Install Qt 6.8 or newer with the matching MinGW kit, CMake 3.25 or newer, and
Ninja. Set these environment variables to the paths for your installed tools:

```powershell
$env:QT_ROOT = "C:\Qt\6.12.0\mingw_64"
$env:CXX = "C:\Qt\Tools\mingw1310_64\bin\g++.exe"
$env:NINJA = "C:\Qt\Tools\Ninja\ninja.exe"
$env:PATH = "$env:QT_ROOT\bin;C:\Qt\Tools\mingw1310_64\bin;$env:PATH"
```

Configure, build, and run the startup smoke test:

```powershell
cmake --preset windows-mingw-debug
cmake --build --preset windows-mingw-debug
ctest --preset windows-mingw-debug
```

Launch the application from the project directory:

```powershell
.\build\windows-mingw-debug\bcc_desktop.exe
```

The Qt Quick desktop prototype includes an overview, scam-check screen,
demonstration transfer form, and searchable/filterable sample activity. Scam
checks use the local analysis API; transfers and account activity are
demonstrations only. It does not process payments or store real account data.

# BCC Desktop — Модель угроз (Crypto Engine)

## 1. Границы
- Приложение не подключается к реальному банку.
- Все данные — фиктивные (демо).
- Криптография защищает **локальное хранилище** и **канал loopback** до analysis API.

## 2. Активы
| Актив | Где | Классификация |
|---|---|---|
| Демо-данные (activity, настройки) | локальный зашифрованный файл | фиктивные, но шифруются |
| Пароль пользователя | в памяти, вводится | секрет |
| AES-ключ | в памяти, выводится из пароля | секрет |
| X25519 secret | в памяти | секрет |
| Ed25519 secret | в памяти | секрет |

## 3. Угрозы (STRIDE)
| Угроза | Вектор | Мера | Статус |
|---|---|---|---|
| Утечка данных с диска | Копирование файла | AES-256-GCM + PBKDF2 | ✅ |
| Подмена файла | Редактирование на диске | GCM auth tag → отказ | ✅ |
| Подмена сообщения scam-check | MITM loopback | Ed25519 подпись | ✅ |
| Перехват ключа обмена | Sniff loopback | X25519 ECDH + HKDF | ✅ |
| Brute-force пароля | Оффлайн | PBKDF2 600k итераций | ✅ |
| Утечка ключей в логи | Логи | Ключи не логируются | ✅ (по коду) |
| Memory dump | Локальный доступ | **НЕ защищено** (нет secure enclave) | ❌ |
| Side-channel | Локальный доступ | **НЕ защищено** | ❌ |
| Forward secrecy | — | **НЕ реализовано** (статичные ключи) | ❌ |

## 4. Ограничения (честно)
- Нет TPM/Secure Enclave — ключи в RAM.
- PBKDF2 (не Argon2id) — компромисс совместимости.
- X25519 без сертификатов — упрощённый обмен, без аутентификации сервера.
- Нет ratchet / forward secrecy.