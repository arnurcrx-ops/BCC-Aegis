import requests

url = "http://127.0.0.1:8000/analyze"
payload = {"text": "Продиктуйте код из СМС"}

response = requests.post(url, json=payload)
print("Статус:", response.status_code)
print("Ответ:", response.json())