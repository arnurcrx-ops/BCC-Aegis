import os
import re

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, event, select
from sqlalchemy.orm import sessionmaker

_database_url = os.environ.get("DATABASE_URL")
os.environ["DATABASE_URL"] = "sqlite://"

from backend import main

if _database_url is None:
    os.environ.pop("DATABASE_URL", None)
else:
    os.environ["DATABASE_URL"] = _database_url


@pytest.fixture
def client(tmp_path):
    database_path = tmp_path / "test.sqlite3"
    engine = create_engine(
        f"sqlite:///{database_path}",
        connect_args={"check_same_thread": False},
    )
    event.listen(engine, "connect", main.enable_sqlite_foreign_keys)
    main.Base.metadata.create_all(bind=engine)
    test_session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)

    def override_get_db():
        db = test_session()
        try:
            yield db
        finally:
            db.close()

    main.app.dependency_overrides[main.get_db] = override_get_db
    with TestClient(main.app) as test_client:
        yield test_client
    main.app.dependency_overrides.clear()
    engine.dispose()


def create_demo_card(client, owner_name="Test User"):
    response = client.post("/create_card", json={"owner_name": owner_name})
    assert response.status_code == 201
    return response.json()


def is_json_number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def test_health_returns_ok(client):
    response = client.get("/health")

    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_analyze_returns_scam_result_and_reason(client):
    response = client.post("/analyze", json={"text": "Продиктуйте код из СМС"})

    assert response.status_code == 200
    assert response.json()["is_scam"] is True
    assert isinstance(response.json()["reason"], str)


def test_analyze_returns_false_for_unmatched_text(client):
    response = client.post("/analyze", json={"text": "Обычное сообщение"})

    assert response.status_code == 200
    assert response.json() == {"is_scam": False}


def test_create_card_returns_demo_card_and_numeric_balance(client):
    response = client.post("/create_card", json={"owner_name": "Test User"})
    body = response.json()

    assert response.status_code == 201
    assert body["status"] == "ok"
    assert re.fullmatch(r"4400\d{12}", body["card_number"])
    assert not main.passes_luhn(body["card_number"])
    assert body["owner_name"] == "Test User"
    assert is_json_number(body["balance"])
    assert body["balance"] == 100000.0


@pytest.mark.parametrize(
    "payload",
    [
        {},
        {"owner_name": ""},
        {"owner_name": "   "},
        {"owner_name": "x" * 101},
        {"owner_name": 123},
    ],
)
def test_create_card_rejects_invalid_data(client, payload):
    response = client.post("/create_card", json=payload)

    assert response.status_code == 422
    assert "detail" in response.json()


def test_create_card_rejects_malformed_json(client):
    response = client.post(
        "/create_card",
        content="{",
        headers={"Content-Type": "application/json"},
    )

    assert response.status_code == 422


def test_create_card_returns_service_unavailable_after_card_number_collisions(
    client, monkeypatch
):
    existing_card = create_demo_card(client)
    monkeypatch.setattr(
        main, "generate_demo_card_number", lambda: existing_card["card_number"]
    )

    response = client.post("/create_card", json={"owner_name": "Another User"})

    assert response.status_code == 503
    assert "detail" in response.json()


def test_balance_returns_numeric_json_value(client):
    card = create_demo_card(client)

    response = client.get(f"/balance/{card['card_number']}")

    assert response.status_code == 200
    assert is_json_number(response.json()["balance"])
    assert response.json()["balance"] == 100000.0


def test_balance_rejects_invalid_or_unknown_card(client):
    malformed = client.get("/balance/not-a-card")
    unknown = client.get("/balance/4400000000000000")

    assert malformed.status_code == 422
    assert unknown.status_code == 404


def test_transfer_updates_both_balances_and_returns_numeric_balance(client):
    sender = create_demo_card(client, "Sender")
    receiver = create_demo_card(client, "Receiver")

    response = client.post(
        "/transfer",
        json={
            "sender_card": sender["card_number"],
            "receiver_card": receiver["card_number"],
            "amount": 1234.50,
        },
    )

    assert response.status_code == 200
    assert response.json()["status"] == "ok"
    assert is_json_number(response.json()["new_balance"])
    assert response.json()["new_balance"] == 98765.5
    assert client.get(f"/balance/{sender['card_number']}").json()["balance"] == 98765.5
    assert client.get(f"/balance/{receiver['card_number']}").json()["balance"] == 101234.5


def test_transfer_rejects_insufficient_balance_without_changing_balances(client):
    sender = create_demo_card(client, "Sender")
    receiver = create_demo_card(client, "Receiver")

    response = client.post(
        "/transfer",
        json={
            "sender_card": sender["card_number"],
            "receiver_card": receiver["card_number"],
            "amount": 100000.01,
        },
    )

    assert response.status_code == 400
    assert client.get(f"/balance/{sender['card_number']}").json()["balance"] == 100000.0
    assert client.get(f"/balance/{receiver['card_number']}").json()["balance"] == 100000.0


def test_transfer_rejects_nonexistent_card(client):
    sender = create_demo_card(client, "Sender")
    missing_card = main.generate_demo_card_number()
    while missing_card == sender["card_number"]:
        missing_card = main.generate_demo_card_number()

    response = client.post(
        "/transfer",
        json={
            "sender_card": sender["card_number"],
            "receiver_card": missing_card,
            "amount": 10,
        },
    )

    assert response.status_code == 404
    assert client.get(f"/balance/{sender['card_number']}").json()["balance"] == 100000.0


@pytest.mark.parametrize(
    "amount", [0, -0.01, 1.001, "10.0", "not-a-number", None]
)
def test_transfer_rejects_invalid_amount_without_changing_balances(client, amount):
    sender = create_demo_card(client, "Sender")
    receiver = create_demo_card(client, "Receiver")

    response = client.post(
        "/transfer",
        json={
            "sender_card": sender["card_number"],
            "receiver_card": receiver["card_number"],
            "amount": amount,
        },
    )

    assert response.status_code == 422
    assert client.get(f"/balance/{sender['card_number']}").json()["balance"] == 100000.0
    assert client.get(f"/balance/{receiver['card_number']}").json()["balance"] == 100000.0


def test_transfer_rejects_same_card_and_malformed_card_numbers(client):
    sender = create_demo_card(client, "Sender")
    same_card = client.post(
        "/transfer",
        json={
            "sender_card": sender["card_number"],
            "receiver_card": sender["card_number"],
            "amount": 1,
        },
    )
    malformed = client.post(
        "/transfer",
        json={"sender_card": "123", "receiver_card": "456", "amount": 1},
    )

    assert same_card.status_code == 400
    assert malformed.status_code == 422
    assert client.get(f"/balance/{sender['card_number']}").json()["balance"] == 100000.0


def test_failed_transfer_does_not_create_transaction(client):
    sender = create_demo_card(client, "Sender")
    receiver = create_demo_card(client, "Receiver")

    response = client.post(
        "/transfer",
        json={
            "sender_card": sender["card_number"],
            "receiver_card": receiver["card_number"],
            "amount": 100000.01,
        },
    )

    assert response.status_code == 400
    db_generator = main.app.dependency_overrides[main.get_db]()
    db = next(db_generator)
    try:
        assert db.scalar(select(main.Transaction)) is None
    finally:
        db_generator.close()
