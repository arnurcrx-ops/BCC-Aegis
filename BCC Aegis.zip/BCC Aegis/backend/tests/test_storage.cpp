#include <QtTest>
#include <QTemporaryDir>
#include <QFile>

#include "security/Crypto.h"
#include "security/SecureStorage.h"

using namespace bcc::security;

class TestStorage : public QObject {
    Q_OBJECT
private slots:
    void init() { m_dir.reset(new QTemporaryDir); QVERIFY(m_dir->isValid()); }
    void cleanup() { m_dir.reset(); }

    // 1. save -> load -> данные совпали
    void saveLoad_Roundtrip() {
        SecureStorage s(m_dir->filePath("data.bin"));
        const QByteArray data = R"({"activity":[{"id":1,"amount":100}]})";
        s.save(data, "correct horse battery staple");
        QCOMPARE(s.load("correct horse battery staple"), data);
    }

    // 2. неверный пароль -> отказ
    void wrongPassword_Throws() {
        SecureStorage s(m_dir->filePath("data.bin"));
        s.save("secret", "password-A");
        QVERIFY_EXCEPTION_THROWN(s.load("password-B"), SecureStorageError);
    }

    // 3. tamper ciphertext -> отказ
    void tamperCiphertext_Throws() {
        const QString p = m_dir->filePath("data.bin");
        SecureStorage s(p);
        s.save(QByteArray(100, 'A'), "pw");
        flipByteAt(p, 4 + 1 + 16 + 4 + 12 + 5);   // внутри ciphertext
        QVERIFY_EXCEPTION_THROWN(s.load("pw"), SecureStorageError);
    }

    // 4. tamper tag -> отказ
    void tamperTag_Throws() {
        const QString p = m_dir->filePath("data.bin");
        SecureStorage s(p);
        s.save(QByteArray(100, 'A'), "pw");
        flipByteAt(p, fileSize(p) - 1);   // последний байт = tag
        QVERIFY_EXCEPTION_THROWN(s.load("pw"), SecureStorageError);
    }

    // 5. tamper salt -> отказ (ключ другой)
    void tamperSalt_Throws() {
        const QString p = m_dir->filePath("data.bin");
        SecureStorage s(p);
        s.save("hello", "pw");
        flipByteAt(p, 5);   // первый байт salt
        QVERIFY_EXCEPTION_THROWN(s.load("pw"), SecureStorageError);
    }

    // 6. обрезанный файл -> отказ
    void truncatedFile_Throws() {
        const QString p = m_dir->filePath("data.bin");
        SecureStorage s(p);
        s.save(QByteArray(100, 'A'), "pw");
        QFile f(p);
        QVERIFY(f.open(QIODevice::ReadWrite));
        QVERIFY(f.resize(20));   // обрезали
        f.close();
        QVERIFY_EXCEPTION_THROWN(s.load("pw"), SecureStorageError);
    }

    // 7. повторная загрузка (save -> load -> save -> load)
    void repeatedSaveLoad_Stable() {
        SecureStorage s(m_dir->filePath("data.bin"));
        s.save("v1", "pw");
        QCOMPARE(s.load("pw"), QByteArray("v1"));
        s.save("v2-longer", "pw");
        QCOMPARE(s.load("pw"), QByteArray("v2-longer"));
        s.save("v3", "pw");
        QCOMPARE(s.load("pw"), QByteArray("v3"));
    }

    // 8. файла нет -> отказ
    void missingFile_Throws() {
        SecureStorage s(m_dir->filePath("nope.bin"));
        QVERIFY_EXCEPTION_THROWN(s.load("pw"), SecureStorageError);
    }

    // 9. пустой пароль -> отказ при save
    void emptyPassword_Throws() {
        SecureStorage s(m_dir->filePath("data.bin"));
        QVERIFY_EXCEPTION_THROWN(s.save("x", ""), SecureStorageError);
    }

private:
    void flipByteAt(const QString& path, qint64 offset) {
        QFile f(path);
        QVERIFY(f.open(QIODevice::ReadWrite));
        QVERIFY(f.seek(offset));
        char b = 0;
        QVERIFY(f.getChar(&b));
        b = static_cast<char>(b ^ 0xFF);
        QVERIFY(f.seek(offset));
        QVERIFY(f.putChar(b));
        f.close();
    }
    qint64 fileSize(const QString& p) { return QFileInfo(p).size(); }

    std::unique_ptr<QTemporaryDir> m_dir;
};

QTEST_MAIN(TestStorage)
#include "test_storage.moc"