"""Local demo ledger only; not a real payment or card-processing service."""

import math
import os
import re
import secrets
from datetime import datetime, timezone
from decimal import Decimal
from typing import Generator

from fastapi import Depends, FastAPI, HTTPException, status
from pydantic import BaseModel, Field, validator
from sqlalchemy import (
    CheckConstraint,
    DateTime,
    ForeignKey,
    Integer,
    Numeric,
    String,
    create_engine,
    event,
    select,
    update,
)
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker


DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./kiberqalqan_pay.db")
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {},
)
if DATABASE_URL.startswith("sqlite"):
    @event.listens_for(engine, "connect")
    def enable_sqlite_foreign_keys(connection, _record) -> None:
        cursor = connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()


SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)

app = FastAPI(title="KiberQalqan Pay Demo API")


class Base(DeclarativeBase):
    pass


class Card(Base):
    __tablename__ = "cards"
    __table_args__ = (CheckConstraint("balance >= 0", name="ck_cards_balance_nonnegative"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    card_number: Mapped[str] = mapped_column(String(16), unique=True, nullable=False, index=True)
    balance: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("100000.00")
    )
    owner_name: Mapped[str] = mapped_column(String(100), nullable=False)


class Transaction(Base):
    __tablename__ = "transactions"
    __table_args__ = (CheckConstraint("amount > 0", name="ck_transactions_amount_positive"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    sender_card: Mapped[str] = mapped_column(
        String(16), ForeignKey("cards.card_number"), nullable=False, index=True
    )
    receiver_card: Mapped[str] = mapped_column(
        String(16), ForeignKey("cards.card_number"), nullable=False, index=True
    )
    amount: Mapped[Decimal] = mapped_column(Numeric(18, 2), nullable=False)
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc)
    )
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="completed")


Base.metadata.create_all(bind=engine)


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def passes_luhn(number: str) -> bool:
    digits = [int(digit) for digit in number]
    checksum = 0
    for index, digit in enumerate(reversed(digits)):
        if index % 2:
            digit *= 2
            if digit > 9:
                digit -= 9
        checksum += digit
    return checksum % 10 == 0


def generate_demo_card_number() -> str:
    first_fifteen = f"4400{secrets.randbelow(10**11):011d}"
    luhn_digit = next(
        digit for digit in range(10) if passes_luhn(first_fifteen + str(digit))
    )
    return first_fifteen + str((luhn_digit + 1) % 10)


class CreateCardRequest(BaseModel):
    owner_name: str = Field(..., min_length=1, max_length=100)

    @validator("owner_name")
    def owner_name_must_not_be_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Owner name must not be blank")
        return value.strip()


class CardResponse(BaseModel):
    status: str = "ok"
    card_number: str
    owner_name: str
    balance: float


class TransferRequest(BaseModel):
    sender_card: str = Field(..., min_length=16, max_length=16)
    receiver_card: str = Field(..., min_length=16, max_length=16)
    amount: Decimal = Field(..., gt=0, max_digits=18, decimal_places=2)

    @validator("sender_card", "receiver_card")
    def validate_demo_card_number(cls, value: str) -> str:
        if re.fullmatch(r"\d{16}", value) is None:
            raise ValueError("Card number must contain exactly 16 digits")
        if passes_luhn(value):
            raise ValueError("Only non-payment demo card numbers are accepted")
        return value

    @validator("amount", pre=True)
    def amount_must_be_a_finite_json_number(cls, value: object) -> object:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Amount must be a JSON number")
        if not math.isfinite(value):
            raise ValueError("Amount must be a finite number")
        return value


class TransferResponse(BaseModel):
    status: str
    new_balance: float


class AnalyzeRequest(BaseModel):
    text: str


@app.post("/analyze")
def analyze(request: AnalyzeRequest) -> dict[str, object]:
    text = request.text.lower()
    if "код из sms" in text or "код из смс" in text or "продиктуйте" in text:
        return {
            "is_scam": True,
            "reason": "Просят код из SMS. Банк никогда не просит коды.",
        }
    if "безопасный счет" in text or "безопасный счёт" in text:
        return {
            "is_scam": True,
            "reason": "Упоминание безопасного счета. Это мошенничество.",
        }
    if "служба безопасности" in text:
        return {
            "is_scam": True,
            "reason": "Представляются службой безопасности. Банк так не работает.",
        }
    return {"is_scam": False}


@app.post("/create_card", response_model=CardResponse, status_code=status.HTTP_201_CREATED)
def create_card(
    request: CreateCardRequest, db: Session = Depends(get_db)
) -> CardResponse:
    for _ in range(5):
        card = Card(
            card_number=generate_demo_card_number(),
            balance=Decimal("100000.00"),
            owner_name=request.owner_name,
        )
        db.add(card)
        try:
            db.commit()
            db.refresh(card)
            return CardResponse(
                status="ok",
                card_number=card.card_number,
                owner_name=card.owner_name,
                balance=float(card.balance),
            )
        except IntegrityError:
            db.rollback()

    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail="Could not allocate a unique demo card number",
    )


@app.get("/health")
def healthcheck() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/balance/{card_number}")
def get_balance(card_number: str, db: Session = Depends(get_db)) -> dict[str, float]:
    if re.fullmatch(r"\d{16}", card_number) is None:
        raise HTTPException(status_code=422, detail="Card number must contain exactly 16 digits")
    if passes_luhn(card_number):
        raise HTTPException(status_code=404, detail="Card not found")
    card = db.scalar(select(Card).where(Card.card_number == card_number))
    if card is None:
        raise HTTPException(status_code=404, detail="Card not found")
    return {"balance": float(card.balance)}


@app.post("/transfer", response_model=TransferResponse)
def transfer(
    request: TransferRequest, db: Session = Depends(get_db)
) -> TransferResponse:
    if request.sender_card == request.receiver_card:
        raise HTTPException(status_code=400, detail="Sender and receiver must be different")

    try:
        with db.begin():
            sender = db.scalar(
                select(Card).where(Card.card_number == request.sender_card)
            )
            receiver = db.scalar(
                select(Card).where(Card.card_number == request.receiver_card)
            )
            if sender is None or receiver is None:
                raise HTTPException(status_code=404, detail="Card not found")

            debit = db.execute(
                update(Card)
                .where(Card.id == sender.id, Card.balance >= request.amount)
                .values(balance=Card.balance - request.amount)
            )
            if debit.rowcount != 1:
                raise HTTPException(status_code=400, detail="Insufficient balance")

            db.execute(
                update(Card)
                .where(Card.id == receiver.id)
                .values(balance=Card.balance + request.amount)
            )
            db.add(
                Transaction(
                    sender_card=request.sender_card,
                    receiver_card=request.receiver_card,
                    amount=request.amount,
                    status="completed",
                )
            )
            new_balance = db.scalar(
                select(Card.balance).where(Card.id == sender.id)
            )
    except HTTPException:
        raise
    except SQLAlchemyError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Database operation failed",
        ) from exc

    return TransferResponse(status="ok", new_balance=float(new_balance))
