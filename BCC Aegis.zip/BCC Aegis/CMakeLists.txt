cmake_minimum_required(VERSION 3.25)

project(BCCDesktop VERSION 0.1.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

include(CTest)

# ── Qt ──────────────────────────────────────────────────────────────
find_package(Qt6 6.8 REQUIRED COMPONENTS Network Quick QuickControls2)
find_package(Qt6 REQUIRED COMPONENTS Test)

# ── OpenSSL (MinGW-совместимые .dll.a) ─────────────────────────────
set(OPENSSL_CRYPTO_LIBRARY "C:/Program Files/OpenSSL-Win64/lib/libcrypto.dll.a")
set(OPENSSL_SSL_LIBRARY    "C:/Program Files/OpenSSL-Win64/lib/libssl.dll.a")
find_package(OpenSSL 3 REQUIRED)

enable_testing()

qt_standard_project_setup(REQUIRES 6.8)

set_source_files_properties(client/ui/theme/Theme.qml PROPERTIES
    QT_QML_SINGLETON_TYPE TRUE
)

# ── bcc_desktop (Qt-клиент) ────────────────────────────────────────
qt_add_executable(bcc_desktop
    client/app/main.cpp
    client/app/ApiClient.cpp
    client/app/ApiClient.h
    src/security/Crypto.cpp
    src/security/Crypto.h
    src/security/SecureStorage.cpp
    src/security/SecureStorage.h
    src/security/SecureStore.cpp
    src/security/SecureStore.h
)

qt_add_qml_module(bcc_desktop
    URI BccDesktop
    VERSION 1.0
    QML_FILES
        client/ui/Main.qml
        client/ui/theme/Theme.qml
        client/ui/SecureStorePanel.qml
)

target_include_directories(bcc_desktop PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/src
)

target_link_libraries(bcc_desktop
    PRIVATE
        Qt6::Quick
        Qt6::Network
        Qt6::QuickControls2
        OpenSSL::Crypto
)

# ── application-startup ────────────────────────────────────────────
if(BUILD_TESTING)
    add_test(NAME application-startup
        COMMAND bcc_desktop --smoke-test
    )
    set_tests_properties(application-startup PROPERTIES
        ENVIRONMENT "QT_QPA_PLATFORM=offscreen"
        TIMEOUT 15
    )
endif()

# ── test_crypto ────────────────────────────────────────────────────
qt_add_executable(test_crypto
    tests/test_crypto.cpp
    src/security/Crypto.cpp
    src/security/Crypto.h
)
target_include_directories(test_crypto PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/src)
target_link_libraries(test_crypto PRIVATE
    Qt6::Test
    OpenSSL::Crypto
)
add_test(NAME test_crypto COMMAND test_crypto)

# ── test_storage ───────────────────────────────────────────────────
qt_add_executable(test_storage
    tests/test_storage.cpp
    src/security/SecureStorage.cpp
    src/security/SecureStorage.h
    src/security/Crypto.cpp
    src/security/Crypto.h
)
target_include_directories(test_storage PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/src)
target_link_libraries(test_storage PRIVATE
    Qt6::Test
    OpenSSL::Crypto
)
add_test(NAME test_storage COMMAND test_storage)