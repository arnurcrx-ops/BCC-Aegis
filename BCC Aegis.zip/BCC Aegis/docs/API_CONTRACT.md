# KiberQalqan API Contract

The Python API is served by `backend.main:app`, normally on
`http://127.0.0.1:8000`. All request and response bodies use JSON. The Qt
client currently sends requests to that fixed host and port.

## `GET /health`

No request body.

**200 response**

```json
{"status": "ok"}
```

| Field | JSON type |
| --- | --- |
| `status` | string |

This route does not currently have an application-specific error response.

## `POST /analyze`

**Request**

```json
{"text": "Продиктуйте код из СМС"}
```

| Field | JSON type |
| --- | --- |
| `text` | string |

**200 response (suspicious text)**

```json
{"is_scam": true, "reason": "Просят код из SMS. Банк никогда не просит коды."}
```

**200 response (no matching indicator)**

```json
{"is_scam": false}
```

| Field | JSON type |
| --- | --- |
| `is_scam` | boolean |
| `reason` | string, optional |

**Errors:** `422` for malformed JSON, a missing `text`, or a non-string value.
The error body uses FastAPI's `{"detail": ...}` format; validation details are
an array of objects.

## `POST /create_card`

**Request**

```json
{"owner_name": "Demo User"}
```

| Field | JSON type |
| --- | --- |
| `owner_name` | string, 1-100 characters and not blank |

**201 response**

```json
{
  "status": "ok",
  "card_number": "4400123456789012",
  "owner_name": "Demo User",
  "balance": 100000.0
}
```

| Field | JSON type |
| --- | --- |
| `status` | string (`"ok"`) |
| `card_number` | string (16 digits; non-payment demo number) |
| `owner_name` | string |
| `balance` | number |

`balance` is a JSON number, not a quoted string.

**Errors:**

- `422` for malformed JSON, a missing field, a blank/oversized owner name, or a
  field with the wrong type. The body uses `{"detail": ...}`.
- `503` if the server cannot allocate a unique demo number after retries; the
  body uses `{"detail": "..."}`.

## `GET /balance/{card_number}`

No request body. `card_number` is a 16-digit path value.

**200 response**

```json
{"balance": 100000.0}
```

| Field | JSON type |
| --- | --- |
| `balance` | number |

The balance is a JSON number, not a quoted string.

**Errors:**

- `422` if the path value is not 16 digits.
- `404` if the number is not a demo card or no such card exists.
- Database failures may produce `500`.

Error bodies use FastAPI's `{"detail": ...}` format.

## `POST /transfer`

**Request**

```json
{
  "sender_card": "4400123456789012",
  "receiver_card": "4400654321098765",
  "amount": 25.5
}
```

| Field | JSON type |
| --- | --- |
| `sender_card` | string (16 digits; non-payment demo number) |
| `receiver_card` | string (16 digits; non-payment demo number) |
| `amount` | number, greater than zero, at most 2 decimal places |

**200 response**

```json
{"status": "ok", "new_balance": 99974.5}
```

| Field | JSON type |
| --- | --- |
| `status` | string (`"ok"`) |
| `new_balance` | number |

`new_balance` is a JSON number, not a quoted string. A successful transfer
debits the sender, credits the receiver, and records a completed transaction
atomically.

**Errors:**

- `400` if the two card numbers are the same or the sender has insufficient
  balance.
- `404` if either card does not exist.
- `422` for malformed JSON, missing/wrongly typed fields, invalid demo-card
  numbers, or an amount that is zero, negative, non-finite, or has more than
  two decimal places.
- `503` for a database operation failure.

Error bodies use FastAPI's `{"detail": ...}` format. Validation details are an
array of objects.

## Response and error behavior

The Python API returns money values as JSON numbers. It uses standard FastAPI
validation responses (`422`, with `detail`) and explicit `detail` messages for
application errors. Clients must not treat a non-2xx response, malformed JSON,
or a response with missing/wrongly typed success fields as a successful
operation.
