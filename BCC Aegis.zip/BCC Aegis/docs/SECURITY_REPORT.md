﻿# BCC Desktop - Отчёт по безопасности

## 1. Что реализовано
- AES-256-GCM: Crypto::encrypt / decrypt (OpenSSL 3.x EVP)
- PBKDF2-HMAC-SHA256: 600000 итераций, соль 16 байт
- X25519 ECDH + HKDF-SHA256
- Ed25519 sign / verify
- SecureStorage: BCCS + version + salt + iter + nonce + ciphertext + tag
- SecureStore: QML-интеграция, 5-й таб Безопасность

## 2. Доказательства
### 2.1. Тесты: 3/3 passed (test_crypto 9 подтестов, test_storage 9 подтестов)
### 2.2. Мутационное тестирование: закомментирован GCM tag -> 3 теста упали -> возвращено -> 100% passed
### 2.3. Шифрование at-rest: hex-дамп 150 байт, BCCS magic + мусор (не JSON)
### 2.4. Tamper-детект: 1 байт изменён -> load FAILED, authentication failed
### 2.5. UI: панель Безопасность, Status ACTIVE, Last op load OK, Error none

## 3. НЕ реализовано (честно)
- TPM / Secure Enclave
- Side-channel защита
- Forward secrecy
- Argon2id (используется PBKDF2)
- PKI для ECDH

## 4. Демо (3 минуты)
1. Запуск с BCC_STORAGE_PASSWORD=demo-secret-2026
2. Таб Безопасность -> Save demo -> save OK
3. Format-Hex -> BCCS + мусор
4. Tamper 1 байт -> Load -> load FAILED
5. ctest -> 3/3 passed
