# API Integration Report

## Qt client

`client/app/ApiClient.cpp` is the HTTP implementation. It uses
`http://127.0.0.1:8000` and JSON requests with a 15-second transfer timeout.
The endpoints called by Qt are:

| Method | URL | Use |
| --- | --- | --- |
| `POST` | `/analyze` | Scam-text analysis |
| `POST` | `/create_card` | Create a demo card |
| `POST` | `/transfer` | Transfer demo funds |

The client does **not** call `/health` or `/balance/{card_number}`; there is no
separate startup/connection check. Connectivity is observed when a feature
request is made.

The QML handlers in `client/ui/Main.qml` reset in-progress state on success and
failure. A transfer only marks itself sent when its success signal is true.

## Error handling

Qt now gives HTTP status errors precedence over `QNetworkReply`'s HTTP-related
network error, and displays `error` or `detail` from a JSON error response when
available. It reports other network failures (including timeout), non-2xx
responses, malformed JSON, missing fields, and fields of the wrong JSON type
through feature-specific failure signals. In particular, card creation and
transfer responses are accepted only after a successful HTTP status and
validation of required success fields. Scam analysis also validates the
optional `reason` type.

Consequently, HTTP `400`, `401`, `403`, `404`, `422`, and `500` all follow the
failure path; they are not converted into a success. Network failures and the
15-second transfer timeout also follow the failure path. The QML error
handlers clear progress indicators and do not display a successful transfer
for an error response.

## Backend selection and parity

The repository does not explicitly designate a single backend or provide a
launcher that chooses one. Both backends listen on port 8000, and the Qt client
hardcodes that address. For this integration, the Python service is treated as
the primary API because it implements the persistent demo ledger; the Qt
client can in practice connect to whichever backend is started on that port.

The Python backend stores cards and transactions through SQLAlchemy; its
default SQLite database is `./kiberqalqan_pay.db` (overridable with
`DATABASE_URL`). The C++ backend stores card owners and balances in in-memory
maps only. Those balances are lost when its process exits, and it does not
record transactions. The activity list shown by the Qt UI is local sample data;
the client does not request transaction history from either backend.

Before this integration, Python had no `/analyze` endpoint even though the Qt
client calls it. Python now exposes `/analyze` with the same keyword checks
and response fields as C++. Other observed differences remain:

- Python exposes `GET /balance/{card_number}`; C++ has no balance route.
- Python's create-card response includes `owner_name`; the C++ response omits
  it. Qt does not require this field.
- Python validates demo-card numbers as 16 digits and rejects Luhn-valid
  payment-like numbers. C++ does not enforce that validation and can generate
  a Luhn-valid number.
- Python reports missing cards as `404`, validation failures as `422`, and
  database failures as `503`. C++ uses `400` for malformed requests and
  missing cards. Error objects are `{"detail": ...}` in FastAPI and
  `{"error": ...}` in C++.
- Python stores decimal amounts with a two-decimal-place limit and commits
  both balance changes and a transaction record atomically. C++ uses `double`
  balances and does not apply the same precision/scale checks or record the
  transaction.

For the three routes that Qt actually calls, the C++ backend currently returns
the success fields and JSON types that `ApiClient` requires. It can therefore
serve the current Qt requests, but its validation, error status codes, and
ledger behavior do not match the Python API contract. The following items are
parity work only; they are not blockers for the current Qt response schema.

### C++ backend follow-up list

If C++ is expected to implement the same contract as the Python service, it
needs:

1. A `GET /balance/{card_number}` route.
2. The same 16-digit non-payment demo-card validation for generated and
   submitted card numbers.
3. Matching request validation, including a two-decimal-place amount limit,
   plus protection against floating-point rounding in ledger operations.
4. Matching status codes and error response shape (`detail`), including `404`
   for missing cards and `422` for invalid input.
5. Durable storage and atomic transfer/transaction recording if it is intended
   to provide the same ledger guarantees.
6. `owner_name` in the create-card response if exact response parity is
   required.

No backend was removed or rewritten.

## Automated coverage and remaining validation

`backend/tests/test_api.py` covers health, analysis, card creation and its
validation/error paths, balance JSON types, successful and rejected
transfers, unchanged balances after failure, and numeric money fields.

Run the API regression suite from the workspace root with:

```powershell
python -m pytest -q backend\tests\test_api.py
```

Result: **24 passed, 0 failed**. The backend was also started with
`python -m uvicorn backend.main:app --host 127.0.0.1 --port 8765`; a live
`GET /health` returned HTTP 200 and `{"status":"ok"}`.

The Qt response/error handling was reviewed in source. Qt 6.12 and MinGW are
installed, but CMake is not available on PATH and CMake Tools reported that no
configure preset is active. The Qt build therefore could not be run; no build
success is claimed.
