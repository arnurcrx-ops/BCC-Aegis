﻿# BCC Desktop - Финальный отчёт (п. 10)

## 1. Изменённые файлы
- CMakeLists.txt
- client/app/main.cpp (регистрация SecureStore)
- client/ui/Main.qml (5-й таб Безопасность)

## 2. Новые файлы
- src/security/Crypto.h / Crypto.cpp
- src/security/SecureStorage.h / SecureStorage.cpp
- src/security/SecureStore.h / SecureStore.cpp
- tests/test_crypto.cpp
- tests/test_storage.cpp
- client/ui/SecureStorePanel.qml
- docs/THREAT_MODEL.md
- docs/SECURITY_REPORT.md
- docs/evidence/secure_activity.bin.example

## 3. Реализованные алгоритмы
- AES-256-GCM (OpenSSL 3.x EVP): Crypto::encrypt/decrypt
- PBKDF2-HMAC-SHA256 (600000 итераций): Crypto::deriveKey
- X25519 ECDH: Crypto::generateX25519 / computeSharedSecret
- HKDF-SHA256: Crypto::hkdfSha256
- Ed25519: Crypto::generateEd25519 / ed25519Sign / ed25519Verify
- SHA-256, secureRandom (RAND_bytes)

## 4. Где интегрировано
- SecureStorage: шифрование файла на диске (формат BCCS)
- SecureStore: Q_PROPERTY/Q_INVOKABLE, доступ из QML
- SecureStorePanel: 5-й таб Безопасность в Main.qml
- main.cpp: qmlRegisterType<SecureStore>

## 5. Команда сборки
cmake --preset windows-mingw-debug
cmake --build --preset windows-mingw-debug
ctest --preset windows-mingw-debug --output-on-failure

## 6. Результат сборки
[17/17] Linking CXX executable bcc_desktop.exe - успешно

## 7. Результат тестов
application-startup: Passed
test_crypto: Passed (9 подтестов)
test_storage: Passed (9 подтестов)
100% tests passed, 0 tests failed out of 3

## 8. Незавершённые функции
- Нет (все заявленные в ТЗ механизмы работают)

## 9. Оставшиеся ограничения безопасности
- Memory dump (ключи в RAM, нет TPM/Secure Enclave)
- Side-channel (timing, cache) - не защищено
- Forward secrecy - статические ключи
- Argon2id не используется (PBKDF2)
- ECDH без PKI (нет сертификатов сервера)

## 10. Инструкция демонстрации
1. Установить переменную окружения BCC_STORAGE_PASSWORD = demo-secret-2026
2. Запустить build/windows-mingw-debug/bcc_desktop.exe
3. Таб Безопасность -> Save demo -> Last op: save OK
4. Format-Hex для secure_activity.bin -> BCCS + мусор
5. Tamper: изменить 1 байт -> Load -> load FAILED
6. ctest -> 3/3 passed
7. Мутационное тестирование: закомментировать GCM tag -> 3 теста упадут
