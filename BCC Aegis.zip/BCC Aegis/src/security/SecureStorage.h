#pragma once

#include <QByteArray>
#include <QString>
#include <stdexcept>

namespace bcc::security {

class SecureStorageError : public std::runtime_error {
public:
    explicit SecureStorageError(const QString& msg)
        : std::runtime_error(msg.toStdString()) {}
};

class SecureStorage {
public:
    explicit SecureStorage(QString path);
    void save(const QByteArray& plaintext, const QString& password);
    QByteArray load(const QString& password) const;
    bool exists() const;
    QString path() const { return m_path; }
    QString lastError() const { return m_lastError; }

private:
    QString m_path;
    mutable QString m_lastError;
};

} // namespace bcc::security