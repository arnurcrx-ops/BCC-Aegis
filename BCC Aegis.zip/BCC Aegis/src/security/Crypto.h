#pragma once

#include <QByteArray>
#include <QString>
#include <stdexcept>

namespace bcc::security {

/// Доменные ошибки крипто-операций. Используются вместо bool, чтобы
/// вызывающий код не мог случайно проигнорировать провал.
class CryptoError : public std::runtime_error {
public:
    explicit CryptoError(const QString& msg)
        : std::runtime_error(msg.toStdString()) {}
};

struct EncryptedBlob {
    QByteArray nonce;       // 12 байт (GCM)
    QByteArray ciphertext;  // plaintext.size()
    QByteArray tag;         // 16 байт (GCM auth tag)
};

struct X25519KeyPair {
    QByteArray publicKey;   // 32 байта
    QByteArray secretKey;   // 32 байта — НЕ логировать, НЕ показывать в UI
};

struct Ed25519KeyPair {
    QByteArray publicKey;   // 32 байта
    QByteArray secretKey;   // 32 байта — НЕ логировать, НЕ показывать в UI
};

class Crypto {
public:
    // ── AES-256-GCM ──────────────────────────────────────────────
    /// key — 32 байта. nonce генерируется криптостойко внутри.
    static EncryptedBlob encrypt(const QByteArray& plaintext, const QByteArray& key);
    /// Бросает CryptoError при неверном теге (tampered / wrong key).
    static QByteArray   decrypt(const EncryptedBlob& blob, const QByteArray& key);

    // ── PBKDF2-HMAC-SHA256 ───────────────────────────────────────
    /// salt — минимум 16 байт. iterations — >= 100000 для продакшна.
    static QByteArray deriveKey(const QString& password,
                                const QByteArray& salt,
                                int iterations = 600000);

    // ── X25519 ECDH + HKDF-SHA256 ────────────────────────────────
    static X25519KeyPair generateX25519();
    /// shared — 32 байта. Бросает CryptoError при невалидном публичном ключе.
    static QByteArray   computeSharedSecret(const QByteArray& mySecretKey,
                                            const QByteArray& peerPublicKey);
    /// HKDF-SHA256 из shared secret -> 32-байтный AES-ключ.
    static QByteArray   hkdfSha256(const QByteArray& ikm,
                                   const QByteArray& salt,
                                   const QByteArray& info,
                                   int outLen = 32);

    // ── Ed25519 ──────────────────────────────────────────────────
    static Ed25519KeyPair generateEd25519();
    static QByteArray     ed25519Sign(const QByteArray& message,
                                      const QByteArray& secretKey);
    /// Возвращает false при неверной подписи (не бросает).
    static bool           ed25519Verify(const QByteArray& message,
                                        const QByteArray& signature,
                                        const QByteArray& publicKey);

    // ── Утилиты ──────────────────────────────────────────────────
    static QByteArray secureRandom(int nBytes);
    static QByteArray sha256(const QByteArray& data);
    static QString    opensslVersion();   // для Paranoid Mode
};

} // namespace bcc::security