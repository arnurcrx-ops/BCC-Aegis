#include "Crypto.h"

#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/kdf.h>
#include <openssl/core_names.h>
#include <openssl/opensslv.h>
#include <openssl/crypto.h>

#include <memory>
#include <cstring>

namespace bcc::security {

namespace {

// RAII для EVP_CIPHER_CTX / EVP_MD_CTX / EVP_PKEY_CTX / EVP_PKEY
struct CipherCtxDeleter { void operator()(EVP_CIPHER_CTX* p) const { EVP_CIPHER_CTX_free(p); } };
struct MdCtxDeleter     { void operator()(EVP_MD_CTX* p)     const { EVP_MD_CTX_free(p); } };
struct PkeyCtxDeleter   { void operator()(EVP_PKEY_CTX* p)   const { EVP_PKEY_CTX_free(p); } };
struct PkeyDeleter      { void operator()(EVP_PKEY* p)       const { EVP_PKEY_free(p); } };
struct KdfCtxDeleter    { void operator()(EVP_KDF_CTX* p)    const { EVP_KDF_CTX_free(p); } };

using CipherCtxPtr = std::unique_ptr<EVP_CIPHER_CTX, CipherCtxDeleter>;
using MdCtxPtr     = std::unique_ptr<EVP_MD_CTX,     MdCtxDeleter>;
using PkeyCtxPtr   = std::unique_ptr<EVP_PKEY_CTX,   PkeyCtxDeleter>;
using PkeyPtr      = std::unique_ptr<EVP_PKEY,       PkeyDeleter>;
using KdfCtxPtr    = std::unique_ptr<EVP_KDF_CTX,    KdfCtxDeleter>;

[[noreturn]] void fail(const char* where) {
    throw CryptoError(QStringLiteral("OpenSSL error in ") + where);
}

} // namespace

// ── AES-256-GCM ──────────────────────────────────────────────────────────────

EncryptedBlob Crypto::encrypt(const QByteArray& plaintext, const QByteArray& key) {
    if (key.size() != 32) fail("AES-GCM: key must be 32 bytes");

    EncryptedBlob out;
    out.nonce = secureRandom(12);

    CipherCtxPtr ctx(EVP_CIPHER_CTX_new());
    if (!ctx) fail("EVP_CIPHER_CTX_new");

    if (EVP_EncryptInit_ex(ctx.get(), EVP_aes_256_gcm(), nullptr, nullptr, nullptr) != 1)
        fail("EVP_EncryptInit_ex(cipher)");
    if (EVP_CIPHER_CTX_ctrl(ctx.get(), EVP_CTRL_GCM_SET_IVLEN, out.nonce.size(), nullptr) != 1)
        fail("EVP_CTRL_GCM_SET_IVLEN");
    if (EVP_EncryptInit_ex(ctx.get(), nullptr, nullptr,
            reinterpret_cast<const unsigned char*>(key.constData()),
            reinterpret_cast<const unsigned char*>(out.nonce.constData())) != 1)
        fail("EVP_EncryptInit_ex(key,nonce)");

    out.ciphertext.resize(plaintext.size() + 16);
    int len = 0;
    if (EVP_EncryptUpdate(ctx.get(),
            reinterpret_cast<unsigned char*>(out.ciphertext.data()), &len,
            reinterpret_cast<const unsigned char*>(plaintext.constData()),
            plaintext.size()) != 1)
        fail("EVP_EncryptUpdate");

    int total = len;
    if (EVP_EncryptFinal_ex(ctx.get(),
            reinterpret_cast<unsigned char*>(out.ciphertext.data()) + total, &len) != 1)
        fail("EVP_EncryptFinal_ex");
    total += len;
    out.ciphertext.resize(total);

    out.tag.resize(16);
    if (EVP_CIPHER_CTX_ctrl(ctx.get(), EVP_CTRL_GCM_GET_TAG, 16, out.tag.data()) != 1)
        fail("EVP_CTRL_GCM_GET_TAG");

    return out;
}

QByteArray Crypto::decrypt(const EncryptedBlob& blob, const QByteArray& key) {
    if (key.size() != 32) fail("AES-GCM: key must be 32 bytes");
    if (blob.nonce.size() != 12) fail("AES-GCM: nonce must be 12 bytes");
    if (blob.tag.size() != 16)   fail("AES-GCM: tag must be 16 bytes");

    CipherCtxPtr ctx(EVP_CIPHER_CTX_new());
    if (!ctx) fail("EVP_CIPHER_CTX_new");

    if (EVP_DecryptInit_ex(ctx.get(), EVP_aes_256_gcm(), nullptr, nullptr, nullptr) != 1)
        fail("EVP_DecryptInit_ex(cipher)");
    if (EVP_CIPHER_CTX_ctrl(ctx.get(), EVP_CTRL_GCM_SET_IVLEN, blob.nonce.size(), nullptr) != 1)
        fail("EVP_CTRL_GCM_SET_IVLEN");
    if (EVP_DecryptInit_ex(ctx.get(), nullptr, nullptr,
            reinterpret_cast<const unsigned char*>(key.constData()),
            reinterpret_cast<const unsigned char*>(blob.nonce.constData())) != 1)
        fail("EVP_DecryptInit_ex(key,nonce)");

    QByteArray plaintext(blob.ciphertext.size() + 16, '\0');
    int len = 0;
    if (EVP_DecryptUpdate(ctx.get(),
            reinterpret_cast<unsigned char*>(plaintext.data()), &len,
            reinterpret_cast<const unsigned char*>(blob.ciphertext.constData()),
            blob.ciphertext.size()) != 1)
        fail("EVP_DecryptUpdate");

    int total = len;
    if (EVP_CIPHER_CTX_ctrl(ctx.get(), EVP_CTRL_GCM_SET_TAG, 16,
            const_cast<char*>(blob.tag.constData())) != 1)
        fail("EVP_CTRL_GCM_SET_TAG");

    int ok = EVP_DecryptFinal_ex(ctx.get(),
        reinterpret_cast<unsigned char*>(plaintext.data()) + total, &len);
   if (ok != 1) throw CryptoError("AES-GCM: authentication failed");
    total += len;
    plaintext.resize(total);
    return plaintext;
}

// ── PBKDF2-HMAC-SHA256 ───────────────────────────────────────────────────────

QByteArray Crypto::deriveKey(const QString& password, const QByteArray& salt, int iterations) {
    if (salt.size() < 16) fail("PBKDF2: salt must be >= 16 bytes");
    if (iterations < 100000) fail("PBKDF2: iterations must be >= 100000");

    const QByteArray pw = password.toUtf8();
    QByteArray key(32, '\0');

    if (PKCS5_PBKDF2_HMAC(pw.constData(), pw.size(),
            reinterpret_cast<const unsigned char*>(salt.constData()), salt.size(),
            iterations, EVP_sha256(), key.size(),
            reinterpret_cast<unsigned char*>(key.data())) != 1)
        fail("PKCS5_PBKDF2_HMAC");
    return key;
}

// ── X25519 ECDH ──────────────────────────────────────────────────────────────

X25519KeyPair Crypto::generateX25519() {
    PkeyCtxPtr ctx(EVP_PKEY_CTX_new_id(EVP_PKEY_X25519, nullptr));
    if (!ctx || EVP_PKEY_keygen_init(ctx.get()) != 1) fail("X25519 keygen_init");

    EVP_PKEY* raw = nullptr;
    if (EVP_PKEY_keygen(ctx.get(), &raw) != 1) fail("X25519 keygen");
    PkeyPtr pkey(raw);

    X25519KeyPair kp;
    size_t len = 32;
    kp.publicKey.resize(32);
    if (EVP_PKEY_get_raw_public_key(pkey.get(),
            reinterpret_cast<unsigned char*>(kp.publicKey.data()), &len) != 1)
        fail("X25519 get_public");

    len = 32;
    kp.secretKey.resize(32);
    if (EVP_PKEY_get_raw_private_key(pkey.get(),
            reinterpret_cast<unsigned char*>(kp.secretKey.data()), &len) != 1)
        fail("X25519 get_private");

    return kp;
}

QByteArray Crypto::computeSharedSecret(const QByteArray& mySecretKey,
                                       const QByteArray& peerPublicKey) {
    if (mySecretKey.size() != 32)   fail("X25519: secret key must be 32 bytes");
    if (peerPublicKey.size() != 32) fail("X25519: public key must be 32 bytes");

    PkeyPtr priv(EVP_PKEY_new_raw_private_key(EVP_PKEY_X25519, nullptr,
        reinterpret_cast<const unsigned char*>(mySecretKey.constData()), 32));
    PkeyPtr pub(EVP_PKEY_new_raw_public_key(EVP_PKEY_X25519, nullptr,
        reinterpret_cast<const unsigned char*>(peerPublicKey.constData()), 32));
    if (!priv || !pub) fail("X25519 new_raw_key");

    PkeyCtxPtr ctx(EVP_PKEY_CTX_new(priv.get(), nullptr));
    if (!ctx || EVP_PKEY_derive_init(ctx.get()) != 1) fail("X25519 derive_init");
    if (EVP_PKEY_derive_set_peer(ctx.get(), pub.get()) != 1) fail("X25519 set_peer");

    size_t len = 0;
    if (EVP_PKEY_derive(ctx.get(), nullptr, &len) != 1) fail("X25519 derive(size)");
    QByteArray shared(len, '\0');
    if (EVP_PKEY_derive(ctx.get(),
            reinterpret_cast<unsigned char*>(shared.data()), &len) != 1)
        fail("X25519 derive");
    shared.resize(len);
    return shared;
}

// ── HKDF-SHA256 ──────────────────────────────────────────────────────────────

QByteArray Crypto::hkdfSha256(const QByteArray& ikm, const QByteArray& salt,
                              const QByteArray& info, int outLen) {
    if (outLen <= 0 || outLen > 8160) fail("HKDF: invalid outLen");

    KdfCtxPtr ctx(EVP_KDF_CTX_new(EVP_KDF_fetch(nullptr, "HKDF", nullptr)));
    if (!ctx) fail("HKDF fetch");

    OSSL_PARAM params[] = {
        OSSL_PARAM_construct_utf8_string(OSSL_KDF_PARAM_DIGEST,
            const_cast<char*>("SHA256"), 0),
        OSSL_PARAM_construct_octet_string(OSSL_KDF_PARAM_KEY,
            const_cast<char*>(ikm.constData()), ikm.size()),
        OSSL_PARAM_construct_octet_string(OSSL_KDF_PARAM_SALT,
            const_cast<char*>(salt.constData()), salt.size()),
        OSSL_PARAM_construct_octet_string(OSSL_KDF_PARAM_INFO,
            const_cast<char*>(info.constData()), info.size()),
        OSSL_PARAM_construct_end()
    };

    QByteArray out(outLen, '\0');
    if (EVP_KDF_derive(ctx.get(),
            reinterpret_cast<unsigned char*>(out.data()), out.size(), params) != 1)
        fail("EVP_KDF_derive");
    return out;
}

// ── Ed25519 ──────────────────────────────────────────────────────────────────

Ed25519KeyPair Crypto::generateEd25519() {
    PkeyCtxPtr ctx(EVP_PKEY_CTX_new_id(EVP_PKEY_ED25519, nullptr));
    if (!ctx || EVP_PKEY_keygen_init(ctx.get()) != 1) fail("Ed25519 keygen_init");

    EVP_PKEY* raw = nullptr;
    if (EVP_PKEY_keygen(ctx.get(), &raw) != 1) fail("Ed25519 keygen");
    PkeyPtr pkey(raw);

    Ed25519KeyPair kp;
    size_t len = 32;
    kp.publicKey.resize(32);
    if (EVP_PKEY_get_raw_public_key(pkey.get(),
            reinterpret_cast<unsigned char*>(kp.publicKey.data()), &len) != 1)
        fail("Ed25519 get_public");

    len = 32;
    kp.secretKey.resize(32);
    if (EVP_PKEY_get_raw_private_key(pkey.get(),
            reinterpret_cast<unsigned char*>(kp.secretKey.data()), &len) != 1)
        fail("Ed25519 get_private");
    return kp;
}

QByteArray Crypto::ed25519Sign(const QByteArray& message, const QByteArray& secretKey) {
    if (secretKey.size() != 32) fail("Ed25519: secret key must be 32 bytes");

    PkeyPtr key(EVP_PKEY_new_raw_private_key(EVP_PKEY_ED25519, nullptr,
        reinterpret_cast<const unsigned char*>(secretKey.constData()), 32));
    if (!key) fail("Ed25519 new_raw_private");

    MdCtxPtr ctx(EVP_MD_CTX_new());
    if (!ctx || EVP_DigestSignInit(ctx.get(), nullptr, nullptr, nullptr, key.get()) != 1)
        fail("Ed25519 sign_init");

    size_t sigLen = 64;
    QByteArray sig(64, '\0');
    if (EVP_DigestSign(ctx.get(),
            reinterpret_cast<unsigned char*>(sig.data()), &sigLen,
            reinterpret_cast<const unsigned char*>(message.constData()),
            message.size()) != 1)
        fail("Ed25519 sign");
    sig.resize(sigLen);
    return sig;
}

bool Crypto::ed25519Verify(const QByteArray& message, const QByteArray& signature,
                           const QByteArray& publicKey) {
    if (signature.size() != 64 || publicKey.size() != 32) return false;

    PkeyPtr key(EVP_PKEY_new_raw_public_key(EVP_PKEY_ED25519, nullptr,
        reinterpret_cast<const unsigned char*>(publicKey.constData()), 32));
    if (!key) return false;

    MdCtxPtr ctx(EVP_MD_CTX_new());
    if (!ctx || EVP_DigestVerifyInit(ctx.get(), nullptr, nullptr, nullptr, key.get()) != 1)
        return false;

    return EVP_DigestVerify(ctx.get(),
        reinterpret_cast<const unsigned char*>(signature.constData()), signature.size(),
        reinterpret_cast<const unsigned char*>(message.constData()), message.size()) == 1;
}

// ── Утилиты ──────────────────────────────────────────────────────────────────

QByteArray Crypto::secureRandom(int nBytes) {
    if (nBytes <= 0) fail("secureRandom: nBytes must be > 0");
    QByteArray out(nBytes, '\0');
    if (RAND_bytes(reinterpret_cast<unsigned char*>(out.data()), nBytes) != 1)
        fail("RAND_bytes");
    return out;
}

QByteArray Crypto::sha256(const QByteArray& data) {
    QByteArray out(32, '\0');
    unsigned int outLen = 0;
    if (EVP_Digest(data.constData(), data.size(),
            reinterpret_cast<unsigned char*>(out.data()), &outLen,
            EVP_sha256(), nullptr) != 1)
        fail("EVP_Digest");
    return out;
}

QString Crypto::opensslVersion() {
    return QString::fromLatin1(OpenSSL_version(OPENSSL_VERSION));
}

} // namespace bcc::security