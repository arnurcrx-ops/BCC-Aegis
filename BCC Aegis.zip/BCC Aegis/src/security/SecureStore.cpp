#include "SecureStore.h"
#include "SecureStorage.h"

#include <QStandardPaths>
#include <QDir>
#include <QFileInfo>
#include <QDateTime>

SecureStore::SecureStore(QObject* parent) : QObject(parent) {
    m_password = qEnvironmentVariable("BCC_STORAGE_PASSWORD");
    if (m_password.isEmpty()) {
        setLastError(QStringLiteral("BCC_STORAGE_PASSWORD not set — secure storage disabled"));
        return;
    }

    const QString dir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    QDir().mkpath(dir);
    m_path = dir + QStringLiteral("/secure_activity.bin");

    m_storage = std::make_unique<bcc::security::SecureStorage>(m_path);
    m_available = true;
    setLastOperation(QStringLiteral("initialized"));
}

SecureStore::~SecureStore() = default;

QString SecureStore::storagePath() const { return m_path; }

bool SecureStore::save(const QString& data) {
    if (!m_available || !m_storage) { setLastError("secure storage unavailable"); return false; }
    try {
        m_storage->save(data.toUtf8(), m_password);
        setLastError(QString());
        setLastOperation(QStringLiteral("save OK @ %1")
            .arg(QDateTime::currentDateTime().toString("hh:mm:ss")));
        return true;
    } catch (const std::exception& e) {
        setLastError(QString::fromUtf8(e.what()));
        setLastOperation(QStringLiteral("save FAILED"));
        return false;
    }
}

QString SecureStore::load() {
    if (!m_available || !m_storage) { setLastError("secure storage unavailable"); return {}; }
    try {
        const QByteArray data = m_storage->load(m_password);
        setLastError(QString());
        setLastOperation(QStringLiteral("load OK (%1 bytes) @ %2")
            .arg(data.size())
            .arg(QDateTime::currentDateTime().toString("hh:mm:ss")));
        return QString::fromUtf8(data);
    } catch (const std::exception& e) {
        setLastError(QString::fromUtf8(e.what()));
        setLastOperation(QStringLiteral("load FAILED"));
        return {};
    }
}

bool SecureStore::exists() const {
    return m_available && m_storage && m_storage->exists();
}

void SecureStore::setLastError(const QString& e) {
    if (m_lastError == e) return;
    m_lastError = e;
    emit lastErrorChanged();
}

void SecureStore::setLastOperation(const QString& op) {
    if (m_lastOperation == op) return;
    m_lastOperation = op;
    emit lastOperationChanged();
}