#include "SecureStorage.h"
#include "Crypto.h"

#include <QFile>
#include <QFileInfo>
#include <cstring>

namespace bcc::security {

namespace {
constexpr char     kMagic[4]    = {'B','C','C','S'};
constexpr quint8   kVersion     = 1;
constexpr int      kSaltLen     = 16;
constexpr int      kNonceLen    = 12;
constexpr int      kTagLen      = 16;
constexpr int      kIterations  = 600000;
constexpr int      kHeaderLen   = 4 + 1 + kSaltLen + 4;
constexpr int      kMinFileLen  = kHeaderLen + kNonceLen + kTagLen;
}

SecureStorage::SecureStorage(QString path) : m_path(std::move(path)) {}

bool SecureStorage::exists() const {
    return QFileInfo::exists(m_path);
}

void SecureStorage::save(const QByteArray& plaintext, const QString& password) {
    if (password.isEmpty()) {
        m_lastError = "empty password";
        throw SecureStorageError("SecureStorage::save: empty password");
    }

    const QByteArray salt = Crypto::secureRandom(kSaltLen);
    const QByteArray key = Crypto::deriveKey(password, salt, kIterations);
    const EncryptedBlob blob = Crypto::encrypt(plaintext, key);

    QByteArray out;
    out.reserve(kHeaderLen + blob.nonce.size() + blob.ciphertext.size() + blob.tag.size());
    out.append(kMagic, 4);
    out.append(static_cast<char>(kVersion));
    out.append(salt);
    out.append(static_cast<char>((kIterations >> 24) & 0xFF));
    out.append(static_cast<char>((kIterations >> 16) & 0xFF));
    out.append(static_cast<char>((kIterations >>  8) & 0xFF));
    out.append(static_cast<char>( kIterations        & 0xFF));
    out.append(blob.nonce);
    out.append(blob.ciphertext);
    out.append(blob.tag);

    const QString tmp = m_path + ".tmp";
    {
        QFile f(tmp);
        if (!f.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
            m_lastError = f.errorString();
            throw SecureStorageError("SecureStorage::save: cannot open " + tmp);
        }
        if (f.write(out) != out.size()) {
            m_lastError = "short write";
            throw SecureStorageError("SecureStorage::save: short write");
        }
        f.flush();
        f.close();
    }

    QFile::remove(m_path);
    if (!QFile::rename(tmp, m_path)) {
        m_lastError = "rename failed";
        throw SecureStorageError("SecureStorage::save: rename failed");
    }
    m_lastError.clear();
}

QByteArray SecureStorage::load(const QString& password) const {
    m_lastError.clear();

    QFile f(m_path);
    if (!f.open(QIODevice::ReadOnly)) {
        m_lastError = f.errorString();
        throw SecureStorageError("SecureStorage::load: cannot open " + m_path);
    }
    const QByteArray raw = f.readAll();
    f.close();

    if (raw.size() < kMinFileLen) {
        m_lastError = "file too short";
        throw SecureStorageError("SecureStorage::load: file too short");
    }

    if (std::memcmp(raw.constData(), kMagic, 4) != 0) {
        m_lastError = "bad magic";
        throw SecureStorageError("SecureStorage::load: bad magic");
    }

    const quint8 ver = static_cast<quint8>(raw.at(4));
    if (ver != kVersion) {
        m_lastError = "unsupported version";
        throw SecureStorageError("SecureStorage::load: unsupported version");
    }

    const QByteArray salt = raw.mid(5, kSaltLen);
    const quint32 iter =
        (static_cast<quint32>(static_cast<quint8>(raw.at(5 + kSaltLen    ))) << 24) |
        (static_cast<quint32>(static_cast<quint8>(raw.at(5 + kSaltLen + 1))) << 16) |
        (static_cast<quint32>(static_cast<quint8>(raw.at(5 + kSaltLen + 2))) <<  8) |
        (static_cast<quint32>(static_cast<quint8>(raw.at(5 + kSaltLen + 3)))      );

    if (iter < 100000) {
        m_lastError = "iterations too low";
        throw SecureStorageError("SecureStorage::load: iterations too low (suspicious)");
    }

    const int offNonce = kHeaderLen;
    const int offTag   = raw.size() - kTagLen;
    if (offTag <= offNonce + kNonceLen) {
        m_lastError = "truncated body";
        throw SecureStorageError("SecureStorage::load: truncated body");
    }

    EncryptedBlob blob;
    blob.nonce      = raw.mid(offNonce, kNonceLen);
    blob.ciphertext = raw.mid(offNonce + kNonceLen, offTag - (offNonce + kNonceLen));
    blob.tag        = raw.mid(offTag, kTagLen);

    const QByteArray key = Crypto::deriveKey(password, salt, static_cast<int>(iter));
    try {
        return Crypto::decrypt(blob, key);
    } catch (const CryptoError& e) {
        m_lastError = e.what();
        throw SecureStorageError(QString("SecureStorage::load: decrypt failed: ") + e.what());
    }
}

} // namespace bcc::security