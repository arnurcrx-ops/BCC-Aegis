#pragma once

#include <QObject>
#include <QString>
#include <QVariantMap>
#include <memory>

namespace bcc::security {
class SecureStorage;
}

class SecureStore : public QObject {
    Q_OBJECT
    Q_PROPERTY(bool available READ available CONSTANT)
    Q_PROPERTY(QString storagePath READ storagePath CONSTANT)
    Q_PROPERTY(QString lastError READ lastError NOTIFY lastErrorChanged)
    Q_PROPERTY(QString lastOperation READ lastOperation NOTIFY lastOperationChanged)

public:
    explicit SecureStore(QObject* parent = nullptr);
    ~SecureStore() override;

    bool available() const { return m_available; }
    QString storagePath() const;
    QString lastError() const { return m_lastError; }
    QString lastOperation() const { return m_lastOperation; }

    Q_INVOKABLE bool save(const QString& data);
    Q_INVOKABLE QString load();
    Q_INVOKABLE bool exists() const;

signals:
    void lastErrorChanged();
    void lastOperationChanged();

private:
    void setLastError(const QString& e);
    void setLastOperation(const QString& op);

    bool m_available = false;
    QString m_password;
    QString m_path;
    QString m_lastError;
    QString m_lastOperation;
    std::unique_ptr<bcc::security::SecureStorage> m_storage;
};