import json
import logging
import os
import secrets
import time
from enum import Enum

from fastapi import Depends, FastAPI, Header, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

API_KEY = os.environ["AEGIS_API_KEY"]  # нет ключа - сервис не стартует
ORIGINS = [o.strip() for o in os.getenv("CORS_ORIGINS", "").split(",") if o.strip()]
IS_DEV = os.getenv("ENV", "prod") == "dev"

logging.basicConfig(level=logging.INFO, format="%(message)s")
audit = logging.getLogger("aegis.audit")

app = FastAPI(
    title="BCC Aegis Security Core",
    version="2.2",
    docs_url="/docs" if IS_DEV else None,
    redoc_url=None,
    openapi_url="/openapi.json" if IS_DEV else None,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "X-API-Key"],
)


def require_key(x_api_key: str = Header(default="")):
    if not secrets.compare_digest(x_api_key.encode(), API_KEY.encode()):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "invalid api key")


def verdict_for(s: int) -> str:
    if s >= 70:
        return "SHADOW_HOLD"
    if s >= 40:
        return "REVIEW"
    return "ALLOW"


def log_decision(kind: str, subject: str, s: int, v: str, signals: list[str], extra: dict | None = None):
    audit.info(json.dumps({
        "ts": int(time.time()), "kind": kind, "subject": subject,
        "score": s, "verdict": v, "signals": signals, **(extra or {}),
    }))


# ---------- 1. Телеметрия с клиента (HTML / мобильное приложение) ----------

class Transport(str, Enum):
    cellular = "cellular"
    wifi = "wifi"
    voip = "voip"
    unknown = "unknown"


class TelemetryPayload(BaseModel):
    device_id: str = Field(min_length=1, max_length=64, pattern=r"^[\w.\-]+$")
    transport: Transport
    speakerphone: bool
    jitter_ms: int = Field(ge=0, le=10_000)


def score_telemetry(d: TelemetryPayload) -> tuple[int, list[str]]:
    total, signals = 0, []
    if d.transport == Transport.voip:
        total += 40; signals.append("voip_transport")
    if d.speakerphone:
        total += 20; signals.append("speakerphone")
    if d.jitter_ms > 150:
        total += 25; signals.append("jitter_high")
    elif d.jitter_ms > 50:
        total += 10; signals.append("jitter_elevated")
    return min(total, 100), signals


@app.post("/api/v1/telemetry", dependencies=[Depends(require_key)])
def analyze(data: TelemetryPayload):
    s, signals = score_telemetry(data)
    v = verdict_for(s)
    log_decision("telemetry", data.device_id, s, v, signals)
    return {"risk_score": s, "verdict": v, "signals": signals}


# ---------- 2. События звонков из Asterisk (через ari_bridge) ----------

SCANNER_UA = ("friendly-scanner", "sipvicious", "sipcli", "sip-scan", "pplsip", "vaxsipuseragent")


class CallEvent(BaseModel):
    call_id: str = Field(min_length=1, max_length=64)
    endpoint: str = Field(min_length=1, max_length=64)
    user_agent: str = Field(default="", max_length=200)
    jitter_ms: int = Field(default=0, ge=0, le=10_000)
    calls_last_10min: int = Field(default=0, ge=0, le=10_000)
    concurrent_calls: int = Field(default=0, ge=0, le=1_000)
    elapsed_s: int = Field(default=0, ge=0, le=86_400)
    external: bool = False
    destination: str = Field(default="", max_length=32)  # уже маскированный номер


def score_call(e: CallEvent) -> tuple[int, list[str]]:
    total, signals = 0, []
    ua = e.user_agent.lower()
    if any(x in ua for x in SCANNER_UA):
        total += 70; signals.append("scanner_user_agent")
    elif not ua:
        total += 15; signals.append("no_user_agent")
    if e.calls_last_10min > 10:
        total += 50; signals.append("call_velocity_very_high")
    elif e.calls_last_10min > 5:
        total += 30; signals.append("call_velocity_high")
    if e.external:
        total += 10; signals.append("external_call")
    if e.concurrent_calls > 1:
        total += 25; signals.append("concurrent_calls")
    if e.jitter_ms > 150:
        total += 25; signals.append("jitter_high")
    elif e.jitter_ms > 50:
        total += 10; signals.append("jitter_elevated")
    return min(total, 100), signals


@app.post("/api/v1/call-event", dependencies=[Depends(require_key)])
def call_event(e: CallEvent):
    s, signals = score_call(e)
    v = verdict_for(s)
    log_decision("call", f"{e.endpoint}/{e.call_id}", s, v, signals,
                 {"dest": e.destination} if e.destination else None)
    return {"risk_score": s, "verdict": v, "signals": signals}


@app.get("/health")
def health():
    return {"status": "ok"}
