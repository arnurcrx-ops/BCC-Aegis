#include "crow.h"

#include <cmath>
#include <cstdint>
#include <iostream>
#include <map>
#include <mutex>
#include <random>
#include <string>

namespace {

void append_utf8(std::string& output, std::uint32_t code_point)
{
    if (code_point <= 0x7F)
    {
        output.push_back(static_cast<char>(code_point));
    }
    else if (code_point <= 0x7FF)
    {
        output.push_back(static_cast<char>(0xC0 | (code_point >> 6)));
        output.push_back(static_cast<char>(0x80 | (code_point & 0x3F)));
    }
    else if (code_point <= 0xFFFF)
    {
        output.push_back(static_cast<char>(0xE0 | (code_point >> 12)));
        output.push_back(static_cast<char>(0x80 | ((code_point >> 6) & 0x3F)));
        output.push_back(static_cast<char>(0x80 | (code_point & 0x3F)));
    }
    else
    {
        output.push_back(static_cast<char>(0xF0 | (code_point >> 18)));
        output.push_back(static_cast<char>(0x80 | ((code_point >> 12) & 0x3F)));
        output.push_back(static_cast<char>(0x80 | ((code_point >> 6) & 0x3F)));
        output.push_back(static_cast<char>(0x80 | (code_point & 0x3F)));
    }
}

std::string lowercase_utf8(const std::string& text)
{
    std::string result;
    result.reserve(text.size());

    for (std::size_t index = 0; index < text.size();)
    {
        const auto first = static_cast<unsigned char>(text[index]);
        std::uint32_t code_point = 0;
        std::size_t sequence_length = 0;

        if (first <= 0x7F)
        {
            code_point = first;
            sequence_length = 1;
            if (code_point >= 'A' && code_point <= 'Z')
            {
                code_point += 'a' - 'A';
            }
        }
        else if ((first & 0xE0) == 0xC0)
        {
            code_point = first & 0x1F;
            sequence_length = 2;
        }
        else if ((first & 0xF0) == 0xE0)
        {
            code_point = first & 0x0F;
            sequence_length = 3;
        }
        else if ((first & 0xF8) == 0xF0)
        {
            code_point = first & 0x07;
            sequence_length = 4;
        }
        else
        {
            result.push_back(text[index++]);
            continue;
        }

        if (index + sequence_length > text.size())
        {
            result.append(text, index, std::string::npos);
            break;
        }

        bool valid_sequence = true;
        for (std::size_t offset = 1; offset < sequence_length; ++offset)
        {
            const auto next = static_cast<unsigned char>(text[index + offset]);
            if ((next & 0xC0) != 0x80)
            {
                valid_sequence = false;
                break;
            }
            code_point = (code_point << 6) | (next & 0x3F);
        }

        if (!valid_sequence)
        {
            result.push_back(text[index++]);
            continue;
        }

        if (code_point == 0x0401)
        {
            code_point = 0x0451;
        }
        else if (code_point >= 0x0410 && code_point <= 0x042F)
        {
            code_point += 0x20;
        }

        append_utf8(result, code_point);
        index += sequence_length;
    }

    return result;
}

crow::response bad_request(const std::string& message)
{
    crow::json::wvalue body;
    body["error"] = message;
    crow::response response(400, body);
    response.set_header("Content-Type", "application/json; charset=utf-8");
    return response;
}

} // namespace

int main()
{
    crow::SimpleApp app;
    std::map<std::string, double> card_balances;
    std::map<std::string, std::string> card_owners;
    std::mutex card_mutex;
    std::mt19937_64 random_engine(std::random_device{}());

    CROW_ROUTE(app, "/create_card")
        .methods(crow::HTTPMethod::POST)(
            [&card_balances, &card_owners, &card_mutex, &random_engine](
                const crow::request& request) {
                crow::json::rvalue body;
                try
                {
                    body = crow::json::load(request.body);
                }
                catch (const std::exception&)
                {
                    return bad_request("Request body must contain valid JSON");
                }

                if (!body || body.t() != crow::json::type::Object ||
                    !body.has("owner_name") ||
                    body["owner_name"].t() != crow::json::type::String)
                {
                    return bad_request(
                        "Expected a JSON object with a string field 'owner_name'");
                }

                const std::string owner_name = body["owner_name"].s();
                if (owner_name.find_first_not_of(" \t\n\r") == std::string::npos)
                {
                    return bad_request("Owner name must not be blank");
                }

                std::lock_guard<std::mutex> lock(card_mutex);
                std::uniform_int_distribution<std::uint64_t> suffix_distribution(
                    0, 999999999999ULL);
                std::string card_number;
                do
                {
                    const std::string suffix =
                        std::to_string(suffix_distribution(random_engine));
                    card_number =
                        "4400" + std::string(12 - suffix.length(), '0') + suffix;
                } while (card_balances.find(card_number) != card_balances.end());

                constexpr double initial_balance = 100000.0;
                card_balances.emplace(card_number, initial_balance);
                card_owners.emplace(card_number, owner_name);

                crow::json::wvalue response;
                response["status"] = "ok";
                response["card_number"] = card_number;
                response["balance"] = initial_balance;
                crow::response result(201, response);
                result.set_header("Content-Type", "application/json; charset=utf-8");
                return result;
            });

    CROW_ROUTE(app, "/transfer")
        .methods(crow::HTTPMethod::POST)(
            [&card_balances, &card_mutex](const crow::request& request) {
                crow::json::rvalue body;
                try
                {
                    body = crow::json::load(request.body);
                }
                catch (const std::exception&)
                {
                    return bad_request("Request body must contain valid JSON");
                }

                if (!body || body.t() != crow::json::type::Object ||
                    !body.has("sender_card") ||
                    body["sender_card"].t() != crow::json::type::String ||
                    !body.has("receiver_card") ||
                    body["receiver_card"].t() != crow::json::type::String ||
                    !body.has("amount") ||
                    body["amount"].t() != crow::json::type::Number)
                {
                    return bad_request(
                        "Expected string fields 'sender_card' and 'receiver_card' "
                        "and a numeric field 'amount'");
                }

                const std::string sender_card = body["sender_card"].s();
                const std::string receiver_card = body["receiver_card"].s();
                const double amount = body["amount"].d();
                if (!std::isfinite(amount) || amount <= 0.0)
                {
                    return bad_request("Amount must be a positive finite number");
                }
                if (sender_card == receiver_card)
                {
                    return bad_request("Sender and receiver must be different");
                }

                std::lock_guard<std::mutex> lock(card_mutex);
                const auto sender = card_balances.find(sender_card);
                const auto receiver = card_balances.find(receiver_card);
                if (sender == card_balances.end() ||
                    receiver == card_balances.end())
                {
                    return bad_request("Sender or receiver card does not exist");
                }
                if (sender->second < amount)
                {
                    return bad_request("Insufficient balance");
                }

                sender->second -= amount;
                receiver->second += amount;

                crow::json::wvalue response;
                response["status"] = "ok";
                response["new_balance"] = sender->second;
                crow::response result(200, response);
                result.set_header("Content-Type", "application/json; charset=utf-8");
                return result;
            });

    CROW_ROUTE(app, "/health")
        .methods(crow::HTTPMethod::GET)([] {
            crow::json::wvalue response;
            response["status"] = "ok";
            crow::response result(200, response);
            result.set_header("Content-Type", "application/json; charset=utf-8");
            return result;
        });

    CROW_ROUTE(app, "/analyze")
        .methods(crow::HTTPMethod::POST)([](const crow::request& request) {
            crow::json::rvalue body;
            try
            {
                body = crow::json::load(request.body);
            }
            catch (const std::exception&)
            {
                return bad_request("Request body must contain valid JSON");
            }

            if (!body || body.t() != crow::json::type::Object ||
                !body.has("text") ||
                body["text"].t() != crow::json::type::String)
            {
                return bad_request("Expected a JSON object with a string field 'text'");
            }

            const std::string text = lowercase_utf8(body["text"].s());
            bool is_scam = false;
            std::string reason;

            if (text.find("код из sms") != std::string::npos ||
                text.find("код из смс") != std::string::npos ||
                text.find("продиктуйте") != std::string::npos)
            {
                is_scam = true;
                reason = "Просят код из SMS. Банк никогда не просит коды.";
            }
            else if (text.find("безопасный счет") != std::string::npos ||
                     text.find("безопасный счёт") != std::string::npos)
            {
                is_scam = true;
                reason = "Упоминание безопасного счета. Это мошенничество.";
            }
            else if (text.find("служба безопасности") != std::string::npos)
            {
                is_scam = true;
                reason =
                    "Представляются службой безопасности. Банк так не работает.";
            }

            crow::json::wvalue response;
            response["is_scam"] = is_scam;
            if (is_scam)
            {
                response["reason"] = reason;
            }
            crow::response result(200, response);
            result.set_header("Content-Type", "application/json; charset=utf-8");
            return result;
        });

    std::cout << "KiberQalqan Backend started on port 8000" << std::endl;
    app.port(8000).multithreaded().run();
}
