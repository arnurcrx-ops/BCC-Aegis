cmake_minimum_required(VERSION 3.20)

project(KiberQalqanBackend LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

find_package(Crow CONFIG REQUIRED)

# ── OpenSSL: явно указываем MinGW-совместимые .dll.a, чтобы CMake не взял MSVC .lib ──
set(OPENSSL_CRYPTO_LIBRARY "C:/Program Files/OpenSSL-Win64/lib/libcrypto.dll.a")
set(OPENSSL_SSL_LIBRARY    "C:/Program Files/OpenSSL-Win64/lib/libssl.dll.a")
find_package(OpenSSL 3 REQUIRED)
# ────────────────────────────────────────────────────────────────────────────────────

# Создаём target — СНАЧАЛА исходники, ПОТОМ линковка
add_executable(kiberqalqan_server
    src/main.cpp
)

# Линковка — после add_executable, target уже существует
target_link_libraries(kiberqalqan_server
    PRIVATE
        Crow::Crow
        OpenSSL::Crypto
)