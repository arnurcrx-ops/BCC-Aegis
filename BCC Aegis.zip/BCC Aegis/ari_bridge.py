"""ARI-мост: Asterisk (Stasis) -> скоринг в backend + защита внешних звонков.

Внутренний звонок 1001 -> 1002:  Stasis(aegis,incoming,<номер>)
Внешний звонок на телефон:       Stasis(aegis,outbound,<номер>)  -> транк оператора

Для внешних звонков жёсткие правила действуют всегда (они стоят денег):
  белый список префиксов, лимит звонков в час, лимит одновременных звонков.
Скоринг в backend: при ENFORCE=true и вердикте SHADOW_HOLD звонок сбрасывается.
"""
import asyncio
import json
import logging
import os
import re
import time
from collections import defaultdict, deque

import httpx
import websockets

ARI_URL = os.environ.get("ASTERISK_ARI_URL", "http://asterisk:8088/ari")
ARI_USER = os.environ.get("ARI_USER", "aegis")
ARI_PASSWORD = os.environ["ARI_PASSWORD"]
BACKEND_URL = os.environ.get("BACKEND_URL", "http://backend:8000")
API_KEY = os.environ["AEGIS_API_KEY"]
ENFORCE = os.getenv("ENFORCE", "false").lower() == "true"

TRUNK_ENABLED = os.getenv("TRUNK_ENABLED", "false").lower() == "true"
TRUNK_DIAL_FORMAT = os.getenv("TRUNK_DIAL_FORMAT", "digits")  # digits | e164
ALLOWED_PREFIXES = [p.strip() for p in os.getenv("ALLOWED_PREFIXES", "+7").split(",") if p.strip()]
OUT_MAX_PER_HOUR = int(os.getenv("OUTBOUND_MAX_PER_HOUR", "10"))
OUT_MAX_CONCURRENT = int(os.getenv("OUTBOUND_MAX_CONCURRENT", "1"))

APP = "aegis"
POLL_S = 10
VELOCITY_WINDOW_S = 600

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("aegis.ari")

calls: dict[str, dict] = {}                     # id входящего канала -> состояние
pending_out: dict[str, str] = {}                # id исходящего канала -> id входящего
history: dict[str, deque] = defaultdict(deque)  # endpoint -> времена звонков (10 мин)
active: dict[str, int] = defaultdict(int)       # endpoint -> активные звонки
out_history: dict[str, deque] = defaultdict(deque)  # endpoint -> внешние звонки (1 час)
out_active: dict[str, int] = defaultdict(int)   # endpoint -> активные внешние звонки

ari = httpx.AsyncClient(base_url=ARI_URL, auth=(ARI_USER, ARI_PASSWORD), timeout=10)
backend = httpx.AsyncClient(base_url=BACKEND_URL, headers={"X-API-Key": API_KEY}, timeout=5)


# ---------- вспомогательные функции для внешних номеров ----------

def normalize(raw: str) -> str:
    """Приводит номер к E.164: 8701..., 7701..., +7701... -> +7701..."""
    digits = re.sub(r"\D", "", raw)
    if raw.strip().startswith("+"):
        return "+" + digits
    if len(digits) == 11 and digits[0] in "78":
        return "+7" + digits[1:]
    return "+" + digits


def mask(num: str) -> str:
    """Номер в логи и backend только в маскированном виде."""
    return num if len(num) <= 7 else num[:5] + "*" * (len(num) - 7) + num[-2:]


def check_outbound(endpoint: str, e164: str, now: float) -> str | None:
    """Возвращает причину отказа или None, если звонок разрешён."""
    if not TRUNK_ENABLED:
        return "trunk_disabled"
    if not re.fullmatch(r"\+\d{8,15}", e164):
        return "bad_number"
    if not any(e164.startswith(p) for p in ALLOWED_PREFIXES):
        return "destination_not_allowed"
    h = out_history[endpoint]
    while h and now - h[0] > 3600:
        h.popleft()
    if len(h) >= OUT_MAX_PER_HOUR:
        return "hourly_limit"
    if out_active[endpoint] >= OUT_MAX_CONCURRENT:
        return "concurrent_limit"
    return None


def dial_string(e164: str) -> str:
    number = e164 if TRUNK_DIAL_FORMAT == "e164" else e164.lstrip("+")
    return f"PJSIP/{number}@trunk"


# ---------- ARI ----------

async def ari_call(method: str, path: str, **kw):
    try:
        r = await ari.request(method, path, **kw)
        r.raise_for_status()
        return r.json() if r.content else None
    except httpx.HTTPError as e:
        log.warning("ARI %s %s failed: %s", method, path, e)
        return None


async def get_var(channel_id: str, name: str) -> str:
    res = await ari_call("GET", f"/channels/{channel_id}/variable", params={"variable": name})
    return (res or {}).get("value", "") or ""


async def get_jitter_ms(channel_id: str) -> int:
    # RTCP-jitter в секундах; доступен только при активном RTCP, иначе 0
    raw = await get_var(channel_id, "CHANNEL(rtcp,rxjitter)")
    try:
        return int(float(raw) * 1000)
    except ValueError:
        return 0


async def score(channel_id: str, c: dict) -> str:
    ev = {
        "call_id": channel_id[:64],
        "endpoint": c["endpoint"],
        "user_agent": c["user_agent"],
        "jitter_ms": await get_jitter_ms(channel_id) if c.get("answered") else 0,
        "calls_last_10min": len(history[c["endpoint"]]),
        "concurrent_calls": active[c["endpoint"]],
        "elapsed_s": int(time.time() - c["start"]),
        "external": bool(c.get("external")),
        "destination": c.get("dest_masked", ""),
    }
    try:
        r = await backend.post("/api/v1/call-event", json=ev)
        r.raise_for_status()
        res = r.json()
    except httpx.HTTPError as e:
        log.warning("backend недоступен: %s (звонок не блокируется)", e)
        return "ALLOW"  # fail-open: сбой скоринга не должен ронять телефонию
    log.info("call %s %s -> %s %s", c["endpoint"], channel_id, res["verdict"], res["signals"])
    return res["verdict"]


async def hangup(channel_id: str):
    await ari_call("DELETE", f"/channels/{channel_id}")


async def monitor(channel_id: str):
    while channel_id in calls:
        await asyncio.sleep(POLL_S)
        c = calls.get(channel_id)
        if not c:
            return
        if await score(channel_id, c) == "SHADOW_HOLD" and ENFORCE:
            log.warning("ENFORCE: сбрасываю звонок %s", channel_id)
            await hangup(channel_id)
            return


async def on_call(channel: dict, kind: str, dest: str):
    cid = channel["id"]
    endpoint = channel["caller"]["number"] or "unknown"
    now = time.time()
    external = kind == "outbound"

    if external:
        e164 = normalize(dest)
        reason = check_outbound(endpoint, e164, now)
        if reason:
            log.warning("BLOCKED outbound %s -> %s: %s", endpoint, mask(e164), reason)
            await hangup(cid)
            return
        out_history[endpoint].append(now)
        out_active[endpoint] += 1
        target = dial_string(e164)
        dest_masked = mask(e164)
    else:
        target = f"PJSIP/{dest}"
        dest_masked = dest

    h = history[endpoint]
    while h and now - h[0] > VELOCITY_WINDOW_S:
        h.popleft()
    h.append(now)
    active[endpoint] += 1
    calls[cid] = {
        "endpoint": endpoint, "start": now, "peer": None, "bridge": None,
        "external": external, "dest_masked": dest_masked,
        "user_agent": await get_var(cid, "PJSIP_HEADER(read,User-Agent)"),
    }
    verdict = await score(cid, calls[cid])
    if verdict == "SHADOW_HOLD" and ENFORCE:
        log.warning("ENFORCE: отклоняю звонок %s -> %s", endpoint, dest_masked)
        await hangup(cid)  # StasisEnd вызовет cleanup
        return

    await ari_call("POST", f"/channels/{cid}/ring")
    bridge = await ari_call("POST", "/bridges", params={"type": "mixing"})
    out = await ari_call("POST", "/channels", params={
        "endpoint": target, "app": APP,
        "appArgs": f"outgoing,{cid}", "callerId": endpoint, "timeout": 40 if external else 30,
    })
    if not bridge or not out:
        await hangup(cid)
        return
    calls[cid].update(bridge=bridge["id"], peer=out["id"])
    pending_out[out["id"]] = cid
    asyncio.create_task(monitor(cid))


async def on_outgoing(channel: dict, in_id: str):
    pending_out.pop(channel["id"], None)
    c = calls.get(in_id)
    if not c:
        await hangup(channel["id"])
        return
    c["answered"] = True
    await ari_call("POST", f"/channels/{in_id}/answer")
    await ari_call("POST", f"/bridges/{c['bridge']}/addChannel",
                   params={"channel": f"{in_id},{channel['id']}"})


async def cleanup(channel_id: str):
    c = calls.pop(channel_id, None)
    if not c:
        return
    active[c["endpoint"]] = max(0, active[c["endpoint"]] - 1)
    if c.get("external"):
        out_active[c["endpoint"]] = max(0, out_active[c["endpoint"]] - 1)
    if c["peer"]:
        await hangup(c["peer"])
    if c["bridge"]:
        await ari_call("DELETE", f"/bridges/{c['bridge']}")
    log.info("call ended %s %s", c["endpoint"], channel_id)


async def handle(event: dict):
    t = event.get("type")
    ch = event.get("channel", {})
    if t == "StasisStart":
        args = event.get("args", [])
        if args[:1] in (["incoming"], ["outbound"]) and len(args) > 1:
            await on_call(ch, args[0], args[1])
        elif args[:1] == ["outgoing"] and len(args) > 1:
            await on_outgoing(ch, args[1])
    elif t == "StasisEnd" and ch.get("id") in calls:
        await cleanup(ch["id"])
    elif t == "ChannelDestroyed" and ch.get("id") in pending_out:
        # вызываемый не ответил/занят/транк отказал: отбиваем звонящего
        in_id = pending_out.pop(ch["id"])
        await hangup(in_id)


async def main():
    ws_url = (ARI_URL.replace("http", "ws", 1) +
              f"/events?app={APP}&api_key={ARI_USER}:{ARI_PASSWORD}")
    delay = 1
    log.info("ARI-мост запущен, ENFORCE=%s, TRUNK=%s, префиксы=%s",
             ENFORCE, TRUNK_ENABLED, ALLOWED_PREFIXES)
    while True:
        try:
            async with websockets.connect(ws_url) as ws:
                log.info("подключён к ARI")
                delay = 1
                async for raw in ws:
                    asyncio.create_task(handle(json.loads(raw)))
        except Exception as e:  # noqa: BLE001
            log.warning("ARI ws: %s, повтор через %ss", e, delay)
            await asyncio.sleep(delay)
            delay = min(delay * 2, 30)


if __name__ == "__main__":
    asyncio.run(main())
