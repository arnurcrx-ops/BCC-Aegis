#include <QtTest>
#include "security/Crypto.h"

using namespace bcc::security;

class TestCrypto : public QObject {
    Q_OBJECT
private slots:
    // 1
    void aesGcm_EncryptDecrypt_Roundtrip() {
        const QByteArray key = Crypto::secureRandom(32);
        const QByteArray plain = QByteArrayLiteral("demo transfer: 100 KZT to account 0000");
        auto blob = Crypto::encrypt(plain, key);
        QCOMPARE(Crypto::decrypt(blob, key), plain);
        QVERIFY(!blob.nonce.isEmpty());
        QVERIFY(!blob.tag.isEmpty());
    }
    // 2
    void aesGcm_TamperCiphertext_Throws() {
        const QByteArray key = Crypto::secureRandom(32);
        auto blob = Crypto::encrypt("secret", key);
        blob.ciphertext[0] = static_cast<char>(blob.ciphertext[0] ^ 0x01);
        QVERIFY_EXCEPTION_THROWN(Crypto::decrypt(blob, key), CryptoError);
    }
    // 3
    void aesGcm_WrongKey_Throws() {
        const QByteArray k1 = Crypto::secureRandom(32);
        const QByteArray k2 = Crypto::secureRandom(32);
        auto blob = Crypto::encrypt("secret", k1);
        QVERIFY_EXCEPTION_THROWN(Crypto::decrypt(blob, k2), CryptoError);
    }
    // 4
    void pbkdf2_DifferentSalts_DifferentKeys() {
        const QByteArray s1 = Crypto::secureRandom(16);
        const QByteArray s2 = Crypto::secureRandom(16);
        const QByteArray k1 = Crypto::deriveKey("password", s1, 100000);
        const QByteArray k2 = Crypto::deriveKey("password", s2, 100000);
        QCOMPARE(k1.size(), 32);
        QVERIFY(k1 != k2);
    }
    // 5
    void x25519_SharedSecretEquality() {
        auto a = Crypto::generateX25519();
        auto b = Crypto::generateX25519();
        const QByteArray sa = Crypto::computeSharedSecret(a.secretKey, b.publicKey);
        const QByteArray sb = Crypto::computeSharedSecret(b.secretKey, a.publicKey);
        QCOMPARE(sa.size(), 32);
        QCOMPARE(sa, sb);
    }
    // 6
    void x25519_WrongPeer_DifferentSecret() {
        auto a  = Crypto::generateX25519();
        auto b  = Crypto::generateX25519();
        auto c  = Crypto::generateX25519();
        const QByteArray s_ab = Crypto::computeSharedSecret(a.secretKey, b.publicKey);
        const QByteArray s_ac = Crypto::computeSharedSecret(a.secretKey, c.publicKey);
        QVERIFY(s_ab != s_ac);
    }
    // 7
    void ed25519_SignVerify() {
        auto kp = Crypto::generateEd25519();
        const QByteArray msg = QByteArrayLiteral("scam-check verdict: suspicious");
        const QByteArray sig = Crypto::ed25519Sign(msg, kp.secretKey);
        QCOMPARE(sig.size(), 64);
        QVERIFY(Crypto::ed25519Verify(msg, sig, kp.publicKey));
    }
    // 8
    void ed25519_TamperedMessage_Fails() {
        auto kp = Crypto::generateEd25519();
        const QByteArray msg = QByteArrayLiteral("verdict: safe");
        const QByteArray sig = Crypto::ed25519Sign(msg, kp.secretKey);
        QVERIFY(!Crypto::ed25519Verify(msg + "!", sig, kp.publicKey));
    }
    // 9
    void aesGcm_TamperNonce_Throws() {
        const QByteArray key = Crypto::secureRandom(32);
        auto blob = Crypto::encrypt("secret", key);
        blob.nonce[0] = static_cast<char>(blob.nonce[0] ^ 0xFF);
        QVERIFY_EXCEPTION_THROWN(Crypto::decrypt(blob, key), CryptoError);
    }
};

QTEST_MAIN(TestCrypto)
#include "test_crypto.moc"  