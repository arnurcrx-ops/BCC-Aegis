#include <QtTest>
#include <QTemporaryDir>
#include <QFile>
#include <QFileInfo>
#include <memory>

#include "security/Crypto.h"
#include "security/SecureStorage.h"

using namespace bcc::security;

class TestStorage : public QObject {
    Q_OBJECT
private slots:
    void init() { m_dir.reset(new QTemporaryDir); QVERIFY(m_dir->isValid()); }
    void cleanup() { m_dir.reset(); }

    void saveLoad_Roundtrip() {
        SecureStorage s(m_dir->filePath("data.bin"));
        const QByteArray data = R"({"activity":[{"id":1,"amount":100}]})";
        s.save(data, "correct horse battery staple");
        QCOMPARE(s.load("correct horse battery staple"), data);
    }

    void wrongPassword_Throws() {
        SecureStorage s(m_dir->filePath("data.bin"));
        s.save("secret", "password-A");
        QVERIFY_EXCEPTION_THROWN(s.load("password-B"), SecureStorageError);
    }

    void tamperCiphertext_Throws() {
        const QString p = m_dir->filePath("data.bin");
        SecureStorage s(p);
        s.save(QByteArray(100, 'A'), "pw");
        flipByteAt(p, 4 + 1 + 16 + 4 + 12 + 5);
        QVERIFY_EXCEPTION_THROWN(s.load("pw"), SecureStorageError);
    }

    void tamperTag_Throws() {
        const QString p = m_dir->filePath("data.bin");
        SecureStorage s(p);
        s.save(QByteArray(100, 'A'), "pw");
        flipByteAt(p, fileSize(p) - 1);
        QVERIFY_EXCEPTION_THROWN(s.load("pw"), SecureStorageError);
    }

    void tamperSalt_Throws() {
        const QString p = m_dir->filePath("data.bin");
        SecureStorage s(p);
        s.save("hello", "pw");
        flipByteAt(p, 5);
        QVERIFY_EXCEPTION_THROWN(s.load("pw"), SecureStorageError);
    }

    void truncatedFile_Throws() {
        const QString p = m_dir->filePath("data.bin");
        SecureStorage s(p);
        s.save(QByteArray(100, 'A'), "pw");
        QFile f(p);
        QVERIFY(f.open(QIODevice::ReadWrite));
        QVERIFY(f.resize(20));
        f.close();
        QVERIFY_EXCEPTION_THROWN(s.load("pw"), SecureStorageError);
    }

    void repeatedSaveLoad_Stable() {
        SecureStorage s(m_dir->filePath("data.bin"));
        s.save("v1", "pw");
        QCOMPARE(s.load("pw"), QByteArray("v1"));
        s.save("v2-longer", "pw");
        QCOMPARE(s.load("pw"), QByteArray("v2-longer"));
        s.save("v3", "pw");
        QCOMPARE(s.load("pw"), QByteArray("v3"));
    }

    void missingFile_Throws() {
        SecureStorage s(m_dir->filePath("nope.bin"));
        QVERIFY_EXCEPTION_THROWN(s.load("pw"), SecureStorageError);
    }

    void emptyPassword_Throws() {
        SecureStorage s(m_dir->filePath("data.bin"));
        QVERIFY_EXCEPTION_THROWN(s.save("x", ""), SecureStorageError);
    }

private:
    void flipByteAt(const QString& path, qint64 offset) {
        QFile f(path);
        QVERIFY(f.open(QIODevice::ReadWrite));
        QVERIFY(f.seek(offset));
        char b = 0;
        QVERIFY(f.getChar(&b));
        b = static_cast<char>(b ^ 0xFF);
        QVERIFY(f.seek(offset));
        QVERIFY(f.putChar(b));
        f.close();
    }
    qint64 fileSize(const QString& p) { return QFileInfo(p).size(); }

    std::unique_ptr<QTemporaryDir> m_dir;
};

QTEST_MAIN(TestStorage)
#include "test_storage.moc"